import XCTest
import HealthKit
@testable import UnRatito
final class HealthDataTests:XCTestCase {
    func record(_ start:Double,_ end:Double,_ name:String = "Dormido (sin fase)")->HealthRecord {
        HealthRecord(id:UUID().uuidString,start:Date(timeIntervalSince1970:start),end:Date(timeIntervalSince1970:end),text:name,source:"Test")
    }
    func testSleepOverlapsAreNotCountedTwice() {
        XCTAssertEqual(asleepSeconds([record(0,100),record(50,150),record(160,200)],from:Date(timeIntervalSince1970:0),to:Date(timeIntervalSince1970:300)),190)
    }
    func testSleepClipsWindowAndExcludesInBedAndAwake() {
        let values = [record(0,100),record(90,150,"Sueño REM"),record(0,500,"En cama"),record(0,500,"Despierto")]
        XCTAssertEqual(asleepSeconds(values,from:Date(timeIntervalSince1970:50),to:Date(timeIntervalSince1970:120)),70)
        XCTAssertEqual(asleepSeconds([],from:Date(),to:Date()),0)
    }
    func testCatalogueTypesAndAggregationMatchSDK() throws {
        XCTAssertGreaterThanOrEqual(Metric.all.count,60)
        XCTAssertEqual(Set(Metric.all.map(\.id)).count,Metric.all.count)
        for metric in Metric.all {
            let type = try XCTUnwrap(metric.type)
            if let quantity = type as? HKQuantityType {
                XCTAssertNotNil(metric.unit,metric.key)
                XCTAssertEqual(quantity.aggregationStyle == .cumulative,metric.cumulative,metric.key)
            }
        }
    }
    func testCachePreservesAbsentVersusZero() throws {
        let original = ["absent":MetricResult(),"zero":MetricResult(value:0)]
        let restored = try JSONDecoder().decode([String:MetricResult].self,from:JSONEncoder().encode(original))
        XCTAssertNil(restored["absent"]?.value)
        XCTAssertEqual(restored["zero"]?.value,0)
    }
}
