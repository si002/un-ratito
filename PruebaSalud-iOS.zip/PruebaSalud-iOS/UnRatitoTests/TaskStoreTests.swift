import XCTest
@testable import UnRatito

final class TaskStoreTests: XCTestCase {
    private func temporaryURL() -> URL {
        FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathComponent("tasks.json")
    }
    @MainActor func testPersistenceAndCompletion() throws {
        let url = temporaryURL()
        defer { try? FileManager.default.removeItem(at: url.deletingLastPathComponent()) }
        let store = TaskStore(fileURL: url)
        XCTAssertTrue(store.add("  Pasear  "))
        XCTAssertEqual(store.tasks.first?.text, "Pasear")
        store.toggle(try XCTUnwrap(store.tasks.first?.id))
        let reopened = TaskStore(fileURL: url)
        XCTAssertEqual(reopened.completed, 1)
        reopened.clearCompleted()
        XCTAssertTrue(TaskStore(fileURL: url).tasks.isEmpty)
    }
    func testImportsPWABackup() throws {
        let data = Data(#"{"app":"un-ratito","version":1,"tasks":[{"id":"web-123","text":"Mi tarea","done":false}]}"#.utf8)
        XCTAssertEqual(try Backup.decode(data).tasks.first?.id, "web-123")
    }
    func testRejectsDuplicateIdentifiers() throws {
        let task = SmallTask(id: "same", text: "Hola", done: false)
        let data = try JSONEncoder().encode(Backup(tasks: [task, task]))
        XCTAssertThrowsError(try Backup.decode(data))
    }
    @MainActor func testCorruptStorageIsNotOverwritten() throws {
        let url = temporaryURL()
        defer { try? FileManager.default.removeItem(at: url.deletingLastPathComponent()) }
        try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        let original = Data("not json".utf8)
        try original.write(to: url)
        let store = TaskStore(fileURL: url)
        XCTAssertNotNil(store.errorMessage)
        XCTAssertFalse(store.add("No sobrescribir"))
        XCTAssertEqual(try Data(contentsOf: url), original)
    }
    @MainActor func testFailedWriteKeepsPreviousState() throws {
        let parent = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: parent) }
        try Data("file, not folder".utf8).write(to: parent)
        let store = TaskStore(fileURL: parent.appendingPathComponent("tasks.json"))
        XCTAssertFalse(store.add("No debe aparecer"))
        XCTAssertTrue(store.tasks.isEmpty)
    }
}
