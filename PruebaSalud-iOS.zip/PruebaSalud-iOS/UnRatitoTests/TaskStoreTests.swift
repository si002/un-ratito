import XCTest
import HealthKit
@testable import UnRatito
final class HealthDataTests:XCTestCase {
    func record(_ start:Double,_ end:Double,_ name:String = "Dormido (sin fase)")->HealthRecord {
        HealthRecord(id:UUID().uuidString,start:Date(timeIntervalSince1970:start),end:Date(timeIntervalSince1970:end),text:name,source:"Test")
    }
    func testSleepOverlapsAreNotCountedTwice() {
        XCTAssertEqual(asleepSeconds([record(0,100),record(50,150),record(160,200)],from:Date(timeIntervalSince1970:0),to:Date(timeIntervalSince1970:300)),190)
    }
    func testSleepClipsWindowAndExcludesInBedAndAwake() {
        let values = [record(0,100),record(90,150,"Sueño REM"),record(0,500,"En cama"),record(0,500,"Despierto")]
        XCTAssertEqual(asleepSeconds(values,from:Date(timeIntervalSince1970:50),to:Date(timeIntervalSince1970:120)),70)
        XCTAssertEqual(asleepSeconds([],from:Date(),to:Date()),0)
    }
    func testCatalogueTypesAndAggregationMatchSDK() throws {
        XCTAssertGreaterThanOrEqual(Metric.all.count,60)
        XCTAssertEqual(Set(Metric.all.map(\.id)).count,Metric.all.count)
        for metric in Metric.all {
            let type = try XCTUnwrap(metric.type)
            if let quantity = type as? HKQuantityType {
                XCTAssertNotNil(metric.unit,metric.key)
                XCTAssertEqual(quantity.aggregationStyle == .cumulative,metric.cumulative,metric.key)
            }
        }
    }
    func testCachePreservesAbsentVersusZero() throws {
        let original = ["absent":MetricResult(),"zero":MetricResult(value:0)]
        let restored = try JSONDecoder().decode([String:MetricResult].self,from:JSONEncoder().encode(original))
        XCTAssertNil(restored["absent"]?.value)
        XCTAssertEqual(restored["zero"]?.value,0)
    }
}

extension HealthDataTests {
    func fixture()->(Date,[String:MetricResult],CoachProfile) {
        let now = Calendar.current.date(from:DateComponents(year:2026,month:10,day:18,hour:8))!
        var records:[HealthRecord] = []
        for offset in 0...28 {
            let day = Calendar.current.date(byAdding:.day,value:-offset,to:now)!
            let end = Calendar.current.date(bySettingHour:7,minute:0,second:0,of:day)!
            records.append(HealthRecord(id:"night-\(offset)",start:end.addingTimeInterval(-8*3600),end:end,text:"Dormido",source:"HUAWEI",categoryValue:1))
        }
        var sleep = MetricResult(date:records.first!.end); sleep.sleepRecords = records; sleep.checked = now
        var rhr = MetricResult(value:60,date:now); rhr.sources = ["HUAWEI"]; rhr.checked = now
        rhr.days = (0...15).map { DayValue(date:Calendar.current.date(byAdding:.day,value:$0-15,to:Calendar.current.startOfDay(for:now))!,value:60) }
        var profile = CoachProfile(); profile.completed = true; profile.age = 25
        return (now,["SleepAnalysis":sleep,"RestingHeartRate":rhr],profile)
    }
    func testRecoveryRequiresRecentSleepAndCompleteProfile() {
        let (now,results,profile) = fixture()
        let valid = RecoveryEngine.snapshot(results:results,profile:profile,checks:[],ratings:[:],now:now)
        XCTAssertNotNil(valid.score); XCTAssertEqual(valid.phase,"morning")
        let absent = RecoveryEngine.snapshot(results:[:],profile:profile,checks:[],ratings:[:],now:now)
        XCTAssertNil(absent.score); XCTAssertEqual(absent.maxMinutes,0)
        var old = results; old["SleepAnalysis"]?.checked = now.addingTimeInterval(-7*3600)
        XCTAssertNil(RecoveryEngine.snapshot(results:old,profile:profile,checks:[],ratings:[:],now:now).score)
        var incomplete = profile; incomplete.completed = false
        XCTAssertNil(RecoveryEngine.snapshot(results:results,profile:incomplete,checks:[],ratings:[:],now:now).score)
    }
    func testAdverseSensationsOverrideHighRecoveryAndMinorPlansAreGeneralOnly() {
        let (now,results,profile) = fixture()
        let check = DailyCheck(date:now,energy:1,soreness:0,unwell:true)
        let snapshot = RecoveryEngine.snapshot(results:results,profile:profile,checks:[check],ratings:[:],now:now)
        XCTAssertTrue(snapshot.caution); XCTAssertEqual(snapshot.maxMinutes,0)
        var minor = profile; minor.age = 15
        XCTAssertEqual(RecoveryEngine.snapshot(results:results,profile:minor,checks:[],ratings:[:],now:now).maxMinutes,0)
        XCTAssertEqual(RecoveryEngine.ageRange(15).0,8)
    }
    func testElevatedRestingPulseReducesIndexAndMissingHRVIsExplicit() {
        let (now,results,profile) = fixture()
        let base = RecoveryEngine.snapshot(results:results,profile:profile,checks:[],ratings:[:],now:now)
        var elevated = results
        let lastIndex = elevated["RestingHeartRate"]!.days.count-1
        elevated["RestingHeartRate"]!.days[lastIndex].value = 78
        let changed = RecoveryEngine.snapshot(results:elevated,profile:profile,checks:[],ratings:[:],now:now)
        XCTAssertLessThan(changed.score!,base.score!)
        XCTAssertTrue(changed.missing.contains { $0.contains("VFC") })
        XCTAssertTrue((0...100).contains(changed.score!))
    }
    func testTwoHourMorningBoundaryAndTomorrowOverride() {
        let (now,results,profile) = fixture()
        XCTAssertEqual(RecoveryEngine.snapshot(results:results,profile:profile,checks:[],ratings:[:],now:now.addingTimeInterval(3600)).phase,"activity")
        var changed = profile
        changed.tomorrowOverride = Calendar.current.date(bySettingHour:10,minute:30,second:0,of:Calendar.current.date(byAdding:.day,value:1,to:now)!)!
        XCTAssertEqual(RecoveryEngine.alarm(profile:changed,now:now),changed.tomorrowOverride)
    }
    func testEffortWithoutRatingIsNotInvented() {
        let w = WorkoutSummary(id:"a",start:Date(),end:Date(),activity:"Caminar",kind:52,minutes:30)
        XCTAssertNil(RecoveryEngine.load(w,ratings:[:]))
        XCTAssertEqual(RecoveryEngine.load(w,ratings:["a":4]),120)
        XCTAssertEqual(RecoveryEngine.effortScore(4),40)
        XCTAssertEqual(RecoveryEngine.effortScore(15),100)
    }
    func testNightWindowKeepsLocalNoonAcrossDST() {
        var calendar = Calendar(identifier:.gregorian); calendar.timeZone = TimeZone(identifier:"Europe/Madrid")!
        let date = calendar.date(from:DateComponents(year:2026,month:10,day:25,hour:8))!
        let window = nightWindow(date,calendar:calendar)
        XCTAssertEqual(calendar.component(.hour,from:window.0),12)
        XCTAssertEqual(calendar.component(.hour,from:window.1),12)
        XCTAssertEqual(window.1.timeIntervalSince(window.0),25*3600)
    }
    func testOpenAIRequestUsesExactModelMaxAndNoStoredResponse() throws {
        let request = try CoachAPI.request(key:"test-token",payload:["age":25],maxMinutes:15)
        let body = try JSONSerialization.jsonObject(with:request.httpBody!) as! [String:Any]
        XCTAssertEqual(request.url?.absoluteString,"https://api.openai.com/v1/responses")
        XCTAssertEqual(body["model"] as? String,"gpt-6-luna")
        XCTAssertEqual((body["reasoning"] as? [String:String])?["effort"],"max")
        XCTAssertEqual(body["store"] as? Bool,false)
        XCTAssertFalse(String(data:request.httpBody!,encoding:.utf8)!.contains("test-token"))
        XCTAssertFalse(CoachAPI.intensities(15).contains("moderate"))
    }
    func testAIRejectsIncompleteRefusalAndExcessiveWorkout() throws {
        XCTAssertThrowsError(try CoachAPI.decode(Data(#"{"status":"incomplete","output":[]}"#.utf8),maxMinutes:15))
        XCTAssertThrowsError(try CoachAPI.decode(Data(#"{"status":"completed","output":[{"content":[{"type":"refusal"}]}]}"#.utf8),maxMinutes:15))
        let plan = CoachPlan(title:"Demo",duration_minutes:45,intensity:"moderate",steps:["Demo"])
        let advice = CoachAdvice(headline:"Demo",interpretation:"Demo",factors:[],minimum_plan:plan,progression_plan:plan,sleep_advice:"Demo",limitations:"Demo")
        let text = String(data:try JSONEncoder().encode(advice),encoding:.utf8)!
        let body = try JSONSerialization.data(withJSONObject:["status":"completed","output":[["content":[["type":"output_text","text":text]]]]])
        XCTAssertThrowsError(try CoachAPI.decode(body,maxMinutes:15))
        XCTAssertNoThrow(try CoachAPI.decode(body,maxMinutes:45))
    }
    func testNightIncludesPreviousEveningAcrossMidnight() {
        var calendar = Calendar(identifier:.gregorian)
        calendar.timeZone = TimeZone(secondsFromGMT:0)!
        let wake = calendar.date(from:DateComponents(year:2026,month:10,day:18,hour:8))!
        let window = nightWindow(wake,calendar:calendar)
        XCTAssertEqual(calendar.component(.hour,from:window.0),12)
        XCTAssertEqual(calendar.component(.day,from:window.0),17)
        XCTAssertEqual(calendar.component(.day,from:window.1),18)
        XCTAssertEqual(calendar.component(.hour,from:window.1),12)
    }
    func testStagesResolveOverlapWithoutDoubleCountingAndAwakeWins() {
        var unspecified = record(0,100)
        unspecified.categoryValue = 1
        var deep = record(20,60)
        deep.categoryValue = 4
        var awake = record(40,50)
        awake.categoryValue = 2
        let segments = resolvedSleep([unspecified,deep,awake,deep],from:Date(timeIntervalSince1970:0),to:Date(timeIntervalSince1970:100))
        let total = segments.filter { $0.phase != 2 }.reduce(0) { $0+$1.end.timeIntervalSince($1.start) }
        let deepSeconds = segments.filter { $0.phase == 4 }.reduce(0) { $0+$1.end.timeIntervalSince($1.start) }
        XCTAssertEqual(total,90)
        XCTAssertEqual(deepSeconds,30)
        XCTAssertFalse(segments.contains { $0.phase == 5 })
    }
    func testMissingStagesAreNotInventedAndInBedIsExcluded() {
        var inBed = record(0,200)
        inBed.categoryValue = 0
        var unspecified = record(20,100)
        unspecified.categoryValue = 1
        let segments = resolvedSleep([inBed,unspecified],from:Date(timeIntervalSince1970:0),to:Date(timeIntervalSince1970:200))
        XCTAssertEqual(segments.count,1)
        XCTAssertEqual(segments.first?.phase,1)
        XCTAssertEqual(segments.first?.end.timeIntervalSince(segments.first!.start),80)
    }
}
