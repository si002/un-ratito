import XCTest
import HealthKit
@testable import UnRatito
final class HealthDataTests:XCTestCase {
    func record(_ start:Double,_ end:Double,_ name:String = "Dormido (sin fase)")->HealthRecord {
        HealthRecord(id:UUID().uuidString,start:Date(timeIntervalSince1970:start),end:Date(timeIntervalSince1970:end),text:name,source:"Test")
    }
    func testSleepOverlapsAreNotCountedTwice() {
        XCTAssertEqual(asleepSeconds([record(0,100),record(50,150),record(160,200)],from:Date(timeIntervalSince1970:0),to:Date(timeIntervalSince1970:300)),190)
    }
    func testSleepClipsWindowAndExcludesInBedAndAwake() {
        let values = [record(0,100),record(90,150,"Sueño REM"),record(0,500,"En cama"),record(0,500,"Despierto")]
        XCTAssertEqual(asleepSeconds(values,from:Date(timeIntervalSince1970:50),to:Date(timeIntervalSince1970:120)),70)
        XCTAssertEqual(asleepSeconds([],from:Date(),to:Date()),0)
    }
    func testCatalogueTypesAndAggregationMatchSDK() throws {
        XCTAssertGreaterThanOrEqual(Metric.all.count,60)
        XCTAssertEqual(Set(Metric.all.map(\.id)).count,Metric.all.count)
        for metric in Metric.all {
            let type = try XCTUnwrap(metric.type)
            if let quantity = type as? HKQuantityType {
                XCTAssertNotNil(metric.unit,metric.key)
                XCTAssertEqual(quantity.aggregationStyle == .cumulative,metric.cumulative,metric.key)
            }
        }
    }
    func testCachePreservesAbsentVersusZero() throws {
        let original = ["absent":MetricResult(),"zero":MetricResult(value:0)]
        let restored = try JSONDecoder().decode([String:MetricResult].self,from:JSONEncoder().encode(original))
        XCTAssertNil(restored["absent"]?.value)
        XCTAssertEqual(restored["zero"]?.value,0)
    }
}

extension HealthDataTests {
    func testNightIncludesPreviousEveningAcrossMidnight() {
        var calendar = Calendar(identifier:.gregorian)
        calendar.timeZone = TimeZone(secondsFromGMT:0)!
        let wake = calendar.date(from:DateComponents(year:2026,month:10,day:18,hour:8))!
        let window = nightWindow(wake,calendar:calendar)
        XCTAssertEqual(calendar.component(.hour,from:window.0),12)
        XCTAssertEqual(calendar.component(.day,from:window.0),17)
        XCTAssertEqual(calendar.component(.day,from:window.1),18)
        XCTAssertEqual(calendar.component(.hour,from:window.1),12)
    }
    func testStagesResolveOverlapWithoutDoubleCountingAndAwakeWins() {
        var unspecified = record(0,100)
        unspecified.categoryValue = 1
        var deep = record(20,60)
        deep.categoryValue = 4
        var awake = record(40,50)
        awake.categoryValue = 2
        let segments = resolvedSleep([unspecified,deep,awake,deep],from:Date(timeIntervalSince1970:0),to:Date(timeIntervalSince1970:100))
        let total = segments.filter { $0.phase != 2 }.reduce(0) { $0+$1.end.timeIntervalSince($1.start) }
        let deepSeconds = segments.filter { $0.phase == 4 }.reduce(0) { $0+$1.end.timeIntervalSince($1.start) }
        XCTAssertEqual(total,90)
        XCTAssertEqual(deepSeconds,30)
        XCTAssertFalse(segments.contains { $0.phase == 5 })
    }
    func testMissingStagesAreNotInventedAndInBedIsExcluded() {
        var inBed = record(0,200)
        inBed.categoryValue = 0
        var unspecified = record(20,100)
        unspecified.categoryValue = 1
        let segments = resolvedSleep([inBed,unspecified],from:Date(timeIntervalSince1970:0),to:Date(timeIntervalSince1970:200))
        XCTAssertEqual(segments.count,1)
        XCTAssertEqual(segments.first?.phase,1)
        XCTAssertEqual(segments.first?.end.timeIntervalSince(segments.first!.start),80)
    }
}
