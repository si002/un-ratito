import SwiftUI
@MainActor final class HealthAppDelegate:NSObject,UIApplicationDelegate {
    let health = HealthDashboard()
    func application(_ application:UIApplication,didFinishLaunchingWithOptions launchOptions:[UIApplication.LaunchOptionsKey:Any]? = nil)->Bool { true }
}
@main struct UnRatitoApp: App {
    @UIApplicationDelegateAdaptor(HealthAppDelegate.self) private var delegate
    var body: some Scene { WindowGroup { ContentView().environmentObject(delegate.health) } }
}
