import SwiftUI

@main
struct UnRatitoApp: App {
    @StateObject private var store = TaskStore()
    var body: some Scene {
        WindowGroup { ContentView().environmentObject(store) }
    }
}
