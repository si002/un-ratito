import Foundation
import SwiftUI
import UniformTypeIdentifiers

struct SmallTask: Codable, Identifiable, Equatable {
    let id: String
    var text: String
    var done: Bool
}

struct Backup: Codable {
    var app = "un-ratito"
    var version = 1
    var tasks: [SmallTask]

    static func decode(_ data: Data) throws -> Backup {
        guard data.count <= 5_000_000 else { throw TaskError.invalidBackup }
        let result = try JSONDecoder().decode(Backup.self, from: data)
        guard result.app == "un-ratito", result.version == 1,
              result.tasks.count <= 5000,
              Set(result.tasks.map(\.id)).count == result.tasks.count,
              result.tasks.allSatisfy({ !$0.id.isEmpty && $0.id.count <= 100 &&
                  !$0.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
                  $0.text.utf16.count <= 180 }) else { throw TaskError.invalidBackup }
        return result
    }
}

enum TaskError: LocalizedError {
    case invalidBackup, full, unavailable
    var errorDescription: String? {
        switch self {
        case .invalidBackup: return "El archivo no es una copia válida de Un ratito."
        case .full: return "La lista admite hasta 5000 tareas. Guarda una copia y elimina algunas."
        case .unavailable: return "No se pudo leer el guardado anterior. Para protegerlo, no se guardarán cambios. Conserva la app y pide ayuda antes de reinstalarla."
        }
    }
}

@MainActor
final class TaskStore: ObservableObject {
    @Published private(set) var tasks: [SmallTask] = []
    @Published var errorMessage: String?
    private let fileURL: URL
    private var canWrite = true
    var completed: Int { tasks.filter(\.done).count }
    var pending: Int { tasks.count - completed }

    init(fileURL: URL? = nil) {
        self.fileURL = fileURL ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("UnRatito", isDirectory: true).appendingPathComponent("tasks-v1.json")
        do {
            // A missing file is a new installation; any other read error is preserved.
            let data = try Data(contentsOf: self.fileURL)
            tasks = try Backup.decode(data).tasks
        } catch let error as NSError where error.domain == NSCocoaErrorDomain && error.code == NSFileReadNoSuchFileError {
            tasks = []
        } catch {
            canWrite = false
            errorMessage = TaskError.unavailable.localizedDescription
        }
    }

    @discardableResult
    private func save(_ next: [SmallTask]) -> Bool {
        guard canWrite else { errorMessage = TaskError.unavailable.localizedDescription; return false }
        do {
            let data = try JSONEncoder().encode(Backup(tasks: next))
            _ = try Backup.decode(data)
            try FileManager.default.createDirectory(at: fileURL.deletingLastPathComponent(), withIntermediateDirectories: true)
            try data.write(to: fileURL, options: .atomic)
            tasks = next
            return true
        } catch {
            errorMessage = "No se pudo guardar el cambio. Tus tareas anteriores se conservan. " + error.localizedDescription
            return false
        }
    }

    func add(_ input: String) -> Bool {
        let text = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return false }
        guard tasks.count < 5000 else { errorMessage = TaskError.full.localizedDescription; return false }
        return save([SmallTask(id: UUID().uuidString, text: text, done: false)] + tasks)
    }
    func toggle(_ id: String) {
        var next = tasks
        guard let index = next.firstIndex(where: { $0.id == id }) else { return }
        next[index].done.toggle()
        save(next)
    }
    func delete(_ id: String) { save(tasks.filter { $0.id != id }) }
    func clearCompleted() { save(tasks.filter { !$0.done }) }
    func restore(_ backup: Backup) { save(backup.tasks) }
}

struct BackupDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.json] }
    var backup: Backup
    init(tasks: [SmallTask]) { backup = Backup(tasks: tasks) }
    init(configuration: ReadConfiguration) throws {
        guard let data = configuration.file.regularFileContents else { throw TaskError.invalidBackup }
        backup = try Backup.decode(data)
    }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        return FileWrapper(regularFileWithContents: try encoder.encode(backup))
    }
}
