import SwiftUI
import Charts
import Security
import CryptoKit

func coachTime(_ date:Date)->String {
    let formatter = DateFormatter()
    formatter.locale = Locale(identifier:"es_ES")
    formatter.dateFormat = "HH:mm"
    return formatter.string(from:date)
}

struct WorkoutSummary:Codable,Identifiable {
    var id:String; var start:Date; var end:Date; var activity:String; var kind:UInt
    var minutes:Double; var distanceKM:Double?; var averageHR:Double?
}
struct DailyCheck:Codable,Identifiable {
    var date:Date; var energy:Int; var soreness:Int; var unwell:Bool
    var sleepQuality:Int? = nil
    var id:Date { date }
}
struct CoachProfile:Codable {
    var age = 0
    var regularWake = 7*60
    var freeWake = 9*60
    var scheduledDays:[Int] = [2,3,4,5,6]
    var tomorrowOverride:Date? = nil
    var availableMinutes = 25
    var usualActivity = "Caminar"
    var fitnessGoal = "Mantener"
    var limitedExercise = false
    var completed = false
    private enum CodingKeys:String,CodingKey { case age,regularWake,freeWake,scheduledDays,tomorrowOverride,availableMinutes,usualActivity,fitnessGoal,limitedExercise,completed }
    init() {}
    init(from decoder:Decoder)throws {
        let c = try decoder.container(keyedBy:CodingKeys.self)
        age = try c.decodeIfPresent(Int.self,forKey:.age) ?? 0
        regularWake = try c.decodeIfPresent(Int.self,forKey:.regularWake) ?? 7*60
        freeWake = try c.decodeIfPresent(Int.self,forKey:.freeWake) ?? 9*60
        scheduledDays = try c.decodeIfPresent([Int].self,forKey:.scheduledDays) ?? [2,3,4,5,6]
        tomorrowOverride = try c.decodeIfPresent(Date.self,forKey:.tomorrowOverride)
        availableMinutes = try c.decodeIfPresent(Int.self,forKey:.availableMinutes) ?? 25
        usualActivity = try c.decodeIfPresent(String.self,forKey:.usualActivity) ?? "Caminar"
        fitnessGoal = try c.decodeIfPresent(String.self,forKey:.fitnessGoal) ?? "Mantener"
        limitedExercise = try c.decodeIfPresent(Bool.self,forKey:.limitedExercise) ?? false
        completed = try c.decodeIfPresent(Bool.self,forKey:.completed) ?? false
    }
}
struct RecoveryFactor:Identifiable {
    var id:String; var title:String; var value:Double; var weight:Double; var detail:String
}
struct SleepNightDigest {
    var daysAgo:Int
    var hours:Double
    var awakeMinutes:Double
    var stageMinutes:[Int:Double]
    var sleepStart:Date?
    var wake:Date?
    var sleepRating:Int?
    var nextDayEnergy:Int?
    var restingHR:Double?
    var hrv:Double?
    var precedingWorkoutMinutes:Double
    var precedingWorkoutEffort:Double?
    func minutes(_ phase:Int)->Double { stageMinutes[phase] ?? 0 }
    func percent(_ phase:Int)->Double? { hours > 0 ? minutes(phase)/(hours*60)*100 : nil }
}
struct SleepStageReview:Identifiable {
    var phase:Int
    var minutes:Double
    var percent:Double?
    var comparison:String
    var id:Int { phase }
}
struct SleepQualityAssessment {
    var score:Int
    var confidence:String
    var basis:[String]
    var stages:[SleepStageReview]
    var history:[SleepNightDigest]
    var durationTarget:Double
    var subjectiveRating:Int?
}
enum SleepQualityEngine {
    static func assess(records:[HealthRecord],date:Date,source:String?,age:Int,checks:[DailyCheck],workouts:[WorkoutSummary],ratings:[String:Double],resting:[DayValue],hrv:[DayValue])->SleepQualityAssessment? {
        let calendar = Calendar.current
        func digest(_ nightDate:Date,_ daysAgo:Int)->SleepNightDigest? {
            let window = nightWindow(nightDate,calendar:calendar)
            let matching = records.filter { $0.source == source }
            let segments = resolvedSleep(matching,from:window.0,to:window.1)
            let asleep = segments.filter { [1,3,4,5].contains($0.phase) }
            let hours = asleep.reduce(0) { $0+$1.end.timeIntervalSince($1.start) }/3600
            guard hours >= 3, hours <= 14 else { return nil }
            var stageMinutes:[Int:Double] = [:]
            for phase in 1...5 { stageMinutes[phase] = segments.filter { $0.phase == phase }.reduce(0) { $0+$1.end.timeIntervalSince($1.start) }/60 }
            let check = checks.first { calendar.isDate($0.date,inSameDayAs:nightDate) }
            let start = asleep.first?.start
            let recentWorkout = workouts.filter { workout in
                guard let start = start else { return false }
                return workout.end <= start && workout.end >= start.addingTimeInterval(-12*3600)
            }
            let latestResting = resting.filter { $0.date <= window.1 && $0.date >= window.0.addingTimeInterval(-86400) }.max(by:{ $0.date < $1.date })?.value
            let latestHRV = hrv.filter { $0.date <= window.1 && $0.date >= window.0.addingTimeInterval(-86400) }.max(by:{ $0.date < $1.date })?.value
            let effort = recentWorkout.compactMap { ratings[$0.id] }
            return SleepNightDigest(daysAgo:daysAgo,hours:hours,awakeMinutes:stageMinutes[2] ?? 0,stageMinutes:stageMinutes,sleepStart:start,wake:asleep.last?.end,sleepRating:check?.sleepQuality,nextDayEnergy:check?.energy,restingHR:latestResting,hrv:latestHRV,precedingWorkoutMinutes:recentWorkout.reduce(0) { $0+$1.minutes },precedingWorkoutEffort:effort.isEmpty ? nil : effort.reduce(0,+)/Double(effort.count))
        }
        guard let current = digest(date,0) else { return nil }
        let previous = (1...14).compactMap { offset in calendar.date(byAdding:.day,value:-offset,to:date).flatMap { digest($0,offset) } }
        let earlier = previous.filter { $0.daysAgo <= 14 }
        let target = age <= 0 ? 8 : (age < 13 ? 10.5 : (age < 18 ? 9 : (age >= 65 ? 7.5 : 8)))
        let durationScore = RecoveryEngine.clamp(100-max(0,target-current.hours)*20)
        var components:[(String,Double,Double)] = [("Duración frente a referencia por edad",durationScore,0.5)]
        var basis:[String] = [age > 0 ? "Duración: \(number(current.hours)) h frente a un punto de referencia orientativo de \(number(target)) h; no se penaliza dormir más." : "Configura tu edad para ajustar la referencia de duración; mientras tanto se usa un punto provisional de 8 h."]
        if let rating = current.sleepRating {
            components.append(("Cómo te sentiste al despertar",Double((rating-1)*25),0.3))
            basis.append("Tu valoración al despertar: \(rating)/5.")
        }
        let wakeMinutes = current.wake.map { Double(calendar.component(.hour,from:$0)*60+calendar.component(.minute,from:$0)) }
        let historicalWake = earlier.compactMap { $0.wake.map { Double(calendar.component(.hour,from:$0)*60+calendar.component(.minute,from:$0)) } }
        if historicalWake.count >= 5, let currentWake = wakeMinutes, let medianWake = RecoveryEngine.median(historicalWake) {
            let deviations = historicalWake.map { value in min(abs(value-medianWake),1440-abs(value-medianWake)) }
            let mad = RecoveryEngine.median(deviations) ?? 0
            let offset = abs(currentWake-medianWake)
            let consistency = RecoveryEngine.clamp(100-min(offset,1440-offset)*0.12-mad*0.08)
            components.append(("Regularidad de hora de despertar",consistency,0.2))
            basis.append("Hora de despertar comparada con tu mediana de \(historicalWake.count) noches.")
        } else { basis.append("Aún faltan 5 noches comparables para incluir regularidad.") }
        let weight = components.reduce(0.0) { total,component in total+component.2 }
        let score = Int(RecoveryEngine.clamp(components.reduce(0.0) { total,component in total+component.1*component.2 }/weight).rounded())
        var stages:[SleepStageReview] = []
        for phase in [4,5,3,2] {
            let minutes = current.minutes(phase)
            let values:[Double]
            if phase == 2 { values = earlier.map(\.awakeMinutes) }
            else { values = earlier.compactMap { $0.percent(phase) } }
            let currentValue = phase == 2 ? current.awakeMinutes : (current.percent(phase) ?? 0)
            var comparison = "Sin 5 noches comparables todavía. No existe un umbral fiable para juzgar esta fase solo con un reloj."
            if values.count >= 5, let median = RecoveryEngine.median(values) {
                let delta = currentValue-median
                let unit = phase == 2 ? " min" : " puntos porcentuales"
                let difference = delta
                let tolerance = phase == 2 ? 15.0 : 5.0
                if abs(difference) <= tolerance { comparison = "En tu variación reciente (mediana \(Int(median.rounded()))\(phase == 2 ? " min" : "%")). Esto no confirma suficiencia." }
                else { comparison = "\(difference < 0 ? "Por debajo" : "Por encima") de tu mediana reciente en \(Int(abs(difference).rounded()))\(unit). Es una diferencia descriptiva, no un diagnóstico." }
            }
            stages.append(SleepStageReview(phase:phase,minutes:minutes,percent:phase == 2 ? nil : current.percent(phase),comparison:comparison))
        }
        let confidence = current.sleepRating != nil && earlier.count >= 5 ? "Estimación orientativa · incluye cómo te sentiste y tu patrón reciente" : (current.sleepRating != nil ? "Estimación orientativa · falta más historial para tu patrón" : "Estimación básica · se apoya sobre todo en duración; añade cómo te sentiste al despertar" )
        return SleepQualityAssessment(score:score,confidence:confidence,basis:basis,stages:stages,history:[current]+earlier,durationTarget:target,subjectiveRating:current.sleepRating)
    }
}
struct RecoverySnapshot {
    var now:Date; var sleepHours:Double?; var wake:Date?; var source:String?
    var sleepQuality:SleepQualityAssessment?
    var score:Int?; var confidence:String; var factors:[RecoveryFactor]; var missing:[String]
    var baselineNights:Int; var restingHR:Double?; var hrv:Double?; var vo2:Double?
    var workouts:[WorkoutSummary]; var recentLoad:Double
    var weeklyWorkoutMinutes:Double; var weeklyGoalMinutes:Int; var suggestedMinutes:Int; var maintenanceMinutes:Int; var progressionMinutes:Int
    var activityNote:String
    var sleepTarget:Double; var bedtime:Date; var alarm:Date; var learningPairs:Int
    var caution:Bool; var maxMinutes:Int; var phase:String; var reason:String
    var todayWorkouts:[WorkoutSummary] { workouts.filter { Calendar.current.isDate($0.end,inSameDayAs:now) } }
    var color:Color { guard let score = score else { return .gray }; return score < 45 ? .orange : (score < 70 ? .yellow : .mint) }
}
enum RecoveryEngine {
    static let version = "pulso-recovery-1"
    static func clamp(_ value:Double,_ low:Double = 0,_ high:Double = 100)->Double { min(high,max(low,value)) }
    static func median(_ values:[Double])->Double? {
        let values = values.filter(\.isFinite).sorted(); guard !values.isEmpty else { return nil }
        return values.count % 2 == 1 ? values[values.count/2] : (values[values.count/2-1]+values[values.count/2])/2
    }
    static func ageRange(_ age:Int)->(Double,Double) {
        if age < 13 { return (9,12) }; if age < 18 { return (8,10) }; if age >= 65 { return (7,8) }; return (7,9)
    }
    static func source(_ records:[HealthRecord])->String? {
        let sources = Array(Set(records.map(\.source))).sorted()
        return sources.first(where:{ $0.localizedCaseInsensitiveContains("huawei") }) ?? sources.first
    }
    static func night(_ records:[HealthRecord],date:Date,source:String?)->(hours:Double?,wake:Date?,segments:[SleepSegment]) {
        let window = nightWindow(date)
        let segments = resolvedSleep(records.filter { $0.source == source },from:window.0,to:window.1)
        let asleep = segments.filter { $0.phase != 2 }
        let seconds = asleep.reduce(0) { $0+$1.end.timeIntervalSince($1.start) }
        return (seconds > 0 ? seconds/3600 : nil,asleep.last?.end,segments)
    }
    static func alarm(profile:CoachProfile,now:Date)->Date {
        let calendar = Calendar.current
        let tomorrow = calendar.date(byAdding:.day,value:1,to:calendar.startOfDay(for:now))!
        if let override = profile.tomorrowOverride, calendar.isDate(override,inSameDayAs:tomorrow) { return override }
        let minutes = profile.scheduledDays.contains(calendar.component(.weekday,from:tomorrow)) ? profile.regularWake : profile.freeWake
        return calendar.date(bySettingHour:minutes/60,minute:minutes%60,second:0,of:tomorrow)!
    }
    static func effortScore(_ rpe:Double)->Int { Int(clamp(rpe*10)) }
    static func load(_ workout:WorkoutSummary,ratings:[String:Double])->Double? {
        guard let rpe = ratings[workout.id] else { return nil }
        return workout.minutes*clamp(rpe,0,10)
    }
    static func snapshot(results:[String:MetricResult],profile:CoachProfile,checks:[DailyCheck],ratings:[String:Double],now:Date)->RecoverySnapshot {
        let calendar = Calendar.current
        let records = results["SleepAnalysis"]?.sleepRecords ?? results["SleepAnalysis"]?.records ?? []
        let source = self.source(records)
        let today = night(records,date:now,source:source)
        let nights = (1...28).compactMap { offset -> (Date,Double)? in
            let date = calendar.date(byAdding:.day,value:-offset,to:now)!
            guard let hours = night(records,date:date,source:source).hours, hours >= 3, hours <= 14 else { return nil }
            return (calendar.startOfDay(for:date),hours)
        }
        let ageRange = self.ageRange(profile.age)
        let todayCheck = checks.last { calendar.isDate($0.date,inSameDayAs:now) }
        let workouts = (results["Workout"]?.workouts ?? []).filter { $0.end <= now && $0.end > now.addingTimeInterval(-30*86400) }
        let sleepQuality = SleepQualityEngine.assess(records:records,date:now,source:source,age:profile.age,checks:checks,workouts:workouts,ratings:ratings,resting:results["RestingHeartRate"]?.days ?? [],hrv:results["HeartRateVariabilitySDNN"]?.days ?? [])
        let recent = workouts.filter { $0.end > now.addingTimeInterval(-36*3600) }
        let recentLoad = recent.compactMap { load($0,ratings:ratings) }.reduce(0,+)
        let usualLoads = workouts.filter { $0.end < now.addingTimeInterval(-36*3600) }.compactMap { load($0,ratings:ratings) }
        // Learn an association only from mornings the user actually rated. No causal claim.
        let pairs = nights.compactMap { date,hours -> Double? in
            guard let check = checks.first(where:{ calendar.isDate($0.date,inSameDayAs:date) }), check.energy >= 4, !check.unwell, let wake = night(records,date:date,source:source).wake, (0...7200).contains(check.date.timeIntervalSince(wake)) else { return nil }
            return hours
        }
        let learned = pairs.count >= 7 ? median(pairs) : nil
        var target = clamp(learned ?? (profile.age < 18 ? 9 : 8),ageRange.0,ageRange.1)
        if let check = todayCheck, check.energy <= 2 { target += 0.25 }
        if let usual = median(usualLoads), recentLoad > usual*1.5 { target += 0.25 }
        target = clamp(target,ageRange.0,ageRange.1)
        var factors:[RecoveryFactor] = []; var missing:[String] = []
        let sleepQuery = results["SleepAnalysis"]
        let freshSleep = today.hours != nil && sleepQuery?.error == nil && sleepQuery.map { now.timeIntervalSince($0.checked) < 6*3600 } == true && today.wake.map { now.timeIntervalSince($0) >= 0 && now.timeIntervalSince($0) < 24*3600 } == true
        if let hours = today.hours, freshSleep {
            let duration = clamp(100 - max(0,target-hours)*25)
            factors.append(RecoveryFactor(id:"sleep",title:"Duración del sueño",value:duration,weight:0.55,detail:"\(sleepDuration(hours*3600)) frente a un objetivo orientativo de \(number(target)) h"))
        } else { missing.append("Sueño reciente de la noche terminada hoy") }
        let priorHours = nights.map { $0.1 }
        if priorHours.count >= 7, let middle = median(priorHours) {
            let deviations = priorHours.map { abs($0-middle) }
            factors.append(RecoveryFactor(id:"regularity",title:"Regularidad de duración",value:clamp(100-(median(deviations) ?? 0)*35),weight:0.1,detail:"\(nights.count) noches de la misma fuente; no mide por sí sola la calidad del sueño"))
        } else { missing.append("7 noches para regularidad") }
        func cardio(_ key:String,title:String,weight:Double,reverse:Bool)->Double? {
            let result = results[key]
            let days = result?.days ?? []
            let latest = days.filter { $0.date <= now && $0.date >= calendar.startOfDay(for:now).addingTimeInterval(-86400) }.last
            let baseline = days.filter { $0.date < calendar.startOfDay(for:now).addingTimeInterval(-86400) }.map(\.value)
            guard let latest = latest, let base = median(baseline), baseline.count >= 7, base > 0, result?.error == nil, result?.sources.count == 1 else { missing.append(title+": falta lectura reciente, fuente única o base de 7 días"); return nil }
            let delta = (latest.value-base)/base
            let value = clamp(75 + (reverse ? -1 : 1)*delta*180)
            factors.append(RecoveryFactor(id:key,title:title,value:value,weight:weight,detail:"\(number(latest.value)) frente a mediana personal \(number(base)). Promedios diarios, no necesariamente nocturnos."))
            return latest.value
        }
        let rhr = cardio("RestingHeartRate",title:"Pulso en reposo",weight:0.2,reverse:true)
        let hrv = cardio("HeartRateVariabilitySDNN",title:"VFC (SDNN)",weight:0.1,reverse:false)
        if let usual = median(usualLoads), usual > 0, usualLoads.count >= 3 {
            factors.append(RecoveryFactor(id:"load",title:"Carga reciente declarada",value:clamp(100-recentLoad/usual*25),weight:0.05,detail:"Minutos × esfuerzo percibido. No equivale a una medición fisiológica de fatiga."))
        } else { missing.append("3 entrenamientos valorados para comparar carga") }
        let coverage = factors.reduce(0) { $0+$1.weight }
        var score:Int? = nil
        if freshSleep, profile.completed, profile.age >= 6, coverage > 0 {
            score = Int(clamp(factors.reduce(0) { $0+$1.value*$1.weight }/coverage).rounded())
        }
        let caution = profile.limitedExercise || todayCheck?.unwell == true || (todayCheck?.soreness ?? 0) >= 4 || (todayCheck?.energy ?? 5) <= 1
        let low = score.map { $0 < 45 } ?? false
        let heavy = recentLoad > max(180,(median(usualLoads) ?? 200)*1.5)
        var cap = min(profile.availableMinutes,low || heavy ? 15 : (profile.fitnessGoal == "Mejorar" ? 45 : 30))
        if caution || !profile.completed || profile.age < 18 || score == nil { cap = 0 }
        let timeAwake = today.wake.map { now.timeIntervalSince($0) }
        let morning = timeAwake.map { $0 >= 0 && $0 < 7200 } ?? false
        let todayWorkouts = workouts.filter { calendar.isDate($0.end,inSameDayAs:now) }
        let weeklyWorkouts = workouts.filter { $0.end > now.addingTimeInterval(-7*86400) }
        let weeklyMinutes = weeklyWorkouts.reduce(0) { $0+$1.minutes }
        let weeklyGoal = profile.age < 18 ? 420 : 150
        var maintenance = 0
        var progression = 0
        if !caution && todayWorkouts.isEmpty {
            if low || heavy {
                maintenance = profile.age < 18 ? 20 : 15
                progression = maintenance
            } else if profile.age < 18 {
                maintenance = weeklyWorkouts.count >= 5 ? 20 : 30
                progression = weeklyWorkouts.count >= 5 ? 25 : 40
            } else if profile.age >= 65 {
                maintenance = weeklyWorkouts.count >= 4 ? 20 : 25
                progression = weeklyWorkouts.count >= 4 ? 25 : 35
            } else {
                maintenance = weeklyWorkouts.count >= 5 ? 20 : 25
                progression = weeklyWorkouts.count >= 5 ? 30 : 40
            }
            maintenance = min(profile.availableMinutes,maintenance)
            progression = min(profile.availableMinutes,progression)
        }
        let suggested = profile.fitnessGoal == "Mejorar" ? progression : maintenance
        let activityNote = caution ? "Tus sensaciones o limitaciones aconsejan descanso o movimiento solo si te resulta cómodo." : (!todayWorkouts.isEmpty ? "Ya aparece un entrenamiento hoy; una segunda sesión no es necesaria para progresar." : (heavy ? "La carga reciente que has valorado es alta frente a tu historial; hoy conviene priorizar recuperación." : (low ? "La recuperación estimada está baja; elige una opción corta y suave, o descansa." : (score == nil ? "Faltan datos para personalizar por recuperación; esta propuesta usa edad, agenda y tu preferencia, no confirma que hayas estado inactivo." : "Propuesta ajustada a tu edad, objetivo y entrenamientos visibles. Adáptala a cómo te encuentres."))))
        let hour = calendar.component(.hour,from:now)
        let phase = morning ? "morning" : ((!todayWorkouts.isEmpty || hour >= 19 || caution || heavy || low) ? "evening" : "activity")
        let alarm = self.alarm(profile:profile,now:now)
        let bedtime = alarm.addingTimeInterval(-(target*3600+20*60))
        let reason = caution ? "Hoy conviene priorizar cómo te encuentras y evitar intensificar." : (!todayWorkouts.isEmpty ? "Ya hay una sesión registrada hoy; puedes dar prioridad a la recuperación." : (score == nil ? "Faltan datos recientes para estimar tu recuperación." : (heavy ? "Tu carga declarada reciente es mayor que la habitual." : (low ? "Las señales disponibles favorecen una jornada suave." : "Una sesión cómoda puede encajar hoy, según tus sensaciones."))))
        let confidence = nights.count < 7 || coverage < 0.8 ? "Provisional · cobertura limitada" : "Tendencia personal · estimación experimental"
        let vo2 = results["VO2Max"].flatMap { result -> Double? in
            guard let date = result.date, now.timeIntervalSince(date) < 30*86400, result.error == nil else { return nil }; return result.value
        }
        return RecoverySnapshot(now:now,sleepHours:today.hours,wake:today.wake,source:source,sleepQuality:sleepQuality,score:score,confidence:confidence,factors:factors,missing:missing,baselineNights:nights.count,restingHR:rhr,hrv:hrv,vo2:vo2,workouts:workouts,recentLoad:recentLoad,weeklyWorkoutMinutes:weeklyMinutes,weeklyGoalMinutes:weeklyGoal,suggestedMinutes:suggested,maintenanceMinutes:maintenance,progressionMinutes:progression,activityNote:activityNote,sleepTarget:target,bedtime:bedtime,alarm:alarm,learningPairs:pairs.count,caution:caution,maxMinutes:cap,phase:phase,reason:reason)
    }
}

struct CoachPlan:Codable {
    var title:String; var duration_minutes:Int; var intensity:String; var steps:[String]
}
struct CoachAdvice:Codable {
    var headline:String; var interpretation:String; var factors:[String]
    var minimum_plan:CoachPlan; var progression_plan:CoachPlan
    var sleep_advice:String; var limitations:String
    var sleep_insight:String? = nil
    var sleep_actions:[String]? = nil
}
struct SavedAdvice:Codable {
    var date:Date; var fingerprint:String; var advice:CoachAdvice
}
struct RecoveryHistoryEntry:Codable,Identifiable {
    var date:Date; var score:Int; var confidence:String
    var id:Date { date }
}
enum CoachFailure:LocalizedError {
    case message(String)
    var errorDescription:String? { if case let .message(text) = self { return text }; return nil }
}
enum CoachKeychain {
    static func bundledKey(_ info:[String:Any])->(id:String,key:String)? {
        guard let id = info["PulsoPersonalKeyID"] as? String, !id.isEmpty,
              let raw = info["PulsoPersonalAPIKey"] as? String else { return nil }
        let key = raw.trimmingCharacters(in:.whitespacesAndNewlines)
        guard key.hasPrefix("sk-"), key.count > 20, !key.contains(where:{$0.isWhitespace}) else { return nil }
        return (id,key)
    }
    static func importPersonalKey(defaults:UserDefaults) throws {
        guard let seed = bundledKey(Bundle.main.infoDictionary ?? [:]) else { return }
        let marker = "coach.imported.personal-key.\(seed.id)"
        guard !defaults.bool(forKey:marker) else { return }
        try write(seed.key)
        defaults.set(true,forKey:marker)
    }
    private static var query:[String:Any] { [kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:"com.si002.pruebasalud.openai",kSecAttrAccount as String:"personal-key"] }
    static func read()->String? {
        var query = Self.query; query[kSecReturnData as String] = true; query[kSecMatchLimit as String] = kSecMatchLimitOne
        var result:CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary,&result) == errSecSuccess, let data = result as? Data else { return nil }
        return String(data:data,encoding:.utf8)
    }
    static func write(_ key:String)throws {
        let data = Data(key.utf8)
        let status = SecItemUpdate(query as CFDictionary,[kSecValueData as String:data] as CFDictionary)
        if status == errSecItemNotFound {
            var query = Self.query; query[kSecValueData as String] = data; query[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
            guard SecItemAdd(query as CFDictionary,nil) == errSecSuccess else { throw CoachFailure.message("No se pudo guardar en el llavero.") }; return
        }
        guard status == errSecSuccess else { throw CoachFailure.message("No se pudo actualizar el llavero.") }
    }
    static func delete() { SecItemDelete(query as CFDictionary) }
}

@MainActor final class CoachStore:ObservableObject {
    @Published var profile = CoachProfile()
    @Published var checks:[DailyCheck] = []
    @Published var ratings:[String:Double] = [:]
    @Published var advice:SavedAdvice?
    @Published var busy = false
    @Published var error:String?
    @Published var hasKey = false
    @Published var consent = false
    @Published var requestsToday = 0
    @Published var history:[RecoveryHistoryEntry] = []
    private let defaults:UserDefaults
    private var storage:URL?
    struct Archive:Codable { var profile:CoachProfile; var checks:[DailyCheck]; var ratings:[String:Double]; var advice:SavedAdvice?; var history:[RecoveryHistoryEntry]? = nil }
    init(preview:Bool = false,defaults:UserDefaults = .standard,storage:URL? = nil) {
        self.defaults = defaults
        if preview {
            profile.completed = true; profile.age = 25
            checks = [DailyCheck(date:Date(),energy:4,soreness:1,unwell:false)]
            ratings = Dictionary(uniqueKeysWithValues:(0..<8).map { ("demo-workout-\($0)",Double(3+$0%3)) })
            return
        }
        let folder = FileManager.default.urls(for:.applicationSupportDirectory,in:.userDomainMask).first!
        self.storage = storage ?? folder.appendingPathComponent("coach-private.json")
        if let data = try? Data(contentsOf:self.storage!), let saved = try? JSONDecoder().decode(Archive.self,from:data) {
            profile = saved.profile; checks = saved.checks; ratings = saved.ratings; advice = saved.advice; history = saved.history ?? []
        }
        consent = defaults.bool(forKey:"coach.openai.consent")
        do { try CoachKeychain.importPersonalKey(defaults:defaults) }
        catch { self.error = "No se pudo importar la clave personal al llavero. Puedes introducirla en IA y privacidad." }
        hasKey = CoachKeychain.read() != nil
        requestsToday = defaults.string(forKey:"coach.request.day") == dayKey(Date()) ? defaults.integer(forKey:"coach.request.count") : 0
    }
    func persist() {
        guard let storage = storage else { return }
        do {
            try FileManager.default.createDirectory(at:storage.deletingLastPathComponent(),withIntermediateDirectories:true)
            let value = Archive(profile:profile,checks:checks,ratings:ratings,advice:advice,history:history)
            try JSONEncoder().encode(value).write(to:storage,options:[.atomic,.completeFileProtection])
            var url = storage; var resources = URLResourceValues(); resources.isExcludedFromBackup = true; try url.setResourceValues(resources)
        } catch { self.error = "No se pudieron guardar tus ajustes personales." }
    }
    func check(energy:Int,soreness:Int,unwell:Bool,sleepQuality:Int? = nil,now:Date = Date()) {
        checks.removeAll { Calendar.current.isDate($0.date,inSameDayAs:now) }
        checks.append(DailyCheck(date:now,energy:energy,soreness:soreness,unwell:unwell,sleepQuality:sleepQuality)); checks = Array(checks.suffix(90)); persist()
    }
    func recordSnapshot(_ s:RecoverySnapshot) {
        guard storage != nil, let score = s.score else { return }
        let day = Calendar.current.startOfDay(for:s.now)
        if let old = history.first(where:{ $0.date == day }), old.score == score, old.confidence == s.confidence { return }
        history.removeAll { $0.date == day }
        history.append(RecoveryHistoryEntry(date:day,score:score,confidence:s.confidence))
        history = Array(history.sorted { $0.date < $1.date }.suffix(90)); persist()
    }
    func setConsent(_ enabled:Bool) { consent = enabled; defaults.set(enabled,forKey:"coach.openai.consent"); if !enabled { advice = nil; persist() } }
    func saveKey(_ key:String) {
        let key = key.trimmingCharacters(in:.whitespacesAndNewlines)
        guard !key.isEmpty, !key.contains(where:{$0.isWhitespace}) else { error = "Introduce una clave válida sin espacios."; return }
        do { try CoachKeychain.write(key); hasKey = true; error = nil } catch { self.error = error.localizedDescription }
    }
    func deleteKey() { CoachKeychain.delete(); hasKey = false; setConsent(false) }
    func dayKey(_ date:Date)->String { let c = Calendar.current.dateComponents([.year,.month,.day],from:date); return "\(c.year!)-\(c.month!)-\(c.day!)" }
}

enum CoachAPI {
    static let model = "gpt-6-luna"
    static let effort = "max"
    static func intensities(_ maxMinutes:Int)->[String] { maxMinutes == 0 ? ["rest"] : (maxMinutes <= 15 ? ["rest","easy"] : ["rest","easy","moderate"]) }
    static func payload(snapshot:RecoverySnapshot,profile:CoachProfile,checks:[DailyCheck],ratings:[String:Double])->[String:Any] {
        var payload:[String:Any] = ["algorithm":RecoveryEngine.version,"age":profile.age,"context":snapshot.phase,"confidence":snapshot.confidence,"missing":snapshot.missing,"max_workout_minutes":snapshot.maxMinutes,"caution":snapshot.caution,"sleep_target_hours":snapshot.sleepTarget,"bedtime_local":coachTime(snapshot.bedtime),"wake_local":coachTime(snapshot.alarm),"available_minutes":profile.availableMinutes,"preferred_activity":profile.usualActivity,"fitness_goal":profile.fitnessGoal,"weekly_activity_reference_minutes":snapshot.weeklyGoalMinutes,"recorded_workout_minutes_last_7_days":snapshot.weeklyWorkoutMinutes,"suggested_local_minutes":snapshot.suggestedMinutes,"maintenance_minutes":snapshot.maintenanceMinutes,"progression_minutes":snapshot.progressionMinutes,"learning_pairs":snapshot.learningPairs,"baseline_nights":snapshot.baselineNights]
        if let score = snapshot.score { payload["recovery_estimate_not_validated"] = score }
        if let sleep = snapshot.sleepHours { payload["sleep_hours"] = sleep }
        if let hr = snapshot.restingHR { payload["resting_hr_daily"] = hr }
        if let hrv = snapshot.hrv { payload["hrv_sdnn_daily"] = hrv }
        if let vo2 = snapshot.vo2 { payload["latest_vo2max"] = vo2 }
        if let check = checks.last(where:{ Calendar.current.isDate($0.date,inSameDayAs:snapshot.now) }) {
            var selfReport:[String:Any] = ["energy_1_to_5":check.energy,"soreness_0_to_5":check.soreness,"feels_unwell":check.unwell]
            if let rating = check.sleepQuality { selfReport["sleep_quality_1_to_5"] = rating }
            payload["self_report"] = selfReport
        }
        if let sleep = snapshot.sleepQuality {
            payload["sleep_quality_score_experimental"] = sleep.score
            payload["sleep_quality_confidence"] = sleep.confidence
            payload["sleep_quality_basis"] = sleep.basis
            payload["sleep_stage_estimates"] = sleep.stages.map { stage in
                let phaseName = [2:"awake",3:"light_or_core",4:"deep",5:"REM"][stage.phase] ?? "unclassified"
                var item:[String:Any] = ["phase":stage.phase,"phase_name":phaseName,"minutes":stage.minutes,"personal_comparison":stage.comparison]
                if let percent = stage.percent { item["percent_of_asleep"] = percent }
                else { item["percent_of_asleep"] = NSNull() }
                return item
            }
            payload["sleep_history"] = sleep.history.map { night -> [String:Any] in
                var entry:[String:Any] = ["days_ago":night.daysAgo,"sleep_hours":night.hours,"awake_minutes":night.awakeMinutes,"preceding_workout_minutes":night.precedingWorkoutMinutes]
                for (key,phase) in [("light_percent",3),("deep_percent",4),("rem_percent",5)] { if let value = night.percent(phase) { entry[key] = value } }
                if let wake = night.wake { entry["wake_local"] = coachTime(wake) }
                if let start = night.sleepStart { entry["bedtime_local"] = coachTime(start) }
                if let rating = night.sleepRating { entry["sleep_self_rating_1_to_5"] = rating }
                if let energy = night.nextDayEnergy { entry["next_day_energy_1_to_5"] = energy }
                if let hr = night.restingHR { entry["resting_hr_daily"] = hr }
                if let value = night.hrv { entry["hrv_sdnn_daily"] = value }
                if let effort = night.precedingWorkoutEffort { entry["preceding_workout_effort_0_to_10"] = effort }
                return entry
            }
        }
        payload["factors"] = snapshot.factors.map { ["name":$0.title,"value":$0.value,"detail":$0.detail] as [String:Any] }
        payload["recent_workouts"] = snapshot.workouts.sorted { $0.end > $1.end }.prefix(12).map { workout -> [String:Any] in
            var entry:[String:Any] = ["activity":workout.activity,"days_ago":max(0,Int(snapshot.now.timeIntervalSince(workout.end)/86400)),"minutes":workout.minutes]
            if let rating = ratings[workout.id] { entry["perceived_effort_0_to_10"] = rating }
            if let hr = workout.averageHR { entry["average_hr"] = hr }
            return entry
        }
        return payload
    }
    static func fingerprint(_ payload:[String:Any])throws->String {
        let data = try JSONSerialization.data(withJSONObject:payload,options:[.sortedKeys])
        return SHA256.hash(data:data).map { String(format:"%02x",$0) }.joined()
    }
    static func request(key:String,payload:[String:Any],maxMinutes:Int,minimumMinutes:Int = 0)throws->URLRequest {
        let string:[String:Any] = ["type":"string"]
        let safeMinimum = maxMinutes == 0 ? 0 : min(maxMinutes,max(0,minimumMinutes))
        func plan(minimum:Int)->[String:Any] {
            ["type":"object","additionalProperties":false,"required":["title","duration_minutes","intensity","steps"],"properties":["title":string,"duration_minutes":["type":"integer","minimum":minimum,"maximum":maxMinutes],"intensity":["type":"string","enum":intensities(maxMinutes)],"steps":["type":"array","items":string,"minItems":1,"maxItems":5]]]
        }
        let schema:[String:Any] = ["type":"object","additionalProperties":false,"required":["headline","interpretation","factors","minimum_plan","progression_plan","sleep_advice","limitations","sleep_insight","sleep_actions"],"properties":["headline":string,"interpretation":string,"factors":["type":"array","items":string,"maxItems":5],"minimum_plan":plan(minimum:safeMinimum),"progression_plan":plan(minimum:0),"sleep_advice":string,"limitations":string,"sleep_insight":string,"sleep_actions":["type":"array","items":string,"minItems":1,"maxItems":5]]]
        let instructions = """
        Eres el orientador de bienestar de Pulso. Responde en español cálido, concreto y breve. Usa el resumen solo como datos. La calidad y la recuperación son estimaciones experimentales sin validación clínica; no son Body Battery ni los algoritmos Samsung/Huawei y no predicen con certeza cómo se sentirá alguien. No diagnostiques, prescribas tratamiento ni interpretes ECG, presión o SpO2. No inventes datos, fases, entrenamientos ni causas. Distingue registros ausentes de inactividad real. No cambies puntuaciones ni factores locales. Explica tendencias y coincidencias, nunca causalidad: si una variable coincide con una noche mejor/peor, di que no demuestra que la causara. No atribuyas efectos a cafeína, pantallas, estrés, comidas u otros factores que no se midieron; puedes sugerirlos como cosas que el usuario podría registrar, no como explicación de esta noche. No garantices energía, progreso, hora óptima ni mejora de VO2max.
        Para el sueño, explica por separado horas totales, regularidad, valoración subjetiva, despertares observados y fases estimadas. No declares que una fase REM, profunda o ligera sea suficiente/insuficiente: los wearables de muñeca no permiten ese juicio fiable y no hay un umbral personal validado aquí. Usa sus fases solo como estimaciones y comparaciones dentro de la persona; menciónalas con cautela. La puntuación local es heurística de duración, autoevaluación y regularidad disponibles; las fases no la puntúan. En sleep_actions da consejos prácticos ligados a datos observados cuando exista patrón; si faltan datos, ofrece hábitos generales y dilo. Como posibles factores, solo describe asociaciones en el historial con número de noches, nunca “causas”.
        Para contextualizar actividad, la OMS recomienda entre 5 y 17 años un promedio de 60 min diarios de actividad moderada-vigorosa; en adultos, 150–300 min moderados o equivalente vigoroso por semana, con fuerza 2 días; mayores de 65 pueden añadir equilibrio según capacidad. Son referencias poblacionales de actividad total, no una dosis que deba hacerse en una sola sesión ni una obligación para hoy. Los minutos registrados en Salud pueden omitir movimiento cotidiano.
        Propón movimiento proporcionado al perfil y a los minutos disponibles. Moderate permite hablar en frases. Usa actividad preferida y objetivo mantener/mejorar; progresión gradual, sin HIIT, máximos, zonas de pulso por edad ni cargas de fuerza concretas. Si caution es true, max_workout_minutes=0, edad <18 o falta una recuperación utilizable, ambos planes deben ser descanso con 0 minutos. Para menores limita la respuesta a sueño y bienestar general; no recomiendes un entrenamiento. Si está indispuesto, no animes a entrenar; ante síntomas de alarma, parar y buscar asistencia adecuada, sin diagnosticar. No uses puntuación alta como permiso para intensificar. Si hay pocos datos, dilo. No castigues el descanso. Nunca afirmes que una nueva muestra VO2max prueba mejora causada por una sesión. Limita cada explicación a 2-3 frases y cada paso a una frase.
        """
        let text = String(data:try JSONSerialization.data(withJSONObject:payload,options:[.sortedKeys]),encoding:.utf8)!
        let body:[String:Any] = ["model":model,"reasoning":["effort":effort],"store":false,"max_output_tokens":12000,"instructions":instructions,"input":text,"text":["format":["type":"json_schema","name":"pulso_wellness","strict":true,"schema":schema]]]
        var request = URLRequest(url:URL(string:"https://api.openai.com/v1/responses")!)
        request.httpMethod = "POST"; request.timeoutInterval = 180
        request.setValue("Bearer "+key,forHTTPHeaderField:"Authorization")
        request.setValue("application/json",forHTTPHeaderField:"Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject:body)
        return request
    }
    static func decode(_ data:Data,maxMinutes:Int,minimumMinutes:Int = 0)throws->CoachAdvice {
        guard let object = try JSONSerialization.jsonObject(with:data) as? [String:Any], object["status"] as? String == "completed" else { throw CoachFailure.message("La IA no completó la respuesta. Se mantiene la orientación local; no se reintentará automáticamente.") }
        let output = object["output"] as? [[String:Any]] ?? []
        let content = output.flatMap { $0["content"] as? [[String:Any]] ?? [] }
        guard !content.contains(where:{ $0["type"] as? String == "refusal" }), let text = content.first(where:{ $0["type"] as? String == "output_text" })?["text"] as? String, let json = text.data(using:.utf8) else { throw CoachFailure.message("No se recibió una orientación utilizable.") }
        let advice = try JSONDecoder().decode(CoachAdvice.self,from:json)
        for (index,plan) in [advice.minimum_plan,advice.progression_plan].enumerated() {
            let minAllowed = index == 0 && maxMinutes > 0 ? min(maxMinutes,max(0,minimumMinutes)) : 0
            guard (minAllowed...maxMinutes).contains(plan.duration_minutes), intensities(maxMinutes).contains(plan.intensity), plan.intensity != "rest" || plan.duration_minutes == 0, !plan.steps.isEmpty, plan.steps.count <= 5 else { throw CoachFailure.message("La propuesta no cumple los límites de actividad de hoy y no se mostrará.") }
        }
        return advice
    }
}
extension CoachStore {
    func analyze(snapshot:RecoverySnapshot) async {
        guard !busy else { return }
        guard consent, let key = CoachKeychain.read() else { error = "Configura tu nueva clave y autoriza el envío del resumen a OpenAI."; return }
        guard profile.completed, profile.age >= 13 else { error = "La orientación IA está disponible desde los 13 años con el perfil completado. Las recomendaciones locales siguen disponibles."; return }
        do {
            let payload = CoachAPI.payload(snapshot:snapshot,profile:profile,checks:checks,ratings:ratings)
            let fingerprint = try CoachAPI.fingerprint(payload)
            if let advice = advice, advice.fingerprint == fingerprint, Calendar.current.isDateInToday(advice.date) { error = "Ya tienes un análisis de este resumen. Se reutiliza para evitar gasto."; return }
            if defaults.string(forKey:"coach.request.day") != dayKey(Date()) { requestsToday = 0 }
            guard requestsToday < 3 else { error = "Límite local de 3 solicitudes al día alcanzado. La orientación local sigue disponible."; return }
            let minimum = snapshot.maxMinutes == 0 ? 0 : min(snapshot.maxMinutes,max(15,snapshot.suggestedMinutes))
            let request = try CoachAPI.request(key:key,payload:payload,maxMinutes:snapshot.maxMinutes,minimumMinutes:minimum)
            requestsToday += 1; defaults.set(dayKey(Date()),forKey:"coach.request.day"); defaults.set(requestsToday,forKey:"coach.request.count")
            busy = true; error = nil
            defer { busy = false }
            let config = URLSessionConfiguration.ephemeral
            config.urlCache = nil; config.timeoutIntervalForRequest = 180; config.timeoutIntervalForResource = 210
            let session = URLSession(configuration:config)
            defer { session.finishTasksAndInvalidate() }
            let (data,response) = try await session.data(for:request)
            guard let response = response as? HTTPURLResponse else { throw CoachFailure.message("Respuesta de red no válida.") }
            guard response.statusCode == 200 else {
                let messages = [401:"Clave no válida o revocada. Sustitúyela en el llavero.",403:"Tu proyecto no tiene acceso a este recurso.",404:"gpt-6-luna no está disponible para esta cuenta. No se ha sustituido el modelo.",429:"Límite de uso o saldo de la API alcanzado."]
                throw CoachFailure.message(messages[response.statusCode] ?? "OpenAI no completó la solicitud (HTTP \(response.statusCode)).")
            }
            let value = try CoachAPI.decode(data,maxMinutes:snapshot.maxMinutes,minimumMinutes:minimum)
            // Disabling consent while a request is running must not retain its response.
            guard consent else { return }
            advice = SavedAdvice(date:Date(),fingerprint:fingerprint,advice:value); persist()
        } catch is CancellationError { error = "Análisis cancelado." }
        catch { self.error = (error as? CoachFailure)?.localizedDescription ?? "No se pudo completar el análisis. Revisa la conexión o inténtalo después; no se ha generado una respuesta de ejemplo." }
    }
}

struct RecoveryRing:View {
    let score:Int?; let color:Color
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var progress:Double = 0
    var body:some View {
        ZStack {
            Circle().stroke(color.opacity(0.12),lineWidth:12)
            Circle().trim(from:0,to:progress).stroke(AngularGradient(colors:[color.opacity(0.4),color,color],center:.center),style:StrokeStyle(lineWidth:12,lineCap:.round)).rotationEffect(.degrees(-90))
            VStack(spacing:1) { Text(score.map(String.init) ?? "—").font(.system(size:38,weight:.semibold,design:.rounded)).monospacedDigit(); Text("de 100").font(.caption).foregroundStyle(.secondary) }
        }.frame(width:116,height:116).padding(6)
            .accessibilityElement(children:.ignore).accessibilityLabel(score.map { "Recuperación estimada \($0) de 100" } ?? "Recuperación sin estimar")
            .onAppear { animate() }.onChange(of:score) { _ in animate() }
    }
    private func animate() { withAnimation(reduceMotion ? nil : .easeOut(duration:1.1)) { progress = Double(score ?? 0)/100 } }
}
struct RevealChart:ViewModifier {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var visible = false
    func body(content:Content)->some View {
        content.opacity(visible ? 1 : 0).scaleEffect(x:1,y:visible || reduceMotion ? 1 : 0.08,anchor:.bottom)
            .onAppear { withAnimation(reduceMotion ? nil : .easeOut(duration:0.65)) { visible = true } }
    }
}
struct CoachPanel<Content:View>:View {
    var color:Color = .mint
    @ViewBuilder var content:()->Content
    var body:some View { VStack(alignment:.leading,spacing:16,content:content).frame(maxWidth:.infinity,alignment:.leading).padding(22).background(LinearGradient(colors:[color.opacity(0.13),.white.opacity(0.035)],startPoint:.topLeading,endPoint:.bottomTrailing),in:RoundedRectangle(cornerRadius:28)) }
}
struct CoachHome:View {
    @EnvironmentObject var model:HealthDashboard
    @EnvironmentObject var coach:CoachStore
    @State private var profileSheet = false
    @State private var checkSheet = false
    @State private var aiSheet = false
    private func clock(_ actual:Date)->Date {
        #if targetEnvironment(simulator)
        if CommandLine.arguments.contains("--preview-morning") { return Calendar.current.date(bySettingHour:8,minute:0,second:0,of:actual)! }
        if CommandLine.arguments.contains("--preview-evening") { return Calendar.current.date(bySettingHour:20,minute:0,second:0,of:actual)! }
        #endif
        return actual
    }
    var body:some View {
        TimelineView(.periodic(from:.now,by:60)) { context in
            let snapshot = RecoveryEngine.snapshot(results:model.results,profile:coach.profile,checks:coach.checks,ratings:coach.ratings,now:clock(context.date))
            VStack(alignment:.leading,spacing:18) {
                if !coach.profile.completed {
                    CoachPanel { Label("Un plan que encaje contigo",systemImage:"sparkles").font(.title2.bold()); Text("Cuéntame tu edad, tus horarios y cuánto tiempo tienes. Tus registros seguirán disponibles mientras tanto.").foregroundStyle(.secondary); Button("Personalizar mi día") { profileSheet = true }.buttonStyle(.borderedProminent) }
                } else {
                    HStack { Button { checkSheet = true } label:{ Label("Cómo me encuentro",systemImage:"face.smiling") }; Spacer(); Button { profileSheet = true } label:{ Image(systemName:"slider.horizontal.3") }.accessibilityLabel("Editar horarios y perfil") }.font(.subheadline)
                    if snapshot.phase == "morning" { morning(snapshot) }
                    else if snapshot.phase == "activity" { activity(snapshot) }
                    else {
                        HStack { Image(systemName:snapshot.todayWorkouts.isEmpty ? "leaf.fill" : "checkmark.circle.fill").foregroundStyle(.mint); Text(snapshot.todayWorkouts.isEmpty ? "Hoy, recuperación y movimiento cómodo" : "\(snapshot.todayWorkouts.count) entrenamiento(s) visible(s) hoy").font(.subheadline) }.padding(14).frame(maxWidth:.infinity,alignment:.leading).background(.white.opacity(0.05),in:RoundedRectangle(cornerRadius:18))
                        bedtime(snapshot)
                    }
                    recovery(snapshot)
                    NavigationLink { CoachJourney().environmentObject(coach) } label:{ Label("Ver mi plan, progreso y descanso",systemImage:"chart.xyaxis.line").frame(maxWidth:.infinity).padding(14) }.buttonStyle(.bordered)
                    ai(snapshot)
                }
            }.onAppear { coach.recordSnapshot(snapshot) }.onChange(of:snapshot.score) { _ in coach.recordSnapshot(snapshot) }
        }.sheet(isPresented:$profileSheet) { CoachProfileView().environmentObject(coach) }
            .sheet(isPresented:$checkSheet) { DailyCheckView().environmentObject(coach) }
            .sheet(isPresented:$aiSheet) { CoachAISettings().environmentObject(coach).environmentObject(model) }
    }
    private func recovery(_ s:RecoverySnapshot)->some View {
        CoachPanel(color:s.color) {
            HStack(alignment:.center,spacing:20) {
                RecoveryRing(score:s.score,color:s.color)
                VStack(alignment:.leading,spacing:8) {
                    Text("RECUPERACIÓN").font(.caption.bold()).tracking(1.3).foregroundStyle(s.color)
                    Text(s.caution ? "Tus sensaciones primero" : (s.score.map { $0 < 45 ? "Baja la marcha" : ($0 < 70 ? "Busca equilibrio" : "Buen punto de partida") } ?? "Escuchemos tus datos")).font(.title3.bold())
                    Text(s.confidence).font(.caption).foregroundStyle(.secondary)
                }
            }
            Text(s.reason).font(.subheadline)
            NavigationLink("Qué influye en mi puntuación") { RecoveryExplanation(snapshot:s) }
            Text("Estimación propia de Pulso. No mide energía real ni garantiza cómo te sentirás.").font(.caption).foregroundStyle(.secondary)
        }
    }
    private func morning(_ s:RecoverySnapshot)->some View {
        CoachPanel(color:.indigo) {
            Label("TUS PRIMERAS DOS HORAS",systemImage:"sun.horizon.fill").font(.caption.bold()).tracking(1.2).foregroundStyle(.indigo)
            Text("Empieza por tu descanso").font(.title2.bold())
            if let sleep = s.sleepHours { Text(sleepDuration(sleep*3600)).font(.system(size:36,weight:.semibold,design:.rounded)); Text(sleep >= s.sleepTarget-0.5 ? "Una duración próxima al objetivo orientativo. Cómo te sientes al despertar también cuenta." : "La noche quedó por debajo del objetivo orientativo. Hoy puede encajar una carga más suave.").foregroundStyle(.secondary) }
            Text("Ventana estimada desde el último tramo de sueño recibido.").font(.caption).foregroundStyle(.secondary)
            if let metric = Metric.all.first(where:{ $0.key == "SleepAnalysis" }) { NavigationLink("Revisar fases de esta noche") { MetricDetail(metric:metric) } }
        }
    }
    private func activity(_ s:RecoverySnapshot)->some View {
        CoachPanel {
            Label("MOVIMIENTO QUE ENCAJA HOY",systemImage:"figure.walk").font(.caption.bold()).tracking(1)
            Text(s.suggestedMinutes == 0 ? "Hoy manda cómo te encuentras" : "\(s.suggestedMinutes) min para \(coach.profile.fitnessGoal.lowercased())").font(.title2.bold())
            if s.suggestedMinutes > 0 {
                Text(sessionDescription(s.suggestedMinutes,age:coach.profile.age,activity:coach.profile.usualActivity)).font(.subheadline).foregroundStyle(.secondary)
                let alternative = coach.profile.fitnessGoal == "Mejorar" ? s.maintenanceMinutes : s.progressionMinutes
                if alternative > 0 {
                    DisclosureGroup(coach.profile.fitnessGoal == "Mejorar" ? "Hoy prefiero mantener" : "Si hoy quiero progresar") {
                        Text("\(alternative) min: \(sessionDescription(alternative,age:coach.profile.age,activity:coach.profile.usualActivity))").font(.subheadline).padding(.top,6)
                        Text("La OMS cuenta toda la actividad moderada o vigorosa del día; esto es una propuesta de sesión, no tu actividad total.").font(.caption).foregroundStyle(.secondary)
                    }
                }
            } else { Text(s.activityNote).foregroundStyle(.secondary) }
            Text("En Salud aparecen \(Int(s.weeklyWorkoutMinutes.rounded())) min de entrenamientos estructurados en 7 días. Referencia general: \(s.weeklyGoalMinutes) min/semana en adultos o un promedio de 60 min/día entre 5–17 años; los paseos, deporte escolar y otros movimientos pueden no figurar aquí.").font(.caption).foregroundStyle(.secondary)
            Text("Si llevas un rato sentado y te encuentras bien, puedes hacer una pausa. La ausencia de un entrenamiento registrado no demuestra inactividad.").font(.caption).foregroundStyle(.secondary)
        }
    }
    private func sessionDescription(_ minutes:Int,age:Int,activity:String)->String {
        let chosen = activity.lowercased()
        if age < 18 { return "\(minutes) min de \(chosen), deporte, baile o bici a un ritmo que te deje hablar en frases. También cuentan la educación física, los juegos y los desplazamientos activos." }
        if age >= 65 { return "\(minutes) min de \(chosen) a un ritmo cómodo; adapta el terreno y para si notas dolor o malestar." }
        return "\(minutes) min de \(chosen) a ritmo moderado, donde puedas hablar en frases. Baja el ritmo o para si no te encuentras bien."
    }
    private func bedtime(_ s:RecoverySnapshot)->some View {
        CoachPanel(color:.purple) {
            Label("PREPARA TU PRÓXIMA NOCHE",systemImage:"moon.stars.fill").font(.caption.bold()).tracking(1).foregroundStyle(.purple)
            Text("Dale espacio al descanso").font(.title2.bold())
            HStack { VStack(alignment:.leading) { Text("A la cama").font(.caption).foregroundStyle(.secondary); Text(coachTime(s.bedtime)).font(.system(size:32,weight:.semibold,design:.rounded)).lineLimit(1).minimumScaleFactor(0.7) }; Spacer(); Image(systemName:"arrow.right").foregroundStyle(.secondary); Spacer(); VStack(alignment:.leading) { Text("Despertar").font(.caption).foregroundStyle(.secondary); Text(coachTime(s.alarm)).font(.system(size:32,weight:.semibold,design:.rounded)).lineLimit(1).minimumScaleFactor(0.7) } }
            Text("Reserva \(number(s.sleepTarget)) h de sueño y unos 20 min para conciliarlo. Es una propuesta ajustable, no un horario óptimo demostrado.").font(.subheadline).foregroundStyle(.secondary)
            Button("Cambiar la agenda de mañana") { profileSheet = true }
        }
    }
    private func ai(_ s:RecoverySnapshot)->some View {
        CoachPanel(color:.cyan) {
            Label("TU ORIENTADOR IA",systemImage:"sparkles").font(.caption.bold()).tracking(1).foregroundStyle(.cyan)
            if let saved = coach.advice {
                Text(saved.advice.headline).font(.headline)
                Text(saved.advice.interpretation).font(.subheadline).foregroundStyle(.secondary)
                Text("Análisis del " + saved.date.formatted(date:.abbreviated,time:.shortened) + " · puede quedar desactualizado si cambian tus datos.").font(.caption).foregroundStyle(.secondary)
            } else { Text(coach.profile.age < 18 ? "Una lectura cautelosa del sueño y de tus señales. La IA no propone entrenamientos a menores." : "Una explicación personal de tus señales, un plan mínimo y una alternativa gradual.").foregroundStyle(.secondary) }
            if coach.busy { ProgressView("Analizando con GPT-6 Luna · max…").font(.subheadline) }
            Button(coach.hasKey && coach.consent ? "Analizar este resumen con IA" : "Configurar IA privada") {
                if coach.hasKey && coach.consent { Task { await coach.analyze(snapshot:s) } } else { aiSheet = true }
            }.buttonStyle(.borderedProminent).disabled(coach.busy)
            Button("Qué se envía y ajustes") { aiSheet = true }.font(.caption)
            if let error = coach.error { Text(error).font(.footnote).foregroundStyle(.orange) }
            Text("gpt-6-luna · esfuerzo max · solo bajo petición · hasta 3 solicitudes/día. Consume saldo de tu API, separado de ChatGPT.").font(.caption).foregroundStyle(.secondary)
        }
    }
}

struct RecoveryExplanation:View {
    let snapshot:RecoverySnapshot
    var body:some View {
        List {
            Section("Índice orientativo 0–100") {
                Text("Pulso combina duración del sueño (55 %), regularidad de su duración (10 %), pulso en reposo (20 %), VFC SDNN (10 %) y carga declarada (5 %). Solo usa factores disponibles y renormaliza sus pesos. Estos pesos son una heurística propia, sin validación clínica ni equivalencia con Huawei, Samsung o Garmin.")
                Text("\(snapshot.baselineNights) noches de referencia. \(snapshot.confidence).").foregroundStyle(.secondary)
                Text("No se asigna una puntuación sin sueño reciente y perfil completo. No se puntúan las fases como buenas o malas ni se comparan porcentajes con un ideal universal.").font(.footnote)
            }
            Section("Factores disponibles") { ForEach(snapshot.factors) { factor in VStack(alignment:.leading,spacing:8) { HStack { Text(factor.title).font(.headline); Spacer(); Text("\(Int(factor.value)) / 100") }; Text(factor.detail).font(.footnote).foregroundStyle(.secondary) } } }
            Section("Qué falta") { ForEach(snapshot.missing,id:\.self) { Text($0).font(.footnote) }; Text("Los promedios cardíacos diarios no sustituyen mediciones nocturnas continuas. Fuentes mezcladas, datos antiguos o errores reducen lo que puede interpretarse.").font(.footnote).foregroundStyle(.secondary) }
            Section("Fuentes del enfoque") {
                Link("Samsung: factores del Energy Score",destination:URL(string:"https://news.samsung.com/global/samsung-collaborates-with-the-university-of-georgia-to-define-and-measure-energy-for-innovative-digital-health-experiences")!)
                Link("Garmin: Body Battery",destination:URL(string:"https://www.garmin.com/en-GB/garmin-technology/health-science/body-battery/")!)
                Link("CDC: sueño por edad",destination:URL(string:"https://www.cdc.gov/sleep/about/")!)
                Link("OMS: actividad física",destination:URL(string:"https://www.who.int/health-topics/noncommunicable-diseases/physical-activity")!)
            }
        }.navigationTitle("Tu recuperación")
    }
}

struct CoachProfileView:View {
    @EnvironmentObject var coach:CoachStore
    @Environment(\.dismiss) private var dismiss
    @State private var draft = CoachProfile()
    @State private var ageText = ""
    private let days = [(2,"L"),(3,"M"),(4,"X"),(5,"J"),(6,"V"),(7,"S"),(1,"D")]
    var body:some View {
        NavigationStack {
            Form {
                Section("Primero, tú") {
                    TextField("Edad en años",text:$ageText).keyboardType(.numberPad)
                    Text("La edad se usa para un rango orientativo de sueño. No se solicitan fecha de nacimiento ni nombre.").font(.caption).foregroundStyle(.secondary)
                    Picker("Actividad preferida",selection:$draft.usualActivity) { ForEach(["Caminar","Bicicleta","Correr","Movilidad"],id:\.self) { Text($0) } }
                    Picker("Objetivo de hoy",selection:$draft.fitnessGoal) { Text("Mantener").tag("Mantener"); Text("Mejorar").tag("Mejorar") }
                    Stepper("Tiempo disponible: \(draft.availableMinutes) min",value:$draft.availableMinutes,in:5...60,step:5)
                    Toggle("Tengo limitaciones para hacer ejercicio",isOn:$draft.limitedExercise)
                    Text("Pulso combina edad, objetivo, entrenamientos visibles y sensaciones. Si tienes limitaciones, prioriza descanso. En menores, la IA puede orientar sobre el sueño, pero no crea entrenamientos.").font(.caption).foregroundStyle(.secondary)
                }
                Section("Clases, trabajo o días con horario") {
                    Text("¿Qué días necesitas madrugar?").font(.subheadline)
                    HStack { ForEach(days,id:\.0) { day in Button { if draft.scheduledDays.contains(day.0) { draft.scheduledDays.removeAll { $0 == day.0 } } else { draft.scheduledDays.append(day.0) } } label:{ Text(day.1).frame(maxWidth:.infinity).padding(.vertical,9).background(draft.scheduledDays.contains(day.0) ? Color.mint.opacity(0.3) : Color.gray.opacity(0.15),in:RoundedRectangle(cornerRadius:9)) }.buttonStyle(.plain).accessibilityLabel("Día \(day.1), \(draft.scheduledDays.contains(day.0) ? "con horario" : "libre")") } }
                    DatePicker("Me levanto a las",selection:timeBinding(regular:true),displayedComponents:.hourAndMinute)
                    DatePicker("Días libres",selection:timeBinding(regular:false),displayedComponents:.hourAndMinute)
                }
                Section("Solo para mañana") {
                    Toggle("Mañana tengo un horario diferente",isOn:Binding(get:{ draft.tomorrowOverride.map { Calendar.current.isDateInTomorrow($0) } ?? false },set:{ value in draft.tomorrowOverride = value ? Calendar.current.date(bySettingHour:8,minute:0,second:0,of:Calendar.current.date(byAdding:.day,value:1,to:Date())!)! : nil }))
                    if draft.tomorrowOverride != nil { DatePicker("Despertar mañana",selection:Binding(get:{ draft.tomorrowOverride ?? Date() },set:{ draft.tomorrowOverride = $0 }),displayedComponents:.hourAndMinute) }
                }
                Section { Text("Con tus valoraciones de energía al despertar y al menos 7 mañanas favorables, Pulso podrá ajustar la duración dentro del rango por edad. Se trata de una asociación personal, no de una predicción garantizada.").font(.footnote).foregroundStyle(.secondary) }
            }.navigationTitle("Tu ritmo")
                .toolbar { ToolbarItem(placement:.cancellationAction) { Button("Cancelar") { dismiss() } }; ToolbarItem(placement:.confirmationAction) { Button("Guardar") { guard let age = Int(ageText), (6...100).contains(age) else { return }; draft.age = age; draft.completed = true; coach.profile = draft; coach.persist(); dismiss() }.disabled(!(6...100).contains(Int(ageText) ?? 0)) } }
                .onAppear { draft = coach.profile; if let override = draft.tomorrowOverride, !Calendar.current.isDateInTomorrow(override) { draft.tomorrowOverride = nil }; ageText = draft.age == 0 ? "" : String(draft.age) }
        }.preferredColorScheme(.dark).tint(.mint)
    }
    private func timeBinding(regular:Bool)->Binding<Date> {
        Binding(get:{ let minutes = regular ? draft.regularWake : draft.freeWake; return Calendar.current.date(bySettingHour:minutes/60,minute:minutes%60,second:0,of:Date())! },set:{ let minutes = Calendar.current.component(.hour,from:$0)*60+Calendar.current.component(.minute,from:$0); if regular { draft.regularWake = minutes } else { draft.freeWake = minutes } })
    }
}
struct DailyCheckView:View {
    @EnvironmentObject var coach:CoachStore
    @Environment(\.dismiss) private var dismiss
    @State private var energy = 3
    @State private var soreness = 0
    @State private var unwell = false
    @State private var sleepQuality = 3
    var body:some View {
        NavigationStack { Form {
            Section("¿Cómo te encuentras hoy?") {
                Stepper("Energía: \(energy) de 5",value:$energy,in:1...5)
                Text("1 = muy cansado · 3 = normal · 5 = con mucha energía").font(.caption).foregroundStyle(.secondary)
                Stepper("Molestias musculares: \(soreness) de 5",value:$soreness,in:0...5)
                Toggle("Hoy no me encuentro bien",isOn:$unwell)
                Text("Tus sensaciones pueden recomendar bajar la carga aunque el índice sea alto. Esta valoración no convierte el índice en una medición clínica.").font(.footnote).foregroundStyle(.secondary)
            }
            Section("Tu sueño de anoche") {
                Stepper("Cómo descansaste: \(sleepQuality) de 5",value:$sleepQuality,in:1...5)
                Text("1 = nada reparador · 3 = normal · 5 = muy reparador. Se guarda en este iPhone y solo se envía a OpenAI si autorizas y pides un análisis.").font(.caption).foregroundStyle(.secondary)
            }
            Button("Guardar mi valoración") { coach.check(energy:energy,soreness:soreness,unwell:unwell,sleepQuality:sleepQuality); dismiss() }.buttonStyle(.borderedProminent)
        }.navigationTitle("Escúchate").toolbar { Button("Cerrar") { dismiss() } }.onAppear { if let check = coach.checks.last(where:{ Calendar.current.isDateInToday($0.date) }) { energy = check.energy; soreness = check.soreness; unwell = check.unwell; sleepQuality = check.sleepQuality ?? 3 } } }.preferredColorScheme(.dark).tint(.mint)
    }
}

struct CoachJourney:View {
    @EnvironmentObject var model:HealthDashboard
    @EnvironmentObject var coach:CoachStore
    @State private var profileSheet = false
    @State private var aiSheet = false
    @State private var ratedWorkout:WorkoutSummary?
    var body:some View {
        TimelineView(.periodic(from:.now,by:60)) { context in
            let s = RecoveryEngine.snapshot(results:model.results,profile:coach.profile,checks:coach.checks,ratings:coach.ratings,now:context.date)
            ScrollView {
                VStack(alignment:.leading,spacing:22) {
                    if !coach.profile.completed { Text("Personaliza tu edad y agenda para preparar el plan.").foregroundStyle(.secondary); Button("Configurar mi ritmo") { profileSheet = true }.buttonStyle(.borderedProminent) }
                    else {
                        Text("Avanzar también es recuperar.").font(.system(size:32,weight:.bold,design:.rounded))
                        localPlan(s)
                        sleepPlan(s)
                        progress(s)
                        if let saved = coach.advice {
                            CoachPanel(color:.cyan) {
                                Label("ORIENTACIÓN IA",systemImage:"sparkles").font(.caption.bold()).foregroundStyle(.cyan)
                                Text(saved.advice.headline).font(.title3.bold()); Text(saved.advice.interpretation)
                                Text("Generada el " + saved.date.formatted(date:.abbreviated,time:.shortened) + ". Revisa si cambió tu estado.").font(.caption).foregroundStyle(.secondary)
                                ForEach(saved.advice.factors,id:\.self) { Text("• "+$0).font(.subheadline) }
                                if Calendar.current.isDateInToday(saved.date) && adviceStillFits(saved.advice,snapshot:s) {
                                    if s.maxMinutes > 0 {
                                        plan(saved.advice.minimum_plan,label:"Mínimo propuesto")
                                        DisclosureGroup("Explorar una progresión gradual") { plan(saved.advice.progression_plan,label:"Alternativa, solo si te encuentras bien") }
                                    } else { Text("La IA no propone sesiones de entrenamiento en menores ni cuando faltan datos de seguridad suficientes. Sigue la orientación local por edad y tus sensaciones.").font(.footnote).foregroundStyle(.secondary) }
                                } else { Text("Tus condiciones actuales cambiaron. Se ocultan los planes anteriores; sigue la orientación local o solicita uno nuevo.").foregroundStyle(.orange) }
                                if let insight = saved.advice.sleep_insight { Text(insight).font(.subheadline.weight(.medium)) }
                                ForEach(saved.advice.sleep_actions ?? [],id:\.self) { Text("• "+$0).font(.subheadline) }
                                Text(saved.advice.sleep_advice).font(.subheadline)
                                Text(saved.advice.limitations).font(.caption).foregroundStyle(.secondary)
                            }
                        }
                        Button("IA: configurar o revisar lo que envío") { aiSheet = true }.buttonStyle(.bordered)
                    }
                }.padding(22)
            }
        }.navigationTitle("Tu plan").toolbar { Button { profileSheet = true } label:{ Image(systemName:"slider.horizontal.3") } }
            .sheet(isPresented:$profileSheet) { CoachProfileView().environmentObject(coach) }
            .sheet(isPresented:$aiSheet) { CoachAISettings().environmentObject(coach).environmentObject(model) }
            .sheet(item:$ratedWorkout) { WorkoutRatingView(workout:$0).environmentObject(coach) }
    }
    private func adviceStillFits(_ advice:CoachAdvice,snapshot:RecoverySnapshot)->Bool {
        [advice.minimum_plan,advice.progression_plan].allSatisfy { $0.duration_minutes <= snapshot.maxMinutes && (snapshot.maxMinutes > 0 || $0.intensity == "rest") }
    }
    private func localPlan(_ s:RecoverySnapshot)->some View {
        CoachPanel(color:s.color) {
            Label("PROPUESTA PARA HOY",systemImage:"figure.walk").font(.caption.bold()).tracking(1)
            if s.suggestedMinutes > 0 {
                Text("\(s.suggestedMinutes) min · objetivo \(coach.profile.fitnessGoal.lowercased())").font(.title2.bold())
                Text(sessionDescription(s.suggestedMinutes,age:coach.profile.age,activity:coach.profile.usualActivity)).foregroundStyle(.secondary)
                Text(s.activityNote).font(.caption).foregroundStyle(.secondary)
                let alternative = coach.profile.fitnessGoal == "Mejorar" ? s.maintenanceMinutes : s.progressionMinutes
                if alternative > 0 {
                    DisclosureGroup(coach.profile.fitnessGoal == "Mejorar" ? "Prefiero una sesión de mantenimiento" : "Hoy quiero una opción para mejorar") {
                        Text("\(alternative) min · \(coach.profile.fitnessGoal == "Mejorar" ? "mantenimiento" : "progresión gradual")").font(.headline)
                        Text(sessionDescription(alternative,age:coach.profile.age,activity:coach.profile.usualActivity)).font(.subheadline).padding(.top,4)
                        Text("Elige una sola opción y ajusta el esfuerzo a cómo te sientes. No necesitas compensar días con menos movimiento.").font(.caption).foregroundStyle(.secondary)
                    }
                }
            } else { Text("Prioriza recuperar y revisar sensaciones").font(.title2.bold()); Text(s.reason).foregroundStyle(.secondary) }
            HStack { Text("Entrenos visibles 7 días"); Spacer(); Text("\(Int(s.weeklyWorkoutMinutes.rounded())) / \(s.weeklyGoalMinutes) min").monospacedDigit() }.font(.subheadline)
            Text(s.weeklyGoalMinutes == 420 ? "Referencia general para edades 5–17: promedio de 60 min diarios de actividad moderada o vigorosa. No todo tiene que ser una sesión ni aparecer en Salud." : "Referencia general para adultos: 150 min semanales de actividad moderada. Se suman paseos y otras actividades, aunque la app no las vea.")
                .font(.caption).foregroundStyle(.secondary)
            DisclosureGroup("Por qué esta propuesta") {
                Text(s.activityNote).font(.subheadline).padding(.top,8)
                Text("Usa edad, objetivo, minutos disponibles, sesiones visibles, carga que has valorado y recuperación cuando está disponible. No es una receta ni una dosis mínima demostrada para mantener tu forma.")
                    .font(.caption).foregroundStyle(.secondary)
                if let vo2 = s.vo2 { Text("VO₂max registrado: \(number(vo2)) ml/kg/min. Se usa como contexto de tendencia, no como permiso para entrenar fuerte.").font(.caption).foregroundStyle(.secondary) }
            }
        }
    }
    private func sleepPlan(_ s:RecoverySnapshot)->some View {
        CoachPanel(color:.purple) {
            Label("TU AGENDA DE DESCANSO",systemImage:"moon.stars.fill").font(.caption.bold()).foregroundStyle(.purple)
            Text("\(coachTime(s.bedtime)) → \(coachTime(s.alarm))").font(.title2.bold()).monospacedDigit().lineLimit(1).minimumScaleFactor(0.7)
            Text("Objetivo orientativo: \(number(s.sleepTarget)) h + 20 min para conciliar el sueño. La hora de despertar corresponde a mañana.").font(.subheadline)
            Text(s.learningPairs >= 7 ? "\(s.learningPairs) mañanas valoradas como favorables han aportado una asociación entre duración y sensación de energía. No demuestra que ese horario sea el mejor." : "\(s.learningPairs) de 7 mañanas favorables para empezar a observar asociaciones. De momento se usa una referencia por edad, no una predicción individual.").font(.caption).foregroundStyle(.secondary)
            Text("Si la hora propuesta ya pasó, empieza la rutina cuando puedas; no compensamos el retraso recomendando dormir menos. El índice no puede garantizar levantarte con más energía.").font(.caption).foregroundStyle(.secondary)
            Button("Editar clases, trabajo y mañana") { profileSheet = true }
        }
    }
    private func progress(_ s:RecoverySnapshot)->some View {
        VStack(alignment:.leading,spacing:18) {
            Text("TU PROGRESO").font(.caption.bold()).tracking(1.5).foregroundStyle(.secondary)
            if !coach.history.isEmpty {
                CoachPanel(color:.purple) {
                    Text("Tu índice de recuperación").font(.headline)
                    Chart(Array(coach.history.suffix(30))) { day in LineMark(x:.value("Día",day.date),y:.value("Estimación",day.score)).foregroundStyle(.purple); PointMark(x:.value("Día",day.date),y:.value("Estimación",day.score)).foregroundStyle(.purple) }.chartYScale(domain:0...100).frame(height:150)
                    Text("Última estimación disponible de cada día. No son mediciones de energía ni una validación de que te sintieras mejor.").font(.caption).foregroundStyle(.secondary)
                }
            }
            let week = (0..<7).map { offset -> DayValue in
                let day = Calendar.current.date(byAdding:.day,value:offset-6,to:Calendar.current.startOfDay(for:s.now))!
                return DayValue(date:day,value:s.workouts.filter { Calendar.current.isDate($0.end,inSameDayAs:day) }.reduce(0) { $0+$1.minutes })
            }
            CoachPanel {
                Text("Minutos de entrenamientos visibles").font(.headline)
                Chart(week) { day in BarMark(x:.value("Día",day.date,unit:.day),y:.value("Minutos",day.value)).foregroundStyle(Color.mint.gradient).cornerRadius(5) }.frame(height:170).modifier(RevealChart())
                Text("Solo sesiones registradas en Salud. Una barra vacía no demuestra que no te movieras.").font(.caption).foregroundStyle(.secondary)
            }
            let vo2 = model.results["VO2Max"]?.days ?? []
            CoachPanel(color:.cyan) {
                Text("Capacidad aeróbica · VO₂max").font(.headline)
                if vo2.count >= 2, let first = vo2.first, let last = vo2.last {
                    Text("\(number(last.value)) ml/kg/min").font(.title2.bold())
                    Text("Cambio observado: \(last.value-first.value >= 0 ? "+" : "")\(number(last.value-first.value)) desde " + first.date.formatted(date:.abbreviated,time:.omitted)).font(.subheadline).foregroundStyle(.cyan)
                    Chart(vo2) { day in LineMark(x:.value("Día",day.date),y:.value("VO₂max",day.value)).foregroundStyle(.cyan).interpolationMethod(.monotone); PointMark(x:.value("Día",day.date),y:.value("VO₂max",day.value)).foregroundStyle(.cyan) }.frame(height:160).modifier(RevealChart())
                } else { Text("Necesitas muestras en al menos dos días para ver una tendencia.").foregroundStyle(.secondary) }
                Text("No se calcula VO₂max a partir de una sesión ni se atribuye un cambio a ese entrenamiento. Las estimaciones varían y pueden proceder de distintas fuentes; observa varias semanas en condiciones comparables.").font(.caption).foregroundStyle(.secondary)
                if let workout = s.workouts.max(by:{ $0.end < $1.end }) { postWorkoutVO2(workout) }
            }
            if s.workouts.isEmpty { Text("Aún no hay entrenamientos estructurados visibles. Actualiza Salud y Pulso para cargar las sesiones.").foregroundStyle(.secondary) }
            ForEach(Array(s.workouts.sorted { $0.end > $1.end }.prefix(12))) { workout in
                CoachPanel(color:.orange) {
                    HStack { VStack(alignment:.leading,spacing:6) { Text(workout.activity).font(.headline); Text(workout.end.formatted(date:.abbreviated,time:.shortened)).font(.caption).foregroundStyle(.secondary) }; Spacer(); Text("\(Int(workout.minutes)) min").font(.headline) }
                    if let rpe = coach.ratings[workout.id] {
                        let load = workout.minutes*rpe
                        Text("Esfuerzo percibido: \(RecoveryEngine.effortScore(rpe)) / 100").font(.headline).foregroundStyle(.orange)
                        ProgressView(value:rpe/10).tint(.orange)
                        Text("RPE \(number(rpe))/10 · carga declarada \(Int(load)) u. (minutos × RPE). No es un esfuerzo medido por el sensor.").font(.caption).foregroundStyle(.secondary)
                    } else { Text("¿Cómo de exigente fue? Valóralo para conocer la carga sin inventar su intensidad.").font(.subheadline).foregroundStyle(.secondary) }
                    if let hr = workout.averageHR { Text("Pulso medio registrado: \(Int(hr)) lpm").font(.caption).foregroundStyle(.secondary) }
                    if let previous = s.workouts.filter({ $0.id != workout.id && $0.kind == workout.kind && $0.end < workout.start }).max(by:{ $0.end < $1.end }), let rating = coach.ratings[workout.id], let priorRating = coach.ratings[previous.id] {
                        Text("Sesión anterior comparable por tipo: \(Int(previous.minutes)) min y RPE \(number(priorRating))/10. Ahora: \(Int(workout.minutes)) min y RPE \(number(rating))/10. Una carga mayor no implica mejor forma.").font(.caption).foregroundStyle(.secondary)
                    }
                    Button(coach.ratings[workout.id] == nil ? "Valorar esfuerzo" : "Editar valoración") { ratedWorkout = workout }
                }
            }
        }
    }
    private func sessionDescription(_ minutes:Int,age:Int,activity:String)->String {
        let chosen = activity.lowercased()
        if age < 18 { return "\(minutes) min de \(chosen), deporte, baile o bici a un ritmo que te deje hablar en frases; cuenta también la actividad escolar y recreativa." }
        if age >= 65 { return "\(minutes) min de \(chosen) a un ritmo cómodo, adaptado a tu movilidad y sensaciones." }
        return "\(minutes) min de \(chosen) a ritmo moderado, donde puedas hablar en frases."
    }
    @ViewBuilder private func postWorkoutVO2(_ workout:WorkoutSummary)->some View {
        let records = model.results["VO2Max"]?.records ?? []
        if let after = records.filter({ $0.end >= workout.end && $0.quantityValue != nil }).min(by:{ $0.end < $1.end }), let before = records.filter({ $0.end < workout.start && $0.source == after.source && $0.quantityValue != nil && workout.start.timeIntervalSince($0.end) < 30*86400 }).max(by:{ $0.end < $1.end }), let a = after.quantityValue, let b = before.quantityValue {
            Text("Hay una muestra posterior a tu última sesión: \(number(a)) frente a \(number(b)) ml/kg/min antes, de la misma fuente. Diferencia temporal observada, no efecto demostrado del ejercicio.").font(.caption).foregroundStyle(.secondary)
        } else { Text("No hay dos muestras comparables, de la misma fuente, antes y después de la última sesión.").font(.caption).foregroundStyle(.secondary) }
    }
    private func plan(_ plan:CoachPlan,label:String)->some View {
        VStack(alignment:.leading,spacing:8) { Text(label).font(.caption.bold()).foregroundStyle(.cyan); Text(plan.title).font(.headline); Text("\(plan.duration_minutes) min · \(plan.intensity == "rest" ? "descanso" : (plan.intensity == "easy" ? "suave" : "moderado"))").font(.subheadline); ForEach(plan.steps,id:\.self) { Text("• "+$0).font(.subheadline) } }.padding(.vertical,8)
    }
}
struct WorkoutRatingView:View {
    let workout:WorkoutSummary
    @EnvironmentObject var coach:CoachStore
    @Environment(\.dismiss) private var dismiss
    @State private var value:Double = 5
    var body:some View {
        NavigationStack { Form {
            Section(workout.activity) { Text("Piensa en la sesión completa, no solo en el tramo más duro."); Slider(value:$value,in:0...10,step:1); Text("RPE \(Int(value)) / 10 · índice \(RecoveryEngine.effortScore(value)) / 100").font(.title3.bold()); Text("0 = reposo · 2 = fácil · 5 = exigente pero controlado · 8 = muy duro · 10 = máximo. Es tu percepción, no una medición cardíaca.").font(.footnote).foregroundStyle(.secondary) }
            Button("Guardar esfuerzo") { coach.ratings[workout.id] = value; coach.persist(); dismiss() }.buttonStyle(.borderedProminent)
        }.navigationTitle("Esfuerzo de la sesión").toolbar { Button("Cerrar") { dismiss() } }.onAppear { value = coach.ratings[workout.id] ?? 5 } }.preferredColorScheme(.dark).tint(.orange)
    }
}
struct CoachAISettings:View {
    @EnvironmentObject var model:HealthDashboard
    @EnvironmentObject var coach:CoachStore
    @Environment(\.dismiss) private var dismiss
    @State private var key = ""
    var body:some View {
        let s = RecoveryEngine.snapshot(results:model.results,profile:coach.profile,checks:coach.checks,ratings:coach.ratings,now:Date())
        NavigationStack {
            Form {
                Section("Tu clave personal") {
                    Text(coach.hasKey ? "Hay una clave guardada en el llavero de este iPhone." : "Introduce una clave nueva de tu cuenta de OpenAI. No reutilices la publicada en la conversación.").font(.footnote)
                    SecureField("Nueva clave de la API",text:$key).textInputAutocapitalization(.never).autocorrectionDisabled()
                    Button("Guardar en el llavero") { coach.saveKey(key); key = "" }.disabled(key.isEmpty)
                    if coach.hasKey { Button("Eliminar clave y desactivar IA",role:.destructive) { coach.deleteKey() } }
                    Text("Una IPA personal puede incluir una clave preconfigurada que se importa al llavero al abrirla. Eliminarla aquí borra la copia del llavero, pero no la del paquete: para invalidarla, revócala en OpenAI. No compartas esa IPA. La conexión es directa a api.openai.com.").font(.caption).foregroundStyle(.secondary)
                    Link("Gestionar claves de OpenAI",destination:URL(string:"https://platform.openai.com/api-keys")!)
                }
                Section("Decides qué compartir") {
                    Text("Solo al pedir un análisis y con tu permiso se envían a OpenAI: edad y objetivo, propuesta horaria, puntuaciones y factores, últimas 15 noches resumidas (horas, fases estimadas, hora de dormir/despertar, valoración personal, energía, pulso/VFC diarios disponibles y entrenamientos previos resumidos), además de hasta 12 sesiones recientes. No se envían nombre, ubicación, rutas, ECG, registros completos ni identificadores del reloj.").font(.footnote)
                    Toggle("Autorizo enviar este resumen a OpenAI al solicitar un análisis",isOn:Binding(get:{ coach.consent },set:{ coach.setConsent($0) }))
                    DisclosureGroup("Ver el resumen exacto de esta consulta") {
                        Text(payloadText(s)).font(.system(.caption,design:.monospaced)).textSelection(.enabled)
                    }
                    Text("Se solicita no guardar la respuesta en la API (store:false), pero esto no equivale a retención cero del proveedor. Los análisis se guardan localmente hasta borrarlos. Los análisis solo se inician al pulsar; no hay envíos automáticos en segundo plano.").font(.caption).foregroundStyle(.secondary)
                }
                Section("Modelo y consumo") {
                    LabeledContent("Modelo",value:CoachAPI.model)
                    LabeledContent("Razonamiento",value:CoachAPI.effort)
                    Text("Máximo 12.000 tokens de salida, incluidos los de razonamiento, por solicitud. Límite local de 3 solicitudes al día; sin reintentos automáticos. Configura también un límite de gasto en tu proyecto de OpenAI.").font(.footnote)
                    Text("Solicitudes iniciadas hoy: \(coach.requestsToday) / 3. Puede tardar varios minutos; mantén la app abierta.").font(.caption).foregroundStyle(.secondary)
                    Button(coach.busy ? "Analizando…" : "Analizar con GPT-6 Luna") { Task { await coach.analyze(snapshot:s) } }.buttonStyle(.borderedProminent).disabled(coach.busy || !coach.consent || !coach.hasKey || !coach.profile.completed || coach.profile.age < 13)
                    if coach.profile.age < 13 { Text("El análisis con IA está desactivado para perfiles menores de 13 años.").font(.caption).foregroundStyle(.secondary) }
                    if let error = coach.error { Text(error).font(.footnote).foregroundStyle(.orange) }
                    if coach.advice != nil { Button("Borrar análisis local",role:.destructive) { coach.advice = nil; coach.persist() } }
                }
            }.navigationTitle("IA y privacidad").toolbar { Button("Cerrar") { key = ""; dismiss() } }
        }.preferredColorScheme(.dark).tint(.mint)
    }
    private func payloadText(_ s:RecoverySnapshot)->String { let payload = CoachAPI.payload(snapshot:s,profile:coach.profile,checks:coach.checks,ratings:coach.ratings); return (try? JSONSerialization.data(withJSONObject:payload,options:[.prettyPrinted,.sortedKeys])).flatMap { String(data:$0,encoding:.utf8) } ?? "Resumen no disponible" }
}

