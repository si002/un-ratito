import SwiftUI
import HealthKit

@MainActor
final class HealthProbe: ObservableObject {
    @Published var status = "Sin comprobar"
    @Published var detail = "Pulsa Comprobar acceso. iOS debería mostrar la solicitud para leer tus pasos."
    @Published var busy = false
    private let health = HKHealthStore()

    func check() {
        guard !busy else { return }
        guard HKHealthStore.isHealthDataAvailable(),
              let steps = HKObjectType.quantityType(forIdentifier: .stepCount) else {
            status = "Salud no disponible"
            detail = "Ejecuta esta prueba en tu iPhone."
            return
        }
        busy = true
        status = "Solicitando acceso…"
        health.requestAuthorization(toShare: [], read: [steps]) { [weak self] success, error in
            Task { @MainActor in
                guard let self = self else { return }
                if let error = error {
                    self.report(error)
                } else if !success {
                    self.busy = false
                    self.status = "Solicitud no completada"
                    self.detail = "La solicitud no se completó. Puedes volver a intentarlo."
                } else {
                    self.read(steps)
                }
            }
        }
    }

    private func read(_ steps: HKQuantityType) {
        status = "Consultando los últimos 7 días…"
        let start = Calendar.current.date(byAdding: .day, value: -7, to: Date())!
        let predicate = HKQuery.predicateForSamples(withStart: start, end: Date(), options: .strictStartDate)
        let query = HKSampleQuery(sampleType: steps, predicate: predicate, limit: 200,
            sortDescriptors: [NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)]) { [weak self] _, samples, error in
            Task { @MainActor in
                guard let self = self else { return }
                if let error = error { self.report(error); return }
                self.busy = false
                let records = samples as? [HKQuantitySample] ?? []
                if records.isEmpty {
                    self.status = "Consulta completada, sin registros visibles"
                    self.detail = "No se ha producido un error de consulta. Por privacidad, iOS no permite distinguir entre permiso de lectura denegado y ausencia de datos. Comprueba el permiso de Pasos y que existan registros en Salud."
                } else {
                    let huawei = records.filter { $0.sourceRevision.source.name.localizedCaseInsensitiveContains("huawei") }
                    self.status = "HealthKit funciona en esta instalación"
                    self.detail = "Se han leído \(records.count) registros recientes de pasos (máximo 200). Entre ellos, \(huawei.count) tienen un nombre de origen que contiene Huawei. Esto no comprueba otras métricas ni la sincronización en segundo plano."
                    if let recent = records.first {
                        self.detail += "\n\nÚltimo registro visible: " + recent.endDate.formatted(date: .abbreviated, time: .shortened) + "."
                    }
                }
            }
        }
        health.execute(query)
    }

    private func report(_ error: Error) {
        busy = false
        status = "No se pudo acceder a HealthKit"
        let ns = error as NSError
        detail = "\(ns.domain) · código \(ns.code)\n\(ns.localizedDescription)\n\nSi menciona un entitlement o permiso ausente, el perfil o la firma no incluyen HealthKit."
    }
}

struct ContentView: View {
    @StateObject private var probe = HealthProbe()
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    Image(systemName: "heart.text.square.fill")
                        .font(.system(size: 58)).foregroundStyle(.pink).accessibilityHidden(true)
                    Text("Comprobemos el acceso a Salud")
                        .font(.largeTitle.bold())
                    Text("Esta prueba solo solicita leer pasos. No escribe ni modifica tus registros, y no envía información a internet.")
                        .foregroundStyle(.secondary)
                    VStack(alignment: .leading, spacing: 14) {
                        Text(probe.status).font(.headline)
                        Text(probe.detail).textSelection(.enabled)
                    }.frame(maxWidth: .infinity, alignment: .leading).padding()
                        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 18))
                        .accessibilityElement(children: .combine)
                    Button(action: probe.check) {
                        HStack {
                            if probe.busy { ProgressView().tint(.white) }
                            Text(probe.busy ? "Comprobando…" : "Comprobar acceso")
                                .fontWeight(.semibold)
                        }.frame(maxWidth: .infinity).padding(.vertical, 10)
                    }.buttonStyle(.borderedProminent).disabled(probe.busy)
                    Text("En el diálogo de Salud, permite leer Pasos. Puedes cambiarlo después en Salud → tu perfil → Apps y servicios → Prueba Salud.")
                        .font(.footnote).foregroundStyle(.secondary)
                    Text("Instalación separada: no modifica Un ratito. Esta prueba no evalúa las actualizaciones en segundo plano.")
                        .font(.footnote).foregroundStyle(.secondary)
                }.padding(24)
            }.background(Color(.systemGroupedBackground))
                .navigationTitle("Prueba Salud").navigationBarTitleDisplayMode(.inline)
        }.tint(.pink)
    }
}
