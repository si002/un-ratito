import SwiftUI
import HealthKit
import Charts

struct Metric: Identifiable {
    let key:String, name:String, group:String, symbol:String, suffix:String
    let unit:HKUnit?
    let cumulative:Bool
    let kind:Int
    var id:String { key }
    var type:HKSampleType? {
        if kind == 0 { return HKObjectType.quantityType(forIdentifier:.init(rawValue:"HKQuantityTypeIdentifier"+key)) }
        if kind == 1 { return HKObjectType.categoryType(forIdentifier:.init(rawValue:"HKCategoryTypeIdentifier"+key)) }
        if key == "ECG" { return HKObjectType.electrocardiogramType() }
        if key == "Audiogram" { return HKObjectType.audiogramSampleType() }
        return HKObjectType.workoutType()
    }
    var color:Color {
        switch group { case "Actividad":return .mint; case "Corazón":return .pink; case "Sueño":return .indigo; case "Cuerpo":return .orange; default:return .cyan }
    }
    static let all:[Metric] = {
        var items:[Metric] = []
        func q(_ key:String,_ name:String,_ group:String,_ symbol:String,_ unit:HKUnit,_ suffix:String,_ sum:Bool = false) {
            items.append(Metric(key:key,name:name,group:group,symbol:symbol,suffix:suffix,unit:unit,cumulative:sum,kind:0))
        }
        let rate = HKUnit.count().unitDivided(by:.minute())
        q("StepCount","Pasos","Actividad","figure.walk",.count(),"pasos",true)
        q("ActiveEnergyBurned","Energía activa","Actividad","flame.fill",.kilocalorie(),"kcal",true)
        q("BasalEnergyBurned","Energía en reposo","Actividad","flame",.kilocalorie(),"kcal",true)
        q("DistanceWalkingRunning","Andar y correr","Actividad","figure.run",.meterUnit(with:.kilo),"km",true)
        q("DistanceCycling","Distancia en bici","Actividad","bicycle",.meterUnit(with:.kilo),"km",true)
        q("DistanceSwimming","Distancia nadada","Actividad","figure.pool.swim",.meter(),"m",true)
        q("DistanceDownhillSnowSports","Deportes de nieve","Actividad","snowflake",.meterUnit(with:.kilo),"km",true)
        q("FlightsClimbed","Pisos subidos","Actividad","figure.stairs",.count(),"pisos",true)
        q("AppleExerciseTime","Ejercicio","Actividad","timer",.minute(),"min",true)
        q("AppleStandTime","Tiempo de pie","Actividad","figure.stand",.minute(),"min",true)
        q("SwimmingStrokeCount","Brazadas","Actividad","water.waves",.count(),"brazadas",true)
        q("HeartRate","Frecuencia cardíaca","Corazón","heart.fill",rate,"lpm")
        q("RestingHeartRate","Pulso en reposo","Corazón","heart",rate,"lpm")
        q("WalkingHeartRateAverage","Pulso al caminar","Corazón","heart.circle",rate,"lpm")
        q("HeartRateVariabilitySDNN","Variabilidad cardíaca","Corazón","waveform.path.ecg",.secondUnit(with:.milli),"ms")
        q("HeartRateRecoveryOneMinute","Recuperación cardíaca","Corazón","heart.slash",rate,"lpm")
        q("VO2Max","Capacidad aeróbica","Corazón","lungs.fill",HKUnit(from:"ml/kg*min"),"ml/kg/min")
        q("BloodPressureSystolic","Tensión sistólica","Corazón","heart.text.square",.millimeterOfMercury(),"mmHg")
        q("BloodPressureDiastolic","Tensión diastólica","Corazón","heart.text.square",.millimeterOfMercury(),"mmHg")
        q("OxygenSaturation","Oxígeno en sangre","Sueño","drop.fill",.percent(),"%")
        q("RespiratoryRate","Frecuencia respiratoria","Sueño","lungs",rate,"resp/min")
        q("BodyTemperature","Temperatura corporal","Cuerpo","thermometer",.degreeCelsius(),"°C")
        q("BasalBodyTemperature","Temperatura basal","Cuerpo","thermometer.medium",.degreeCelsius(),"°C")
        q("AppleSleepingWristTemperature","Temperatura de muñeca","Sueño","thermometer",.degreeCelsius(),"°C")
        q("BodyMass","Peso","Cuerpo","scalemass",.gramUnit(with:.kilo),"kg")
        q("BodyMassIndex","Índice de masa corporal","Cuerpo","figure",.count(),"IMC")
        q("BodyFatPercentage","Grasa corporal","Cuerpo","figure",.percent(),"%")
        q("LeanBodyMass","Masa magra","Cuerpo","figure.strengthtraining.traditional",.gramUnit(with:.kilo),"kg")
        q("Height","Altura","Cuerpo","ruler",.meterUnit(with:.centi),"cm")
        q("WaistCircumference","Cintura","Cuerpo","ruler",.meterUnit(with:.centi),"cm")
        q("WalkingSpeed","Velocidad al caminar","Movilidad","figure.walk",.meter().unitDivided(by:.second()),"m/s")
        q("WalkingStepLength","Longitud de paso","Movilidad","shoeprints.fill",.meterUnit(with:.centi),"cm")
        q("WalkingAsymmetryPercentage","Asimetría al caminar","Movilidad","figure.walk",.percent(),"%")
        q("WalkingDoubleSupportPercentage","Doble apoyo","Movilidad","shoeprints.fill",.percent(),"%")
        q("AppleWalkingSteadiness","Estabilidad al caminar","Movilidad","figure.walk",.percent(),"%")
        q("SixMinuteWalkTestDistance","Marcha de 6 minutos","Movilidad","figure.walk",.meter(),"m")
        q("StairAscentSpeed","Subir escaleras","Movilidad","figure.stairs",.meter().unitDivided(by:.second()),"m/s")
        q("StairDescentSpeed","Bajar escaleras","Movilidad","figure.stairs",.meter().unitDivided(by:.second()),"m/s")
        q("RunningSpeed","Velocidad de carrera","Actividad","figure.run",.meter().unitDivided(by:.second()),"m/s")
        q("RunningPower","Potencia de carrera","Actividad","bolt.fill",.watt(),"W")
        q("RunningStrideLength","Zancada de carrera","Actividad","figure.run",.meter(),"m")
        q("RunningVerticalOscillation","Oscilación vertical","Actividad","arrow.up.arrow.down",.meterUnit(with:.centi),"cm")
        q("RunningGroundContactTime","Contacto con el suelo","Actividad","shoeprints.fill",.secondUnit(with:.milli),"ms")
        q("EnvironmentalAudioExposure","Sonido ambiental","Otros","ear",.decibelAWeightedSoundPressureLevel(),"dBA")
        q("HeadphoneAudioExposure","Sonido en auriculares","Otros","headphones",.decibelAWeightedSoundPressureLevel(),"dBA")
        q("BloodGlucose","Glucosa","Cuerpo","drop",HKUnit(from:"mg/dL"),"mg/dL")
        q("DietaryWater","Agua registrada","Otros","drop.fill",.literUnit(with:.milli),"ml",true)
        q("DietaryEnergyConsumed","Energía alimentaria","Otros","fork.knife",.kilocalorie(),"kcal",true)
        q("DietaryCaffeine","Cafeína","Otros","cup.and.saucer",.gramUnit(with:.milli),"mg",true)
        q("UVExposure","Exposición UV","Otros","sun.max",.count(),"UV")
        for (key,name,group,symbol) in [
            ("SleepAnalysis","Sueño","Sueño","bed.double.fill"),
            ("MindfulSession","Atención plena","Sueño","brain.head.profile"),
            ("HighHeartRateEvent","Avisos de pulso alto","Corazón","heart.fill"),
            ("LowHeartRateEvent","Avisos de pulso bajo","Corazón","heart"),
            ("IrregularHeartRhythmEvent","Ritmo irregular","Corazón","waveform.path.ecg"),
            ("LowCardioFitnessEvent","Avisos de capacidad aeróbica","Corazón","lungs"),
            ("AppleStandHour","Horas de pie","Actividad","figure.stand"),
            ("ToothbrushingEvent","Cepillado dental","Otros","sparkles"),
            ("HandwashingEvent","Lavado de manos","Otros","hands.sparkles"),
            ("EnvironmentalAudioExposureEvent","Avisos de ruido","Otros","ear.trianglebadge.exclamationmark"),
            ("HeadphoneAudioExposureEvent","Avisos de auriculares","Otros","headphones")
        ] { items.append(Metric(key:key,name:name,group:group,symbol:symbol,suffix:"",unit:nil,cumulative:false,kind:1)) }
        for (key,name,group,symbol) in [("Workout","Entrenamientos","Actividad","figure.run.circle.fill"),("ECG","Electrocardiogramas","Corazón","waveform.path.ecg.rectangle"),("Audiogram","Audiogramas","Otros","ear")] {
            items.append(Metric(key:key,name:name,group:group,symbol:symbol,suffix:"",unit:nil,cumulative:false,kind:2))
        }
        return items.filter { $0.type != nil }
    }()
}
struct ContentView:View {
    @EnvironmentObject var model:HealthDashboard
    @StateObject private var coach = CoachStore(preview:CommandLine.arguments.contains("--preview-data"))
    @Environment(\.scenePhase) private var phase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var search = ""
    @State private var onlyAvailable = false
    @State private var appeared = false
    @State private var previewSleep = CommandLine.arguments.contains("--preview-sleep")
    @State private var selectedTab = CommandLine.arguments.contains("--preview-explore") ? 1 : (CommandLine.arguments.contains("--preview-connection") ? 2 : (CommandLine.arguments.contains("--preview-plan") ? 3 : 0))
    private let groups = ["Actividad","Corazón","Sueño","Cuerpo","Movilidad","Otros"]
    var body:some View {
        TabView(selection:$selectedTab) {
            NavigationStack {
                ScrollView {
                    VStack(alignment:.leading,spacing:24) {
                        HStack {
                            VStack(alignment:.leading,spacing:8) {
                                Text(Date(),format:.dateTime.weekday(.wide).day().month(.wide)).font(.subheadline).foregroundStyle(.secondary)
                                Text("Tu salud,\na tu ritmo.").font(.system(size:38,weight:.bold,design:.rounded))
                            }
                            Spacer()
                            Image(systemName:"waveform.path.ecg").font(.system(size:32)).foregroundStyle(.mint).padding(18).background(.mint.opacity(0.12),in:Circle())
                        }
                        if !model.connected { connectCard }
                        else {
                            HStack {
                                Circle().fill(.mint).frame(width:6,height:6)
                                Text(model.busy ? "Actualizando Salud…" : "\(model.results.values.filter { !$0.records.isEmpty }.count) categorías con datos visibles")
                                Spacer(); if model.busy { ProgressView() }
                            }.font(.caption).foregroundStyle(.secondary)
                            if let message = model.message { Text(message).font(.footnote).foregroundStyle(.orange) }
                            CoachHome().environmentObject(coach)
                            Text("TUS CONSTANTES").font(.caption.bold()).tracking(2).foregroundStyle(.secondary)
                            LazyVGrid(columns:[GridItem(.flexible()),GridItem(.flexible())],spacing:14) {
                                ForEach(Metric.all.filter { ["HeartRate","OxygenSaturation","RestingHeartRate","ActiveEnergyBurned"].contains($0.key) }) { metric in
                                    NavigationLink { MetricDetail(metric:metric) } label:{ MetricCard(metric:metric,result:model.results[metric.id]) }.buttonStyle(SoftPress())
                                }
                            }
                            ForEach(Metric.all.filter { ["SleepAnalysis","Workout"].contains($0.key) }) { metric in
                                NavigationLink { MetricDetail(metric:metric) } label:{ MetricRow(metric:metric,result:model.results[metric.id]).padding(16).background(.white.opacity(0.04),in:RoundedRectangle(cornerRadius:22)) }.buttonStyle(SoftPress())
                            }
                            Text("Huawei sincroniza el reloj con Salud. Aquí ves los datos que Salud permite consultar, además de otras fuentes de tu iPhone.").font(.footnote).foregroundStyle(.secondary)
                        }
                    }.padding(22).opacity(appeared ? 1 : 0).offset(y:appeared ? 0 : 14)
                }.navigationDestination(isPresented:$previewSleep) { if let metric = Metric.all.first(where:{ $0.key == "SleepAnalysis" }) { MetricDetail(metric:metric) } }.refreshable { model.refresh() }.background(backdrop).navigationTitle("Pulso").navigationBarTitleDisplayMode(.inline)
                    .toolbar { Button { model.refresh() } label:{ Image(systemName:"arrow.clockwise") }.disabled(model.busy || !model.connected).accessibilityLabel("Actualizar datos") }
            }.tabItem { Label("Resumen",systemImage:"square.grid.2x2.fill") }.tag(0)
            NavigationStack {
                List {
                    Toggle("Solo categorías con datos",isOn:$onlyAvailable)
                    ForEach(groups,id:\.self) { group in
                        let metrics = Metric.all.filter { $0.group == group && (search.isEmpty || $0.name.localizedCaseInsensitiveContains(search)) && (!onlyAvailable || !(model.results[$0.id]?.records.isEmpty ?? true)) }
                        if !metrics.isEmpty { Section(group) { ForEach(metrics) { metric in NavigationLink { MetricDetail(metric:metric) } label:{ MetricRow(metric:metric,result:model.results[metric.id]) }.listRowBackground(Color.white.opacity(0.035)) } } }
                    }
                }.searchable(text:$search,prompt:"Buscar en \(Metric.all.count) categorías").navigationTitle("Explorar").scrollContentBackground(.hidden).background(backdrop)
            }.tabItem { Label("Explorar",systemImage:"heart.text.square.fill") }.tag(1)
            NavigationStack { CoachJourney().environmentObject(coach) }.tabItem { Label("Tu plan",systemImage:"sparkles") }.tag(3)
            NavigationStack { settings }.tabItem { Label("Conexión",systemImage:"antenna.radiowaves.left.and.right") }.tag(2)
        }.tint(.mint).preferredColorScheme(.dark)
            .animation(reduceMotion ? nil : .spring(response:0.45,dampingFraction:0.85),value:model.busy)
            .onAppear { withAnimation(reduceMotion ? nil : .easeOut(duration:0.6)) { appeared = true } }
            .onChange(of:phase) { value in if value == .active { model.refresh() } }
    }
    private var backdrop:some View { LinearGradient(colors:[Color(red:0.035,green:0.075,blue:0.10),Color(red:0.02,green:0.025,blue:0.04)],startPoint:.topLeading,endPoint:.bottomTrailing).ignoresSafeArea() }
    private var connectCard:some View {
        VStack(alignment:.leading,spacing:16) {
            Label("Un espacio para tus datos",systemImage:"heart.fill").font(.headline)
            Text("Conecta Salud para descubrir tus registros. Tú eliges qué categorías leer. La IA es opcional y pide autorización para enviar un resumen a OpenAI.").foregroundStyle(.secondary)
            Button("Conectar con Salud") { model.connect() }.buttonStyle(.borderedProminent).disabled(model.busy)
            if let message = model.message { Text(message).font(.footnote).foregroundStyle(.orange) }
        }.padding(24).background(.white.opacity(0.05),in:RoundedRectangle(cornerRadius:28))
    }
    private func hero(_ metric:Metric)->some View {
        let result = model.results[metric.id]
        return VStack(alignment:.leading,spacing:16) {
            HStack { Label("MOVIMIENTO DE HOY",systemImage:"figure.walk").font(.caption.bold()).tracking(1); Spacer(); Image(systemName:"arrow.up.right") }.foregroundStyle(.mint)
            HStack(alignment:.firstTextBaseline) {
                Text(result?.value.map(number) ?? "—").font(.system(size:58,weight:.semibold,design:.rounded)).minimumScaleFactor(0.5).lineLimit(1)
                Text("pasos").foregroundStyle(.secondary)
            }
            if let result = result, !result.days.isEmpty { Sparkline(points:Array(result.days.suffix(7)),color:.mint).frame(height:62).accessibilityLabel("Pasos de los últimos siete días") }
            Text(result?.value == nil ? "Sin registros visibles hoy" : "Total de hoy · fuentes combinadas por Salud").font(.caption).foregroundStyle(.secondary)
        }.padding(24).frame(maxWidth:.infinity,alignment:.leading).background(LinearGradient(colors:[.mint.opacity(0.14),.white.opacity(0.035)],startPoint:.topLeading,endPoint:.bottomTrailing),in:RoundedRectangle(cornerRadius:30))
    }
    private var settings:some View {
        List {
            Section("Salud") {
                Button("Revisar permisos de lectura") { model.connect() }.disabled(model.busy)
                Text("Permitir acceso no garantiza que haya datos. iOS no revela si una categoría está vacía o si su lectura se denegó.").font(.footnote).foregroundStyle(.secondary)
                if let date = model.lastRefresh { LabeledContent("Última consulta",value:date.formatted(date:.abbreviated,time:.shortened)) }
            }
            Section("Actualización en segundo plano") {
                Text("\(model.background.values.filter { $0.hasPrefix("Activada") }.count) de \(Metric.all.count) categorías registradas")
                if let date = model.lastBackground { LabeledContent("Última recepción",value:date.formatted(date:.abbreviated,time:.shortened)) }
                else { Text("Aún no se ha observado una recepción en segundo plano.").foregroundStyle(.secondary) }
                Text("Se solicitan avisos horarios de HealthKit. iOS decide cuándo entregarlos; no es una conexión continua con el reloj. Huawei debe sincronizar primero con Salud. Después de reiniciar, desbloquea el iPhone y abre la app. Evita cerrarla a la fuerza durante la prueba.").font(.footnote).foregroundStyle(.secondary)
                NavigationLink("Diagnóstico por categoría") { List(Metric.all) { metric in VStack(alignment:.leading,spacing:6) { Text(metric.name); Text(model.background[metric.id] ?? "Pendiente").font(.caption).foregroundStyle(.secondary) } }.navigationTitle("Segundo plano") }
            }
            Section("Privacidad") {
                Label("Sin cuenta de Pulso ni anuncios",systemImage:"lock.shield")
                Text("Los registros se guardan localmente, protegidos por iOS y excluidos de copias de seguridad. La IA es opcional: solo al autorizarla y solicitar un análisis se envía un resumen a OpenAI. No se modifican los registros de Salud.").font(.footnote).foregroundStyle(.secondary)
                Button("Borrar copia local",role:.destructive) { model.eraseCache() }
                Text("Al actualizar se volverá a consultar Salud. Para impedir nuevas lecturas, revoca el acceso desde Salud → tu perfil → Apps y servicios → Pulso.").font(.caption).foregroundStyle(.secondary)
            }
            Section { Text("Pulso · 3.0\nOrientación de bienestar y tendencias personales. La recuperación es una estimación experimental, no una medida clínica ni un diagnóstico.").font(.footnote).foregroundStyle(.secondary) }
        }.navigationTitle("Conexión")
    }
}
struct SoftPress:ButtonStyle {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    func makeBody(configuration:Configuration)->some View {
        configuration.label.scaleEffect(configuration.isPressed && !reduceMotion ? 0.975 : 1)
            .animation(reduceMotion ? nil : .spring(response:0.28,dampingFraction:0.75),value:configuration.isPressed)
    }
}
struct HistoryChart:View {
    let points:[DayValue]; let color:Color; let suffix:String; let days:Int
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var selected:DayValue?
    var body:some View {
        VStack(alignment:.leading,spacing:12) {
            if let selected = selected { Text(selected.date.formatted(date:.abbreviated,time:.omitted)+" · "+number(selected.value)+" "+suffix).font(.subheadline.monospacedDigit()).foregroundStyle(color) }
            Chart(points) { point in
                BarMark(x:.value("Día",point.date,unit:.day),y:.value(suffix,point.value)).foregroundStyle(color.gradient).cornerRadius(4)
                if let selected = selected, selected.id == point.id {
                    RuleMark(x:.value("Selección",point.date)).foregroundStyle(.white.opacity(0.5)).lineStyle(StrokeStyle(lineWidth:1,dash:[4,4]))
                }
            }.chartXAxis { AxisMarks(values:.stride(by:.day,count:days == 7 ? 1 : 7)) { _ in AxisValueLabel(format:.dateTime.day().month(.abbreviated)) } }
                .chartOverlay { proxy in GeometryReader { geometry in Color.clear.contentShape(Rectangle()).gesture(DragGesture(minimumDistance:0).onChanged { gesture in
                    let x = gesture.location.x - geometry[proxy.plotAreaFrame].origin.x
                    if let date:Date = proxy.value(atX:x) {
                        let nearest = points.min { abs($0.date.timeIntervalSince(date)) < abs($1.date.timeIntervalSince(date)) }
                        if nearest?.id != selected?.id { selected = nearest; UISelectionFeedbackGenerator().selectionChanged() }
                    }
                }) } }.frame(height:220)
            Text("Toca o desliza sobre el gráfico para explorar.").font(.caption).foregroundStyle(.secondary)
        }.animation(reduceMotion ? nil : .easeInOut(duration:0.35),value:days)
            .onChange(of:days) { _ in selected = nil }
    }
}
struct Sparkline:View {
    let points:[DayValue]; let color:Color
    var body:some View {
        Chart(points) { point in
            AreaMark(x:.value("Día",point.date),y:.value("Valor",point.value)).foregroundStyle(LinearGradient(colors:[color.opacity(0.25),color.opacity(0.01)],startPoint:.top,endPoint:.bottom)).interpolationMethod(.monotone)
            LineMark(x:.value("Día",point.date),y:.value("Valor",point.value)).foregroundStyle(color).lineStyle(StrokeStyle(lineWidth:2.5,lineCap:.round)).interpolationMethod(.monotone)
        }.chartXAxis(.hidden).chartYAxis(.hidden)
    }
}
struct MetricCard:View {
    let metric:Metric; let result:MetricResult?
    var body:some View {
        VStack(alignment:.leading,spacing:12) {
            Image(systemName:metric.symbol).foregroundStyle(metric.color).font(.title3)
            Text(metric.name).font(.subheadline).foregroundStyle(.secondary).lineLimit(2).frame(minHeight:36,alignment:.top)
            Text(result?.value.map(number) ?? "—").font(.system(size:30,weight:.semibold,design:.rounded)).lineLimit(1).minimumScaleFactor(0.5)
            Text(result?.value == nil ? "Sin datos visibles" : metric.suffix).font(.caption).foregroundStyle(.secondary)
            if let date = result?.date { Text(date.formatted(date:.abbreviated,time:.shortened)).font(.caption2).foregroundStyle(.secondary) }
            if result?.error != nil { Label("Sin actualizar",systemImage:"exclamationmark.triangle").font(.caption2).foregroundStyle(.orange) }
            if let result = result, !result.days.isEmpty { Sparkline(points:Array(result.days.suffix(7)),color:metric.color).frame(height:34) }
        }.frame(maxWidth:.infinity,alignment:.leading).padding(18).background(.white.opacity(0.045),in:RoundedRectangle(cornerRadius:24))
    }
}
struct MetricRow:View {
    let metric:Metric; let result:MetricResult?
    var body:some View {
        HStack(spacing:14) {
            Image(systemName:metric.symbol).font(.title3).foregroundStyle(metric.color).frame(width:38,height:42).background(metric.color.opacity(0.1),in:RoundedRectangle(cornerRadius:12))
            VStack(alignment:.leading,spacing:5) {
                Text(metric.name).font(.headline)
                Text(result?.date?.formatted(date:.abbreviated,time:.shortened) ?? "Sin registros visibles").font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            if metric.kind == 0 { Text(result?.value.map(number) ?? "—").font(.headline.monospacedDigit()) }
            else if let result = result, !result.records.isEmpty { Text("\(result.records.count)\(result.records.count == 100 ? "+" : "")").font(.headline.monospacedDigit()) }
        }.padding(.vertical,8)
    }
}
struct SleepSegment:Identifiable {
    let start:Date, end:Date
    let phase:Int
    var id:String { "\(start.timeIntervalSince1970)-\(end.timeIntervalSince1970)-\(phase)" }
}
func sleepPhase(_ record:HealthRecord)->Int? {
    if let value = record.categoryValue { return value }
    // Migration for the 2.0 cache. Fresh queries use HealthKit's numeric values.
    if record.text.hasPrefix("En cama") { return 0 }
    if record.text.hasPrefix("Dormido") { return 1 }
    if record.text.hasPrefix("Despierto") { return 2 }
    if record.text.hasPrefix("Sueño esencial") { return 3 }
    if record.text.hasPrefix("Sueño profundo") { return 4 }
    if record.text.hasPrefix("Sueño REM") { return 5 }
    return nil
}
func nightWindow(_ date:Date,calendar:Calendar = .current)->(Date,Date) {
    let noon = calendar.date(bySettingHour:12,minute:0,second:0,of:date)!
    return (calendar.date(byAdding:.day,value:-1,to:noon)!,noon)
}
func resolvedSleep(_ records:[HealthRecord],from start:Date,to end:Date)->[SleepSegment] {
    let records = records.filter { $0.start < end && $0.end > start && (1...5).contains(sleepPhase($0) ?? -1) }
    let boundaries = Array(Set(records.flatMap { [max(start,$0.start),min(end,$0.end)] })).sorted()
    guard boundaries.count > 1 else { return [] }
    var result:[SleepSegment] = []
    for index in 0..<(boundaries.count-1) {
        let a = boundaries[index], b = boundaries[index+1]
        // One phase per instant. Awake wins conflicts, specific phases beat unspecified.
        let active = records.filter { $0.start < b && $0.end > a }.compactMap(sleepPhase)
        let order = [2,4,5,3,1]
        guard let phase = order.first(where:{ active.contains($0) }) else { continue }
        if let last = result.last, last.end == a, last.phase == phase {
            result[result.count-1] = SleepSegment(start:last.start,end:b,phase:phase)
        } else { result.append(SleepSegment(start:a,end:b,phase:phase)) }
    }
    return result
}
func sleepDuration(_ seconds:Double)->String {
    let minutes = Int((seconds/60).rounded())
    return minutes >= 60 ? "\(minutes/60) h \(minutes%60) min" : "\(minutes) min"
}
struct SleepOverview:View {
    let records:[HealthRecord]
    let checked:Date?
    @State private var date = Calendar.current.startOfDay(for:Date())
    @State private var chosenSource = ""
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    private let phases = [4,5,3,2]
    private var window:(Date,Date) { nightWindow(date) }
    private var nightly:[HealthRecord] { records.filter { $0.start < window.1 && $0.end > window.0 } }
    private var sources:[String] { Array(Set(nightly.map(\.source))).sorted() }
    private var source:String? {
        if sources.contains(chosenSource) { return chosenSource }
        // Prefer the Huawei feed; keep other sources separate to avoid mixing stages.
        return sources.first(where:{ $0.localizedCaseInsensitiveContains("huawei") }) ?? sources.first
    }
    private var segments:[SleepSegment] { resolvedSleep(nightly.filter { $0.source == source },from:window.0,to:window.1) }
    private var total:Double { segments.filter { $0.phase != 2 }.reduce(0) { $0+$1.end.timeIntervalSince($1.start) } }
    private func duration(_ phase:Int)->Double { segments.filter { $0.phase == phase }.reduce(0) { $0+$1.end.timeIntervalSince($1.start) } }
    private func title(_ phase:Int)->String { [1:"Sin fase",2:"Despierto",3:"Esencial / ligero",4:"Profundo",5:"REM"][phase] ?? "Sin fase" }
    private func color(_ phase:Int)->Color { switch phase { case 2:return .orange; case 3:return .cyan; case 4:return .indigo; case 5:return .purple; default:return .gray } }
    private var dayTitle:String { Calendar.current.isDateInToday(date) ? "Hoy" : date.formatted(.dateTime.day().month(.wide)) }
    var body:some View {
        VStack(alignment:.leading,spacing:20) {
            HStack {
                Button { move(-1) } label:{ Image(systemName:"chevron.left").padding(10) }.accessibilityLabel("Noche anterior")
                Spacer()
                VStack(spacing:4) { Text(dayTitle).font(.headline); Text("Noche terminada el " + date.formatted(.dateTime.day().month(.abbreviated))).font(.caption).foregroundStyle(.secondary) }
                Spacer()
                Button { move(1) } label:{ Image(systemName:"chevron.right").padding(10) }.disabled(Calendar.current.isDateInToday(date)).accessibilityLabel("Noche siguiente")
            }
            if sources.count > 1 {
                Picker("Fuente del sueño",selection:Binding(get:{ source ?? "" },set:{ chosenSource = $0 })) { ForEach(sources,id:\.self) { Text($0).tag($0) } }.pickerStyle(.menu)
            } else if let source = source { Label(source,systemImage:"watchface.applewatch.case").font(.caption).foregroundStyle(.secondary) }
            if segments.isEmpty {
                Text("Sin sueño visible para esta noche").font(.title2.bold())
                Text("No se sustituye por una noche anterior. Sincroniza Huawei con Salud y actualiza Pulso.").font(.footnote).foregroundStyle(.secondary)
                if let last = records.filter({ (sleepPhase($0) ?? 0) > 0 }).max(by:{ $0.end < $1.end }) {
                    Button("Ver última noche disponible") { date = Calendar.current.startOfDay(for:last.end); chosenSource = "" }
                }
            } else {
                VStack(alignment:.leading,spacing:6) {
                    Text(sleepDuration(total)).font(.system(size:40,weight:.semibold,design:.rounded)).minimumScaleFactor(0.6).lineLimit(1)
                    Text("Tiempo dormido esta noche").foregroundStyle(.secondary)
                    if let first = segments.first, let last = segments.last { Text(first.start.formatted(date:.omitted,time:.shortened)+" → "+last.end.formatted(date:.omitted,time:.shortened)).font(.subheadline.monospacedDigit()).foregroundStyle(.secondary) }
                }
                LazyVGrid(columns:[GridItem(.flexible()),GridItem(.flexible())],spacing:12) {
                    ForEach(phases,id:\.self) { phase in
                        VStack(alignment:.leading,spacing:8) {
                            Label(title(phase),systemImage:phase == 2 ? "sun.max.fill" : "moon.fill").font(.subheadline.weight(.medium)).foregroundStyle(color(phase))
                            Text(duration(phase) > 0 ? sleepDuration(duration(phase)) : "Sin registros").font(.headline).minimumScaleFactor(0.7).lineLimit(1)
                            if phase != 2, duration(phase) > 0, total > 0 { Text("\(Int((duration(phase)/total*100).rounded())) % del sueño").font(.caption).foregroundStyle(.secondary) }
                        }.frame(maxWidth:.infinity,minHeight:82,alignment:.leading).padding(14).background(color(phase).opacity(0.12),in:RoundedRectangle(cornerRadius:20))
                    }
                }
                if duration(1) > 0 { Label("Sin fase identificada: " + sleepDuration(duration(1)),systemImage:"moon.zzz").font(.subheadline).foregroundStyle(.secondary) }
                if !segments.contains(where:{ (3...5).contains($0.phase) }) { Text("La fuente solo ha compartido sueño total, sin fases. Pulso no puede deducir profundo, REM o ligero.").font(.footnote).foregroundStyle(.secondary) }
                Text("ASÍ FUE TU NOCHE").font(.caption.bold()).tracking(1.5).foregroundStyle(.secondary)
                Chart(segments) { segment in
                    BarMark(xStart:.value("Inicio",segment.start),xEnd:.value("Fin",segment.end),y:.value("Fase",title(segment.phase))).foregroundStyle(color(segment.phase)).cornerRadius(3)
                }.chartYScale(domain:["Despierto","REM","Esencial / ligero","Profundo","Sin fase"])
                    .chartXAxis { AxisMarks(values:.stride(by:.hour,count:2)) { _ in AxisValueLabel(format:.dateTime.hour().minute()) } }.frame(height:180)
                Text("De las 12:00 del día anterior a las 12:00 de este día, para incluir la noche completa al cruzar medianoche. Una sola fuente; los intervalos solapados no se cuentan dos veces. «Sin registros» no equivale a cero.").font(.caption).foregroundStyle(.secondary)
            }
        }.animation(reduceMotion ? nil : .easeInOut(duration:0.3),value:date)
    }
    private func move(_ offset:Int) { date = Calendar.current.date(byAdding:.day,value:offset,to:date)!; chosenSource = "" }
}
struct MetricDetail:View {
    let metric:Metric
    @EnvironmentObject var model:HealthDashboard
    @State private var days = 7
    private var result:MetricResult? { model.results[metric.id] }
    private var points:[DayValue] {
        let cutoff = Calendar.current.date(byAdding:.day,value:-(days-1),to:Calendar.current.startOfDay(for:Date()))!
        return (result?.days ?? []).filter { $0.date >= cutoff }
    }
    var body:some View {
        ScrollView {
            VStack(alignment:.leading,spacing:24) {
                Image(systemName:metric.symbol).font(.largeTitle).foregroundStyle(metric.color)
                if metric.key == "SleepAnalysis" { SleepOverview(records:result?.sleepRecords ?? result?.records ?? [],checked:result?.checked) }
                if metric.kind == 0 || metric.key == "SleepAnalysis" {
                    if metric.key != "SleepAnalysis" {
                    HStack(alignment:.firstTextBaseline) { Text(result?.value.map(number) ?? "—").font(.system(size:54,weight:.semibold,design:.rounded)); Text(metric.key == "SleepAnalysis" ? "h" : metric.suffix).font(.title3).foregroundStyle(.secondary) }
                    Text(metric.key == "SleepAnalysis" ? "Último día con sueño registrado" : (metric.cumulative ? "Total de hoy" : "Última lectura disponible")).foregroundStyle(.secondary)
                    } else { Text("HISTÓRICO POR DÍA NATURAL").font(.caption.bold()).tracking(1.5).foregroundStyle(.secondary) }
                    Picker("Período",selection:$days) { Text("7 días").tag(7); Text("30 días").tag(30) }.pickerStyle(.segmented)
                    if !points.isEmpty {
                        HistoryChart(points:points,color:metric.color,suffix:metric.key == "SleepAnalysis" ? "h" : metric.suffix,days:days)
                        Text(metric.key == "SleepAnalysis" ? "Horas dormidas por día natural, incluidas siestas. Se unen intervalos solapados de todas las fuentes, excluyendo «En cama» y «Despierto»." : (metric.cumulative ? "Totales diarios calculados por Salud. Los días vacíos no se representan como cero." : "Promedios diarios de las lecturas disponibles. Los días vacíos no se representan como cero.")).font(.caption).foregroundStyle(.secondary)
                    }
                }
                if let error = result?.error { Label("No se pudo actualizar: \(error)",systemImage:"exclamationmark.triangle").font(.footnote).foregroundStyle(.orange) }
                if result?.records.isEmpty ?? true {
                    VStack(alignment:.leading,spacing:10) {
                        Text("Sin registros visibles").font(.title3.bold())
                        Text("Puede que esta categoría no tenga datos o que no hayas permitido su lectura. Comprueba Salud y los permisos. Que el reloj mida algo no implica que Huawei lo exporte.").foregroundStyle(.secondary)
                    }.padding(20).background(.white.opacity(0.05),in:RoundedRectangle(cornerRadius:20))
                }
                if let result = result, !result.sources.isEmpty {
                    Text("FUENTES VISIBLES").font(.caption.bold()).tracking(1.5).foregroundStyle(.secondary)
                    ForEach(result.sources,id:\.self) { source in Label(source,systemImage:source.localizedCaseInsensitiveContains("huawei") ? "watchface.applewatch.case" : "heart.text.square").font(.subheadline) }
                    Text("Fuentes presentes en las últimas 100 muestras. Los totales pueden incluir otras fuentes. Un nombre Huawei indica el origen declarado por la app, no identifica por sí solo el dispositivo.").font(.caption).foregroundStyle(.secondary)
                }
                Text("REGISTROS RECIENTES").font(.caption.bold()).tracking(1.5).foregroundStyle(.secondary)
                if metric.key == "SleepAnalysis" { Text("Fases y sesiones originales. No se suman «En cama» y «Dormido» ni muestras de distintas fuentes: pueden solaparse.").font(.footnote).foregroundStyle(.secondary) }
                ForEach(result?.records ?? []) { record in
                    VStack(alignment:.leading,spacing:8) {
                        Text(record.text).font(.headline)
                        Text(record.start.formatted(date:.abbreviated,time:.shortened) + " → " + record.end.formatted(date:.abbreviated,time:.shortened)).font(.caption).foregroundStyle(.secondary)
                        Text(record.source).font(.caption).foregroundStyle(metric.color)
                    }.frame(maxWidth:.infinity,alignment:.leading).padding(18).background(.white.opacity(0.04),in:RoundedRectangle(cornerRadius:20))
                }
                Text("Hasta 100 muestras recientes disponibles. Los gráficos consultan todas las muestras de los últimos 30 días. Los ECG muestran su clasificación registrada; no se descarga la señal ni se interpreta. Las rutas GPS y las métricas propietarias de Huawei no están incluidas.").font(.caption).foregroundStyle(.secondary)
            }.padding(22)
        }.navigationTitle(metric.name).navigationBarTitleDisplayMode(.inline).refreshable { model.refresh() }
    }
}
struct DayValue:Codable,Identifiable { var date:Date; var value:Double; var id:Date { date } }
struct HealthRecord:Codable,Identifiable { var id:String; var start:Date; var end:Date; var text:String; var source:String; var categoryValue:Int? = nil; var quantityValue:Double? = nil }
struct MetricResult:Codable {
    var value:Double?; var date:Date?
    var days:[DayValue] = []; var records:[HealthRecord] = []; var sources:[String] = []
    var error:String?; var checked:Date = Date()
    var sleepRecords:[HealthRecord]? = nil
    var workouts:[WorkoutSummary]? = nil
}
// Union of clipped asleep intervals: never adds overlapping sources or in-bed time.
func asleepSeconds(_ records:[HealthRecord],from start:Date,to end:Date)->Double {
    let intervals = records.filter { $0.text.hasPrefix("Dormido") || $0.text.hasPrefix("Sueño ") }.map { (max($0.start,start),min($0.end,end)) }.filter { $0.1 > $0.0 }.sorted { $0.0 < $1.0 }
    var total:Double = 0
    var current:(Date,Date)?
    for interval in intervals {
        if let old = current {
            if interval.0 <= old.1 { current = (old.0,max(old.1,interval.1)) }
            else { total += old.1.timeIntervalSince(old.0); current = interval }
        } else { current = interval }
    }
    if let old = current { total += old.1.timeIntervalSince(old.0) }
    return total
}
func number(_ value:Double)->String { value.formatted(.number.precision(.fractionLength(0...1)).locale(Locale(identifier:"es_ES"))) }

@MainActor final class HealthDashboard:ObservableObject {
    @Published var results:[String:MetricResult] = [:]
    @Published var busy = false
    @Published var message:String?
    @Published var background:[String:String] = [:]
    @Published var lastBackground:Date?
    @Published var lastRefresh:Date?
    @Published var connected = UserDefaults.standard.bool(forKey:"health.connected")
    private let health = HKHealthStore()
    private var observers:[HKObserverQuery] = []
    private var inFlight = Set<String>()
    private var pending:[String:[()->Void]] = [:]
    private var cacheURL:URL? {
        guard let folder = FileManager.default.urls(for:.applicationSupportDirectory,in:.userDomainMask).first else { return nil }
        do { try FileManager.default.createDirectory(at:folder,withIntermediateDirectories:true); return folder.appendingPathComponent("health-dashboard.json") } catch { return nil }
    }
    init() {
        if let url = cacheURL, let data = try? Data(contentsOf:url), let saved = try? JSONDecoder().decode([String:MetricResult].self,from:data) { results = saved }
        lastBackground = UserDefaults.standard.object(forKey:"health.lastBackground") as? Date
        #if targetEnvironment(simulator)
        if CommandLine.arguments.contains("--preview-data") { preview(); return }
        #endif
        if connected { installObservers(); refresh() }
    }
    func connect() {
        guard HKHealthStore.isHealthDataAvailable() else { message = "Salud solo está disponible en un iPhone compatible."; return }
        busy = true
        health.requestAuthorization(toShare:[],read:Set(Metric.all.compactMap(\.type))) { [weak self] success,error in
            Task { @MainActor in
                guard let self = self else { return }
                self.busy = false
                if let error = error { self.message = error.localizedDescription; return }
                guard success else { self.message = "No se completó la solicitud de acceso."; return }
                self.connected = true; UserDefaults.standard.set(true,forKey:"health.connected")
                self.installObservers(); self.refresh()
            }
        }
    }
    func refresh() {
        #if targetEnvironment(simulator)
        if CommandLine.arguments.contains("--preview-data") { return }
        #endif
        guard connected, !busy else { return }
        busy = true; message = nil
        var remaining = Metric.all.count
        for metric in Metric.all {
            load(metric) { [weak self] in
                remaining -= 1
                if remaining == 0 { self?.busy = false; self?.lastRefresh = Date(); self?.save() }
            }
        }
    }
    private func preview() {
        connected = true
        for metric in Metric.all where ["StepCount","HeartRate","OxygenSaturation","RestingHeartRate","ActiveEnergyBurned","SleepAnalysis","Workout"].contains(metric.key) {
            var result = MetricResult(date:Date())
            let base:[String:Double] = ["StepCount":8234,"HeartRate":68,"OxygenSaturation":98,"RestingHeartRate":57,"ActiveEnergyBurned":426]
            result.value = base[metric.key]
            if let value = result.value { result.days = (0..<30).map { i in DayValue(date:Calendar.current.date(byAdding:.day,value:i-29,to:Calendar.current.startOfDay(for:Date()))!,value:value * (0.8+Double(i%5)*0.07)) } }
            result.sources = ["Datos de demostración"]
            result.records = [HealthRecord(id:metric.id,start:Date().addingTimeInterval(-3600),end:Date(),text:metric.kind == 0 ? number(result.value ?? 0)+" "+metric.suffix : "Registro de ejemplo",source:"Datos de demostración")]
            if metric.key == "SleepAnalysis" {
                let midnight = Calendar.current.startOfDay(for:Date())
                let start = midnight.addingTimeInterval(-3600)
                let stages:[(Int,Double)] = [(3,60),(4,75),(3,90),(5,30),(2,12),(3,80),(4,40),(5,50),(3,43)]
                var cursor = start
                result.sleepRecords = stages.enumerated().map { index,stage in
                    let end = cursor.addingTimeInterval(stage.1*60)
                    defer { cursor = end }
                    return HealthRecord(id:"preview-\(index)",start:cursor,end:end,text:"Fase de ejemplo",source:"Datos de demostración",categoryValue:stage.0)
                }
                result.records = result.sleepRecords ?? []
            }
            results[metric.id] = result
        }
        if var sleep = results["SleepAnalysis"] {
            for offset in 1...28 {
                let date = Calendar.current.date(byAdding:.day,value:-offset,to:Date())!
                let end = Calendar.current.date(bySettingHour:7,minute:0,second:0,of:date)!
                sleep.sleepRecords?.append(HealthRecord(id:"night-\(offset)",start:end.addingTimeInterval(-8*3600),end:end,text:"Dormido (sin fase)",source:"Datos de demostración",categoryValue:1))
            }
            results["SleepAnalysis"] = sleep
        }
        var vo2 = MetricResult(value:43.5,date:Date())
        vo2.sources = ["Datos de demostración"]
        vo2.days = (0..<12).map { DayValue(date:Calendar.current.date(byAdding:.day,value:($0-11)*2,to:Calendar.current.startOfDay(for:Date()))!,value:42+Double($0)*0.13) }
        results["VO2Max"] = vo2
        var workout = results["Workout"] ?? MetricResult()
        workout.workouts = (0..<8).map { index in
            let end = Calendar.current.date(byAdding:.day,value:-(index*2+1),to:Date())!
            return WorkoutSummary(id:"demo-workout-\(index)",start:end.addingTimeInterval(-1800),end:end,activity:"Caminar",kind:52,minutes:30,distanceKM:2.5,averageHR:112)
        }
        results["Workout"] = workout
        if CommandLine.arguments.contains("--preview-evening") || CommandLine.arguments.contains("--preview-morning") {
            let hour = CommandLine.arguments.contains("--preview-evening") ? 20 : 8
            let date = Calendar.current.date(bySettingHour:hour,minute:0,second:0,of:Date())!
            for key in Array(results.keys) { results[key]?.checked = date }
        }
        message = "VISTA PREVIA · datos ficticios"
    }
    private func installObservers() {
        guard observers.isEmpty else { return }
        for metric in Metric.all {
            guard let type = metric.type else { continue }
            let observer = HKObserverQuery(sampleType:type,predicate:nil) { [weak self] _,completion,error in
                Task { @MainActor in
                    guard let self = self else { completion(); return }
                    if let error = error { self.background[metric.id] = error.localizedDescription; completion(); return }
                    let wasBackground = UIApplication.shared.applicationState == .background
                    self.load(metric) {
                        if wasBackground, self.results[metric.id]?.error == nil {
                            self.lastBackground = Date(); UserDefaults.standard.set(self.lastBackground,forKey:"health.lastBackground")
                        }
                        self.save(); completion()
                    }
                }
            }
            observers.append(observer); health.execute(observer)
            health.enableBackgroundDelivery(for:type,frequency:.hourly) { [weak self] success,error in
                Task { @MainActor in self?.background[metric.id] = success ? "Activada · frecuencia solicitada: cada hora" : (error?.localizedDescription ?? "No disponible para esta categoría") }
            }
        }
    }
    private func save() {
        guard let url = cacheURL else { return }
        do {
            try JSONEncoder().encode(results).write(to:url,options:[.atomic,.completeFileProtectionUntilFirstUserAuthentication])
            var file = url; var values = URLResourceValues(); values.isExcludedFromBackup = true; try file.setResourceValues(values)
        } catch { message = "No se pudo guardar la copia local: \(error.localizedDescription)" }
    }
    func eraseCache() {
        results = [:]; if let url = cacheURL { try? FileManager.default.removeItem(at:url) }
        lastBackground = nil; lastRefresh = nil; UserDefaults.standard.removeObject(forKey:"health.lastBackground")
    }
    private func load(_ metric:Metric,completion:@escaping ()->Void) {
        if inFlight.contains(metric.id) { pending[metric.id,default:[]].append(completion); return }
        guard let type = metric.type else { completion(); return }
        inFlight.insert(metric.id)
        let finish:(MetricResult)->Void = { [weak self] result in
            guard let self = self else { completion(); return }
            if result.error != nil, var old = self.results[metric.id] { old.error = result.error; self.results[metric.id] = old }
            else { self.results[metric.id] = result }
            self.inFlight.remove(metric.id)
            let callbacks = self.pending.removeValue(forKey:metric.id) ?? []
            completion()
            // An observer can arrive after this query took its snapshot. Requery once
            // before acknowledging those events, so a mid-query update is not lost.
            if !callbacks.isEmpty { self.load(metric) { callbacks.forEach { $0() } } }
        }
        let start = Calendar.current.date(byAdding:.day,value:-29,to:Calendar.current.startOfDay(for:Date()))!
        let predicate = HKQuery.predicateForSamples(withStart:start,end:Date(),options:[])
        let query = HKSampleQuery(sampleType:type,predicate:metric.key == "SleepAnalysis" ? predicate : nil,limit:metric.key == "SleepAnalysis" ? HKObjectQueryNoLimit : 100,sortDescriptors:[NSSortDescriptor(key:HKSampleSortIdentifierEndDate,ascending:false)]) { [weak self] _,samples,error in
            Task { @MainActor in
                guard let self = self else { completion(); return }
                if let error = error { finish(MetricResult(error:error.localizedDescription)); return }
                let samples = samples ?? []
                var result = MetricResult(date:samples.first?.endDate)
                result.sources = Array(Set(samples.map { $0.sourceRevision.source.name })).sorted()
                result.records = samples.map { sample in
                    var record = HealthRecord(id:sample.uuid.uuidString,start:sample.startDate,end:sample.endDate,text:self.describe(sample,metric:metric),source:sample.sourceRevision.source.name,categoryValue:(sample as? HKCategorySample)?.value)
                    if let sample = sample as? HKQuantitySample, let unit = metric.unit { record.quantityValue = sample.quantity.doubleValue(for:unit) * (metric.suffix == "%" ? 100 : 1) }
                    return record
                }
                if metric.key == "Workout" {
                    let hrType = HKObjectType.quantityType(forIdentifier:.heartRate)!
                    result.workouts = samples.compactMap { sample -> WorkoutSummary? in
                        guard let workout = sample as? HKWorkout else { return nil }
                        let activity = self.describe(workout,metric:metric).components(separatedBy:" · ").first ?? "Entrenamiento"
                        return WorkoutSummary(id:workout.uuid.uuidString,start:workout.startDate,end:workout.endDate,activity:activity,kind:workout.workoutActivityType.rawValue,minutes:workout.duration/60,distanceKM:workout.totalDistance?.doubleValue(for:.meterUnit(with:.kilo)),averageHR:workout.statistics(for:hrType)?.averageQuantity()?.doubleValue(for:.count().unitDivided(by:.minute())))
                    }
                }
                if metric.key == "SleepAnalysis" {
                    result.sleepRecords = result.records
                    for offset in 0..<30 {
                        let day = Calendar.current.date(byAdding:.day,value:offset,to:start)!
                        let end = Calendar.current.date(byAdding:.day,value:1,to:day)!
                        let seconds = asleepSeconds(result.records,from:day,to:end)
                        if seconds > 0 { result.days.append(DayValue(date:day,value:seconds/3600)) }
                    }
                    result.value = result.days.last?.value
                    result.records = Array(result.records.prefix(100))
                    finish(result); return
                }
                if let sample = samples.first as? HKQuantitySample, let unit = metric.unit { result.value = sample.quantity.doubleValue(for:unit) * (metric.suffix == "%" ? 100 : 1) }
                else if !samples.isEmpty { result.value = Double(samples.count) }
                guard let quantityType = type as? HKQuantityType, let unit = metric.unit else { finish(result); return }
                let query = HKStatisticsCollectionQuery(quantityType:quantityType,quantitySamplePredicate:predicate,options:metric.cumulative ? .cumulativeSum : .discreteAverage,anchorDate:Calendar.current.startOfDay(for:Date()),intervalComponents:DateComponents(day:1))
                query.initialResultsHandler = { _,collection,error in
                    var points:[DayValue] = []
                    collection?.enumerateStatistics(from:start,to:Date()) { stat,_ in
                        if let value = metric.cumulative ? stat.sumQuantity() : stat.averageQuantity() { points.append(DayValue(date:stat.startDate,value:value.doubleValue(for:unit) * (metric.suffix == "%" ? 100 : 1))) }
                    }
                    let captured = points
                    Task { @MainActor in
                        self.health.stop(query)
                        result.days = captured
                        if let error = error { result.error = error.localizedDescription }
                        if metric.cumulative { result.value = captured.first(where:{ Calendar.current.isDateInToday($0.date) })?.value }
                        finish(result)
                    }
                }
                self.health.execute(query)
            }
        }
        health.execute(query)
    }
    private func describe(_ sample:HKSample,metric:Metric)->String {
        if let sample = sample as? HKQuantitySample, let unit = metric.unit { return number(sample.quantity.doubleValue(for:unit) * (metric.suffix == "%" ? 100 : 1)) + " " + metric.suffix }
        if let workout = sample as? HKWorkout {
            let names:[HKWorkoutActivityType:String] = [.walking:"Caminar",.running:"Correr",.cycling:"Ciclismo",.swimming:"Natación",.hiking:"Senderismo",.traditionalStrengthTraining:"Fuerza",.functionalStrengthTraining:"Fuerza funcional",.yoga:"Yoga",.elliptical:"Elíptica",.rowing:"Remo",.dance:"Baile",.soccer:"Fútbol",.tennis:"Tenis",.other:"Otro entrenamiento"]
            var text = (names[workout.workoutActivityType] ?? "Entrenamiento (\(workout.workoutActivityType.rawValue))") + " · \(Int(workout.duration/60)) min"
            if let energy = workout.totalEnergyBurned { text += " · \(Int(energy.doubleValue(for:.kilocalorie()))) kcal" }
            if let distance = workout.totalDistance { text += " · \(number(distance.doubleValue(for:.meterUnit(with:.kilo)))) km" }
            return text
        }
        if let sample = sample as? HKCategorySample {
            if metric.key == "SleepAnalysis" {
                let names = [0:"En cama",1:"Dormido (sin fase)",2:"Despierto",3:"Sueño esencial",4:"Sueño profundo",5:"Sueño REM"]
                return (names[sample.value] ?? "Sueño") + " · \(Int(sample.endDate.timeIntervalSince(sample.startDate)/60)) min"
            }
            return metric.name + " · \(Int(sample.endDate.timeIntervalSince(sample.startDate)/60)) min · valor \(sample.value)"
        }
        if let ecg = sample as? HKElectrocardiogram {
            let names:[HKElectrocardiogram.Classification:String] = [.sinusRhythm:"Ritmo sinusal",.atrialFibrillation:"Fibrilación auricular",.inconclusiveLowHeartRate:"Pulso bajo",.inconclusiveHighHeartRate:"Pulso alto",.inconclusivePoorReading:"Lectura deficiente",.inconclusiveOther:"No concluyente",.notSet:"Sin clasificar",.unrecognized:"Sin reconocer"]
            return names[ecg.classification] ?? "Electrocardiograma"
        }
        if let audiogram = sample as? HKAudiogramSample { return "Audiograma · \(audiogram.sensitivityPoints.count) frecuencias" }
        return metric.name
    }
}


