# Pulso 3.0 - tu ritmo, recuperación y orientación IA

Actualiza encima de Pulso con el mismo iLoader HealthKit y cuenta Apple. Abre la app y espera a que termine la actualización de Salud: las sesiones ahora incluyen duración, tipo, distancia y pulso medio cuando HealthKit lo proporciona.

## Empezar
1. En Resumen, pulsa Personalizar mi día: edad, días con clases/trabajo, horas de despertar y minutos disponibles. Puedes cambiar solo mañana.
2. Usa Cómo me encuentro para registrar energía subjetiva, molestias y si hoy estás indispuesto. No se confirma ninguna sensación por defecto.
3. En Tu plan consulta una propuesta conservadora, agenda de sueño, gráficos y sesiones. Valora el esfuerzo de cada sesión (RPE 0-10); el índice de esfuerzo es RPE × 10 y la carga declarada es minutos × RPE. No se inventa intensidad a partir de calorías o duración.
4. La primera ventana de dos horas se estima desde el final del sueño visible; no es una detección exacta de cuándo despertaste. Después se prioriza movimiento o descanso según los datos. Al terminar ejercicio, en recuperación o por la noche, gana protagonismo la agenda de sueño.

## Recuperación, límites y aprendizaje
El índice 0-100 es una heurística experimental de Pulso, no una medición de energía, validación clínica, réplica del algoritmo Samsung/Huawei/Garmin ni predicción demostrada de tu rendimiento. Sin sueño reciente o perfil completo no hay puntuación. Factores: duración de sueño 55 %, regularidad de duración 10 %, pulso de reposo 20 %, VFC SDNN diaria 10 % y carga declarada 5 %. Solo usa factores disponibles y renormaliza pesos; muestra la cobertura y los factores ausentes. La VFC diaria SDNN no equivale a la VFC nocturna de otros dispositivos. Datos cardíacos de varias fuentes no se comparan como si fueran una misma serie.

Los objetivos de sueño están acotados por edad. Tras al menos 7 mañanas valoradas favorablemente en las dos horas posteriores al descanso, la mediana de su duración puede ajustar la propuesta: es una asociación observacional, no causalidad ni un horario óptimo. La agenda fija el despertar de mañana, resta el sueño propuesto y 20 minutos para conciliarlo. Un índice alto nunca obliga a intensificar ni garantiza despertar con más energía.

La orientación local de actividad es conservadora y ajustable. Indisposición, molestias importantes, limitaciones, falta de recuperación o edad menor de 18 años impiden generar planes IA de entrenamiento. No es una prescripción de la dosis mínima necesaria para mantener forma. El VO2max solo muestra muestras y tendencias observadas: una muestra después de una sesión no demuestra progreso causado por esa sesión.

## IA opcional y clave
Revoca la clave publicada en la conversación. No está incluida en el proyecto ni en la IPA. Introduce una nueva dentro de la app; se guarda únicamente en el llavero del dispositivo, accesible al desbloquear y no migrable a otro dispositivo.

IA y privacidad muestra exactamente el resumen que se enviará a https://api.openai.com/v1/responses: edad, horario propuesto, preferencias, sueño agregado, factores/índice, cardíacos disponibles, VO2max, sensaciones y hasta 12 sesiones resumidas. No se mandan rutas, ECG, muestras completas, nombre ni identificadores de dispositivo. Activa el consentimiento y pulsa Analizar. Modelo fijo gpt-6-luna, reasoning.effort=max, store=false, salida JSON estructurada, hasta 12000 tokens (incluye razonamiento), sin sustitución de modelo. store=false no equivale a retención cero del proveedor.

La API tiene facturación independiente de la suscripción ChatGPT. El límite local es 3 solicitudes iniciadas por día, sin reintentos automáticos, y se reutiliza un análisis del mismo resumen del día. Configura además el presupuesto en tu proyecto de OpenAI. Se muestran errores de acceso, saldo, respuesta incompleta y red; nunca una respuesta ficticia como resultado real. Las propuestas se validan contra el límite conservador local y se ocultan si dejan de encajar con el estado actual. La IA explica y propone; no cambia el índice local ni ejecuta acciones en Salud.

El envío requiere una clave nueva y una petición explícita. Las pruebas usan datos ficticios y validan el contrato de la API; no demuestran acceso real a OpenAI con tu cuenta ni la calidad clínica del algoritmo.

## Fuentes consultadas
- Samsung, factores de Energy Score: https://news.samsung.com/global/samsung-collaborates-with-the-university-of-georgia-to-define-and-measure-energy-for-innovative-digital-health-experiences
- Garmin, Body Battery: https://www.garmin.com/en-GB/garmin-technology/health-science/body-battery/
- Huawei, sueño/HRV y patrones personales: https://consumer.huawei.com/ae-en/community/healthforward/the-sleep-mood-connection-how-to-track-and-understand-your-sleep-better-with-your-smartwatch/
- CDC, sueño por edad: https://www.cdc.gov/sleep/about/
- OMS, actividad física: https://www.who.int/health-topics/noncommunicable-diseases/physical-activity
- OpenAI, modelo y parámetros: https://developers.openai.com/api/docs/models/gpt-6-luna
- OpenAI, respuestas estructuradas: https://developers.openai.com/api/docs/guides/structured-outputs

Los factores generales de fabricantes orientan el diseño; los pesos y umbrales de Pulso son propios y no han sido validados frente a fatiga o rendimiento reales.
