# Pulso para iPhone

Actualización de Prueba Salud: mantiene com.si002.pruebasalud para usar el firmador HealthKit que ya funciona en tu iPhone.

1. Instala la nueva IPA con el mismo iLoader ajustado y la misma cuenta Apple, encima de Prueba Salud. No la desinstales primero.
2. Abre Pulso y pulsa Conectar con Salud. Permite leer las categorías que quieras.
3. Huawei Salud debe seguir sincronizando el reloj y tener permiso para escribir en Apple Salud.
4. En Conexión consulta el diagnóstico de segundo plano. Registra avisos horarios, sujetos a iOS; no garantiza actualizaciones cada hora.
5. Déjala en segundo plano sin cerrarla a la fuerza, sincroniza el reloj desde Huawei y revisa después Última recepción. Que un registro de avisos sea aceptado no demuestra una recepción real.

64 categorías: actividad, corazón, sueño y respiración, cuerpo, movilidad, sonidos, alimentación, sesiones, ECG y audiogramas. Solo aparecerán los datos exportados a Salud y autorizados. No incluye puntuaciones propietarias Huawei, señal ECG completa ni rutas GPS. No sustituye Huawei Salud.

Históricos de 30 días, gráficos de 7/30 días, hasta 100 muestras recientes por categoría. Para sueño se consultan todas las muestras del período y se unen intervalos dormidos solapados; el gráfico usa días naturales, no noches. Los totales cuantitativos se calculan con consultas estadísticas HealthKit, no sumando las 100 muestras visibles.

Sin backend. Caché JSON en Application Support protegida por el sistema hasta el primer desbloqueo tras reiniciar y excluida de copias de seguridad. No se envían registros a GitHub ni a internet. iOS protege el acceso a Salud mientras está bloqueado; errores conservan datos anteriores con aviso.

La actualización en segundo plano requiere que el perfil y la firma incluyan com.apple.developer.healthkit.background-delivery, además de HealthKit. El firmador existente usa los permisos concedidos por Apple; el diagnóstico muestra el resultado real de enableBackgroundDelivery. Si falta ese permiso, la lectura al abrir sigue funcionando y el segundo plano requiere resolver el perfil, no conceder de nuevo lectura.

Proyecto para Xcode 16+, iOS 16+. Abrir UnRatito.xcodeproj. El target conserva su nombre técnico UnRatito. Tests: solapamientos y límites de sueño, catálogo/estilo de agregación y caché sin datos frente a cero. Las capturas de compilación usan datos ficticios marcados y solo se activan con el argumento --preview-data en simulador.
