# Prueba Salud

Instala el IPA de esta prueba con la misma cuenta gratuita y el mismo iLoader que usaste para Un ratito. Es una app distinta y ocupa otro de los huecos de instalación gratuita.

Abre Prueba Salud, pulsa Comprobar acceso, permite leer Pasos y revisa el resultado. Si indica HealthKit funciona, habrá leído al menos un registro real en este teléfono. Si no hay registros visibles, no se puede distinguir entre permiso denegado y datos ausentes. Si aparece un error de entitlement, el instalador/perfil no ha conservado el permiso necesario.

La app no escribe en Salud, no exporta datos y no hace peticiones de red. Puedes comunicar únicamente el estado o el error, sin compartir cantidades de pasos ni datos personales. No comprueba sincronización en segundo plano ni otras métricas.
