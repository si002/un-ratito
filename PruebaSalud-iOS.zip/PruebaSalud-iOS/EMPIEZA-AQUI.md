# Pulso 3.1 — sueño y movimiento con contexto

Actualiza sobre Pulso usando el mismo iLoader HealthKit y la misma cuenta de Apple. No desinstales la versión anterior. Al abrir, deja que Pulso vuelva a consultar Salud.

## Sueño

Cada etapa muestra los minutos observados, su porcentaje estimado y, cuando hay al menos cinco noches comparables, cómo se compara con tu propio patrón. El reloj no permite afirmar por sí solo que el sueño REM, profundo, ligero o despierto sea suficiente o insuficiente: la app marca esa conclusión como no determinada y no usa las fases para puntuar la calidad.

La puntuación local de sueño es experimental. Combina duración frente a una referencia por edad, cómo valoras tu descanso al despertar y la regularidad de la hora de despertar si hay suficiente historial. No es una medida clínica. Pulso no penaliza dormir por encima del punto central de referencia. En «Cómo me encuentro» puedes registrar una valoración subjetiva de 1 a 5; se guarda localmente y solo se comparte con permiso y cuando pides un análisis.

Con autorización, la IA puede comparar hasta 15 noches con etapas estimadas, horas, autoevaluaciones, energía, pulso/VFC diarios disponibles y entrenamientos registrados antes de dormir. Explica coincidencias como asociaciones, no como causas. La app no registra cafeína, pantallas o estrés, así que la IA no los atribuye como explicación.

## Movimiento y descanso

En «Tu ritmo» puedes elegir mantener o mejorar y cuánto tiempo tienes. La sesión se adapta a edad, preferencia, entrenamientos visibles, sensaciones y recuperación cuando hay datos. Por ejemplo, una sesión de mantenimiento para alguien adolescente empieza normalmente alrededor de 30 minutos y ofrece progresión hacia 40 minutos si hay tiempo; la actividad del día también puede ser educación física, deporte, bici, baile, juegos o desplazamientos. No es necesario realizar todo en una sola sesión.

Como contexto general, la OMS recomienda para edades de 5–17 un promedio de 60 minutos diarios de actividad moderada o vigorosa; para adultos, 150–300 minutos moderados o equivalente vigoroso por semana. Los registros de entrenamiento en Salud pueden omitir buena parte del movimiento cotidiano. No se supone que una barra vacía signifique inactividad. Si ya aparece una sesión, hay indisposición o señales de cautela, Pulso da prioridad al descanso.

En perfiles menores de 18 años, la orientación de ejercicio se calcula localmente; la IA se limita a sueño y bienestar general. Para menores de 13 años la IA permanece desactivada.

## IA y privacidad

Modelo gpt-6-luna, esfuerzo max, respuesta estructurada y hasta tres solicitudes al día. La IA solo se llama cuando das permiso y pulsas analizar. No hay envíos automáticos en segundo plano. «IA y privacidad» permite ver el resumen exacto que se enviará a OpenAI antes de solicitarlo. La petición usa store=false, lo que no equivale a retención cero del proveedor. El uso de la API se factura aparte de ChatGPT.

El proyecto y el artefacto público de GitHub no incluyen una clave. La IPA personalizada local puede llevar una clave preconfigurada; no la compartas porque se puede extraer y usar para consumir saldo. Si la clave que usas se ha expuesto, revócala y reemplázala.

El índice de recuperación y la puntuación del sueño son heurísticas propias. No son Body Battery, Energy Score ni diagnósticos. Pulso no prescribe medicación, no interpreta ECG y no garantiza que el ejercicio mejore VO₂max.

## Fuentes de referencia

- [OMS — actividad física por edad](https://www.who.int/initiatives/behealthy/physical-activity/)
- [AASM — duración del sueño en infancia y adolescencia](https://pmc.ncbi.nlm.nih.gov/articles/PMC4877308/)
- [Revisión sistemática — estimación de fases por wearables frente a polisomnografía](https://pubmed.ncbi.nlm.nih.gov/38557808/)
- [CDC — sueño y duración recomendada](https://www.cdc.gov/sleep/about/)

Las referencias poblacionales no sustituyen una indicación individual. La app no evalúa trastornos del sueño ni sobreentrenamiento.