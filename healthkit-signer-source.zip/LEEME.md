# iLoader — ajuste local para Prueba Salud

Esta compilación NO es una versión oficial de iLoader. Parte del código oficial de iLoader 2.3.9 (commit aa9aa3779e15498180e0205158b7ff91536877c6) y de isideload 0.4.6, verificado por su SHA-256 de crates.io.

El único cambio en la firma se aplica al IPA original con identificador `com.si002.pruebasalud` y descripción de lectura de Salud: solicita a Apple activar el servicio HealthKit, descarga su perfil y exige que incluya `com.apple.developer.healthkit=true`. Si no lo incluye, se detiene con un error. El firmador existente utiliza los permisos de ese perfil. No se falsifican permisos ni se omite la validación de Apple.

No solicita HealthKit para otras apps ni cambia el inicio de sesión. Conserva el identificador de configuración de iLoader para reutilizar sus ajustes y almacenamiento seguro existentes. No añade telemetría ni registra datos de Salud. No incluyas contraseñas, perfiles, certificados o registros de emparejamiento en GitHub.

Para probar: cierra el iLoader normal, abre este ejecutable, conserva el servidor anisette que ya te funcionó e instala de nuevo `PruebaSalud-sin-firmar.ipa` con la misma cuenta. No necesitas cambiar el IPA ni desinstalar la prueba. Abre Prueba Salud y pulsa Comprobar acceso. El éxito en tu iPhone solo se confirma si aparece el diálogo de Salud y/o la lectura de registros se completa.

Las dos pruebas de código verifican el alcance del cambio y que el perfil necesite permiso explícito. No prueban tu cuenta ni tu dispositivo. Puede seguir fallando por una respuesta de Apple, autenticación o problemas ajenos al permiso.

Fuente oficial: https://github.com/nab138/iloader
Servicio HealthKit de referencia: https://github.com/Rzbck/isideload/blob/f7b9f3da570edd6824c29680545e710846d07df5/isideload/src/dev/app_ids.rs
