"""Reproducible, narrowly scoped patch of official iLoader 2.3.9.
No account credentials, profiles or device records are included in this build.
"""
from pathlib import Path
import urllib.request, zipfile, tarfile, hashlib, io, json

BASE = Path('signer-build')
BASE.mkdir(exist_ok=True)
COMMIT = 'aa9aa3779e15498180e0205158b7ff91536877c6'
request = urllib.request.Request(f'https://github.com/nab138/iloader/archive/{COMMIT}.zip', headers={'User-Agent':'HealthKit-probe-build'})
with urllib.request.urlopen(request) as response:
    source = response.read()
with zipfile.ZipFile(io.BytesIO(source)) as archive:
    archive.extractall(BASE)
app = BASE / ('iloader-' + COMMIT)
with urllib.request.urlopen('https://crates.io/api/v1/crates/isideload/0.4.6/download') as response:
    crate = response.read()
assert hashlib.sha256(crate).hexdigest() == '473bde4da71c72bcf5f1cf77acfffdf4b879b65ef989c19f8cb4c3e9ea758a76'
vendor = app / 'src-tauri/vendor'
vendor.mkdir()
with tarfile.open(fileobj=io.BytesIO(crate),mode='r:gz') as archive:
    archive.extractall(vendor,filter='data')
lib = vendor/'isideload-0.4.6'

def replace_once(path, before, after):
    text=path.read_text(encoding='utf-8')
    assert text.count(before)==1, (path,before[:60])
    path.write_text(text.replace(before,after),encoding='utf-8')

sideloader=lib/'src/sideload/sideloader.rs'
replace_once(sideloader,
    'let main_bundle_id = app.main_bundle_id()?;',
    '''let main_bundle_id = app.main_bundle_id()?;
        // Only this explicitly requested diagnostic app may gain HealthKit.
        let request_healthkit = needs_probe_healthkit(
            &main_bundle_id,
            app.bundle.app_info.get("NSHealthShareUsageDescription")
                .and_then(|value| value.as_string()),
        );''')
replace_once(sideloader,
    '        info!("App IDs configured");',
    '''        if request_healthkit {
            let mut features = plist::Dictionary::new();
            features.insert("HK421J6T7P".to_string(), plist::Value::Boolean(true));
            self.dev_session.update_app_id(&team, &main_app_id, features, None)
                .await.context("No se pudo activar HealthKit para Prueba Salud en Apple")?;
        }

        info!("App IDs configured");''')
replace_once(sideloader,
    '        let mut provisioning_profiles: Vec<(String, Profile, Dictionary)> = Vec::new();',
    '''        if request_healthkit {
            let profile = ProvisioningProfile::parse(main_provisioning_profile.encoded_profile.as_ref())?;
            if !profile_allows_healthkit(profile.entitlements()) {
                bail!("Apple no incluyo HealthKit en el perfil de Prueba Salud. Se detiene la instalacion antes de firmar; no se modifica el permiso para ocultar este fallo.");
            }
        }

        let mut provisioning_profiles: Vec<(String, Profile, Dictionary)> = Vec::new();''')
with sideloader.open('a',encoding='utf-8') as f:
    f.write('''

fn needs_probe_healthkit(bundle_id: &str, purpose: Option<&str>) -> bool {
    bundle_id == "com.si002.pruebasalud" && purpose.is_some_and(|s| !s.trim().is_empty())
}

fn profile_allows_healthkit(entitlements: &Dictionary) -> bool {
    entitlements.get("com.apple.developer.healthkit")
        .and_then(|value| value.as_boolean()) == Some(true)
}

#[cfg(test)]
mod healthkit_probe_tests {
    use super::*;
    #[test]
    fn only_explicit_probe_with_usage_description_requests_access() {
        assert!(needs_probe_healthkit("com.si002.pruebasalud", Some("Read steps")));
        assert!(!needs_probe_healthkit("com.si002.unratito", Some("Read steps")));
        assert!(!needs_probe_healthkit("com.si002.pruebasalud.other", Some("Read steps")));
        assert!(!needs_probe_healthkit("com.si002.pruebasalud", None));
        assert!(!needs_probe_healthkit("com.si002.pruebasalud", Some("  ")));
    }
    #[test]
    fn profile_must_explicitly_allow_healthkit() {
        let mut entitlements = Dictionary::new();
        assert!(!profile_allows_healthkit(&entitlements));
        entitlements.insert("com.apple.developer.healthkit".into(), plist::Value::Boolean(false));
        assert!(!profile_allows_healthkit(&entitlements));
        entitlements.insert("com.apple.developer.healthkit".into(), plist::Value::String("true".into()));
        assert!(!profile_allows_healthkit(&entitlements));
        entitlements.insert("com.apple.developer.healthkit".into(), plist::Value::Boolean(true));
        assert!(profile_allows_healthkit(&entitlements));
    }
}
''')
manifest=app/'src-tauri/Cargo.toml'
with manifest.open('a',encoding='utf-8') as f:
    f.write('\n[patch.crates-io]\nisideload = { path = "vendor/isideload-0.4.6" }\n')
config_path=app/'src-tauri/tauri.conf.json'
config=json.loads(config_path.read_text())
config['app']['windows'][0]['title']='iLoader · prueba HealthKit (versión local)'
config_path.write_text(json.dumps(config,indent=2),encoding='utf-8')
Path('signer-app-path.txt').write_text(str(app.resolve()),encoding='utf-8')
print('Parche aplicado: solo com.si002.pruebasalud; perfil verificado antes de firmar.')
