import SwiftUI
import UniformTypeIdentifiers

private enum TaskFilter: String, CaseIterable {
    case all = "Todas", active = "Pendientes", done = "Hechas"
}

struct ContentView: View {
    @EnvironmentObject private var store: TaskStore
    @State private var draft = ""
    @State private var filter = TaskFilter.all
    @State private var showHelp = false
    @State private var showExporter = false
    @State private var showImporter = false
    @State private var exportDocument = BackupDocument(tasks: [])
    @State private var incoming: Backup?
    @State private var confirmImport = false
    @State private var confirmClear = false
    @FocusState private var inputFocused: Bool

    private let green = Color(red: 0.14, green: 0.30, blue: 0.25)
    private let paper = Color(red: 0.965, green: 0.957, blue: 0.929)
    private var visible: [SmallTask] {
        store.tasks.filter { filter == .all || (filter == .done ? $0.done : !$0.done) }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 28) {
                    introduction
                    taskBoard
                    HStack(spacing: 15) {
                        Image(systemName: "sparkle").foregroundStyle(.brown)
                        Text("No tienes que hacerlo todo hoy.\nCon un pequeño paso basta.")
                            .font(.subheadline).lineSpacing(5)
                    }
                    .frame(maxWidth: .infinity).padding(.vertical, 4)
                    Text("UN RATITO PARA TI · SIN PRISAS, SIN CUENTAS")
                        .font(.caption2).tracking(1).foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity)
                }
                .frame(maxWidth: 620).padding(22).frame(maxWidth: .infinity)
            }
            .background(paper).foregroundStyle(green)
            .scrollDismissesKeyboard(.interactively)
            .navigationTitle("un ratito.")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { showHelp = true } label: { Image(systemName: "info.circle") }
                        .accessibilityLabel("Información y copias de seguridad")
                }
            }
            .sheet(isPresented: $showHelp) { helpSheet }
            .fileExporter(isPresented: $showExporter, document: exportDocument,
                          contentType: .json, defaultFilename: "un-ratito-copia") { result in
                if case .failure(let error) = result { store.errorMessage = "No se pudo exportar: " + error.localizedDescription }
            }
            .fileImporter(isPresented: $showImporter, allowedContentTypes: [.json]) { result in
                do {
                    let url = try result.get()
                    let access = url.startAccessingSecurityScopedResource()
                    defer { if access { url.stopAccessingSecurityScopedResource() } }
                    let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
                    guard size <= 5_000_000 else { throw TaskError.invalidBackup }
                    incoming = try Backup.decode(Data(contentsOf: url))
                    confirmImport = true
                } catch let error as CocoaError where error.code == .userCancelled { }
                catch { store.errorMessage = "No se pudo importar: " + error.localizedDescription }
            }
            .alert("No se pudo completar", isPresented: Binding(
                get: { store.errorMessage != nil },
                set: { if !$0 { store.errorMessage = nil } }
            )) { Button("Entendido", role: .cancel) { store.errorMessage = nil } }
                message: { Text(store.errorMessage ?? "") }
            .alert("¿Sustituir tu lista?", isPresented: $confirmImport) {
                Button("Cancelar", role: .cancel) { incoming = nil }
                Button("Importar", role: .destructive) {
                    if let backup = incoming { store.restore(backup) }
                    incoming = nil
                }
            } message: { Text("Se reemplazarán tus tareas por las \(incoming?.tasks.count ?? 0) de la copia. Guarda antes una copia de tu lista actual si quieres conservarla.") }
            .confirmationDialog("¿Borrar todas las tareas hechas?", isPresented: $confirmClear, titleVisibility: .visible) {
                Button("Borrar hechas", role: .destructive) { store.clearCompleted() }
                Button("Cancelar", role: .cancel) { }
            }
        }
        .tint(green)
        .preferredColorScheme(.light)
    }

    private var introduction: some View {
        VStack(alignment: .leading, spacing: 17) {
            Text(Date.now.formatted(.dateTime.weekday(.wide).day().month(.wide).locale(Locale(identifier: "es_ES"))).uppercased())
                .font(.caption2.weight(.semibold)).tracking(1.4)
            HStack(alignment: .top, spacing: 8) {
                Text("Poco a poco,\ntambién cuenta.")
                    .font(.system(.largeTitle, design: .serif)).fontWeight(.regular)
                    .fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 0)
                Image(systemName: "sun.max")
                    .font(.system(size: 42, weight: .ultraLight))
                    .foregroundStyle(Color(red: 0.80, green: 0.61, blue: 0.28))
                    .accessibilityHidden(true)
            }
            Text("Saca de tu cabeza lo que tienes pendiente.\nUna cosa cada vez, a tu ritmo.")
                .font(.subheadline).lineSpacing(5).foregroundStyle(.secondary)
        }.padding(.top, 8)
    }

    private var taskBoard: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("HAZ HUECO PARA LO IMPORTANTE")
                .font(.caption2.weight(.semibold)).tracking(1).foregroundStyle(.secondary)
            ViewThatFits(in: .horizontal) {
                HStack { boardTitle; Spacer(); pendingBadge }
                VStack(alignment: .leading, spacing: 10) { boardTitle; pendingBadge }
            }
            HStack(alignment: .center, spacing: 10) {
                TextField("¿Qué te gustaría hacer?", text: $draft, axis: .vertical)
                    .lineLimit(1...4).submitLabel(.done).focused($inputFocused)
                    .onSubmit(addTask)
                    .onChange(of: draft) { value in
                        if value.utf16.count > 180 {
                            var clipped = String(value.prefix(180))
                            while clipped.utf16.count > 180 { clipped.removeLast() }
                            draft = clipped
                        }
                    }
                    .padding(13).background(paper, in: RoundedRectangle(cornerRadius: 12))
                    .accessibilityLabel("Nueva tarea")
                Button(action: addTask) {
                    Image(systemName: "plus").font(.title3.weight(.medium))
                        .frame(minWidth: 48, minHeight: 48)
                        .foregroundStyle(.white).background(green, in: RoundedRectangle(cornerRadius: 12))
                }
                .disabled(draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                .opacity(draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? 0.5 : 1)
                .accessibilityLabel("Añadir tarea")
            }
            Picker("Mostrar tareas", selection: $filter) {
                ForEach(TaskFilter.allCases, id: \.self) { Text($0.rawValue).tag($0) }
            }.pickerStyle(.segmented)
            VStack(alignment: .leading, spacing: 8) {
                Text(store.tasks.isEmpty ? "Tu próximo paso empieza aquí" : "\(store.completed) de \(store.tasks.count) hechas · cada paso cuenta")
                    .font(.caption).foregroundStyle(.secondary)
                ProgressView(value: Double(store.completed), total: Double(max(store.tasks.count, 1)))
                    .accessibilityLabel("Progreso de tareas")
            }
            if visible.isEmpty {
                VStack(spacing: 12) {
                    Image(systemName: "leaf").font(.largeTitle).foregroundStyle(.green.opacity(0.65))
                    Text(filter == .done ? "Cada paso tendrá su momento." : filter == .active && !store.tasks.isEmpty ? "Por ahora, todo hecho." : "Un poquito de espacio mental.")
                        .font(.system(.title3, design: .serif))
                    Text(filter == .done ? "Aquí aparecerán las tareas que completes." : filter == .active && !store.tasks.isEmpty ? "Disfruta de este ratito para ti." : "Añade tu primera tarea. Puede ser algo pequeño.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                .multilineTextAlignment(.center).frame(maxWidth: .infinity).padding(.vertical, 25)
            } else {
                LazyVStack(spacing: 0) {
                    ForEach(visible) { task in
                        HStack(spacing: 8) {
                            Button { store.toggle(task.id) } label: {
                                HStack(spacing: 12) {
                                    Image(systemName: task.done ? "checkmark.square.fill" : "square")
                                        .font(.title2).foregroundStyle(task.done ? green : .secondary)
                                    Text(task.text).font(.body).strikethrough(task.done)
                                        .foregroundStyle(task.done ? .secondary : .primary)
                                        .multilineTextAlignment(.leading)
                                    Spacer(minLength: 0)
                                }.frame(minHeight: 52)
                            }
                            .buttonStyle(.plain)
                            .accessibilityLabel(task.text)
                            .accessibilityValue(task.done ? "Hecha" : "Pendiente")
                            .accessibilityHint(task.done ? "Pulsa para marcar como pendiente" : "Pulsa para completar")
                            Button(role: .destructive) { store.delete(task.id) } label: {
                                Image(systemName: "xmark").font(.subheadline)
                                    .foregroundStyle(.brown).frame(minWidth: 44, minHeight: 44)
                            }.accessibilityLabel("Eliminar: " + task.text)
                        }
                        Divider()
                    }
                }
            }
            ViewThatFits(in: .horizontal) {
                HStack { localLabel; Spacer(); clearButton }
                VStack(alignment: .leading) { localLabel; clearButton }
            }
        }
        .padding(20).background(.white, in: RoundedRectangle(cornerRadius: 23))
        .overlay(RoundedRectangle(cornerRadius: 23).stroke(green.opacity(0.10), lineWidth: 1))
    }

    private var boardTitle: some View { Text("Mis pequeñas tareas").font(.system(.title2, design: .serif)) }
    private var pendingBadge: some View {
        Text("\(store.pending) \(store.pending == 1 ? "pendiente" : "pendientes")")
            .font(.caption).padding(8).background(paper, in: RoundedRectangle(cornerRadius: 8))
    }
    private var localLabel: some View { Label("Solo en este dispositivo", systemImage: "iphone").font(.caption2).foregroundStyle(.secondary) }
    @ViewBuilder private var clearButton: some View {
        if store.completed > 0 { Button("Borrar hechas", role: .destructive) { confirmClear = true }.font(.caption).frame(minHeight: 44) }
    }
    private func addTask() {
        if store.add(draft) {
            draft = ""
            if filter == .done { filter = .active }
            inputFocused = false
        }
    }

    private var helpSheet: some View {
        NavigationStack {
            List {
                Section("Tu espacio personal") {
                    Label("App nativa de iOS", systemImage: "iphone")
                    Label("Funciona sin internet", systemImage: "wifi.slash")
                    Label("Sin cuentas ni anuncios", systemImage: "leaf")
                    Text("Tus tareas se guardan en los archivos privados de esta app. No se envían a un servidor ni se sincronizan con la web o con otros dispositivos. La copia del dispositivo de Apple puede incluir los datos de la app según tus ajustes.")
                }
                Section("Copias de seguridad") {
                    Button {
                        exportDocument = BackupDocument(tasks: store.tasks)
                        showHelp = false
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { showExporter = true }
                    } label: { Label("Guardar copia en Archivos", systemImage: "square.and.arrow.up") }
                    Button {
                        showHelp = false
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { showImporter = true }
                    } label: { Label("Importar copia JSON", systemImage: "square.and.arrow.down") }
                    Text("Puedes importar una copia de la PWA Un ratito. La importación sustituye tu lista tras pedir confirmación. Exporta una copia antes de desinstalar la app: al eliminarla puedes perder sus datos.")
                }
                Section("Un ratito · 1.0") {
                    Text("Hecha para uso personal. Una cosa cada vez, a tu ritmo.")
                }
            }
            .navigationTitle("Tu app, a mano")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Listo") { showHelp = false } } }
        }.tint(green)
    }
}
