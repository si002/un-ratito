# Un ratito — app nativa de iOS

Proyecto SwiftUI para iPhone con iOS 16 o posterior. No es un navegador incrustado: la pantalla, los botones, los selectores de archivos y el guardado están implementados con las herramientas nativas de Apple. Funciona sin internet desde el primer uso. No requiere backend, paquetes externos ni servicios de pago.

## 1. Llevar el proyecto al Mac

1. Descarga `UnRatito-iOS.zip` en el Mac (puedes trasladarlo desde Windows con AirDrop desde tu iPhone, iCloud Drive, una memoria USB u otro método).
2. Haz doble clic en el ZIP para extraerlo. Conserva toda la carpeta `UnRatito-iOS`, no solo el archivo del proyecto.
3. Instala Xcode desde la Mac App Store. Tu Mac debe ser compatible con la versión de Xcode que admita el iOS de tu iPhone. Abre Xcode una vez y deja que instale los componentes y el soporte para iOS que solicite.
4. Abre `UnRatito.xcodeproj` dentro de la carpeta extraída.

## 2. Probar primero en el simulador

1. En la parte superior de Xcode, elige el esquema **UnRatito** y un **iPhone Simulator** como destino. Si no hay simuladores, instala un runtime de iOS desde Xcode → Settings → Components/Platforms, según la versión.
2. Pulsa el botón triangular **Run** o **⌘R**.
3. Prueba a añadir una tarea, completarla y filtrar. Cierra la app en el simulador y vuelve a abrirla: la tarea debe conservarse.
4. Ejecuta **Product → Test** o **⌘U**. El proyecto incluye cinco pruebas de guardado, recuperación, importación y protección ante archivos dañados o errores de escritura.

El simulador no necesita seleccionar un equipo de firma de Apple. Si Xcode intenta firmar para un iPhone real, revisa el destino seleccionado arriba.

## 3. Preparar tu cuenta gratuita de Apple

1. En **Xcode → Settings → Apple Accounts** (o **Accounts**, según versión), añade tu cuenta de Apple. Introduce tú la contraseña y cualquier código de verificación.
2. En el panel izquierdo, pulsa el icono azul del proyecto **UnRatito**.
3. En **TARGETS**, selecciona **UnRatito**, después **Signing & Capabilities**.
4. Activa **Automatically manage signing** y elige tu nombre con **Personal Team** en **Team**. No hace falta contratar el Apple Developer Program para esta prueba personal.
5. El **Bundle Identifier** inicial es `com.si002.unratito`. Si Xcode indica que no está disponible, cámbialo por uno único, por ejemplo `com.tunombre.unratito.personal`. Conserva el identificador que elijas para las futuras renovaciones.
6. Si vas a ejecutar los tests en el iPhone, selecciona también el target **UnRatitoTests** y el mismo Team. Su Bundle Identifier debe ser distinto del de la app, por ejemplo el de la app seguido de `.tests`.

## 4. Instalarla en tu iPhone

1. Conecta el iPhone al Mac con un cable que transmita datos, desbloquéalo y acepta **Confiar en este ordenador** si aparece.
2. Selecciona tu iPhone como destino junto al esquema **UnRatito** en la barra superior de Xcode. Espera a que termine la preparación del dispositivo.
3. Si Xcode pide **Developer Mode / Modo de desarrollador**, en el iPhone ve a **Ajustes → Privacidad y seguridad → Modo de desarrollador**, actívalo y sigue los pasos de reinicio y confirmación. Puede no aparecer hasta conectar y preparar el teléfono con Xcode.
4. Vuelve a Xcode y pulsa **⌘R**. Xcode compilará, firmará e instalará la app.
5. Si iOS muestra **Desarrollador no fiable**, ve a **Ajustes → General → VPN y gestión de dispositivos**, selecciona tu cuenta de desarrollador y pulsa **Confiar**, si esa opción aparece. Vuelve a ejecutar desde Xcode.
6. Abre **Un ratito** desde su icono. Ya puedes desconectar el cable y usarla sin internet.

## 5. Límite de la instalación gratuita

Con una cuenta gratuita de Apple, el perfil de desarrollo caduca a los **7 días**. Al caducar, la app puede dejar de abrirse. Para renovarla, conecta el iPhone al Mac, abre este mismo proyecto, selecciona el mismo Team y Bundle Identifier y pulsa **⌘R** otra vez. Mantén el proyecto en el Mac.

**No borres la app para renovarla.** Ejecutar de nuevo sobre la misma instalación normalmente conserva sus datos; desinstalarla elimina los datos locales. Guarda copias periódicas. El funcionamiento sin conexión es independiente de la caducidad de la firma.

## 6. Traer las tareas de la web

1. En la PWA, despliega **Tu app, siempre a mano → Guardar copia** y guarda el JSON en Archivos.
2. En la app nativa, pulsa el botón **ⓘ → Importar copia JSON** y selecciona ese archivo.
3. Confirma el reemplazo de la lista. La app nativa y la web guardan sus datos por separado; no se sincronizan automáticamente.

Desde **ⓘ → Guardar copia en Archivos** también puedes exportar la lista de la app nativa. Los datos se guardan como JSON en Application Support dentro de su contenedor privado. La copia del dispositivo de Apple puede incluirlos según tus ajustes.

## Si algo falla

- **Signing requires a development team**: selecciona tu Personal Team en el target UnRatito.
- **Bundle identifier unavailable / cannot be registered**: utiliza un identificador único y conserva el nuevo para las renovaciones.
- **iPhone no disponible / versión de iOS no compatible**: actualiza Xcode y verifica su compatibilidad con macOS y con el iOS de tu teléfono.
- **Developer Mode disabled**: sigue el apartado 4.
- **No se ve el iPhone**: desbloquéalo, comprueba la confianza y prueba otro cable con datos. Consulta **Window → Devices and Simulators**.
- **Error al compilar**: copia el primer error rojo completo, con el nombre del archivo y la versión de Xcode, y envíalo en este chat. No hace falta compartir contraseñas ni certificados.
- **Error al leer los datos**: la app bloquea escrituras para no sobrescribir un guardado que no puede leer. No la desinstales; conserva una copia del contenedor y pide ayuda.

## Comprobación al terminar

- Añadir, marcar, desmarcar y eliminar una tarea.
- Filtrar por todas, pendientes y hechas.
- Cerrar la app completamente y reabrirla: conservar la lista.
- Usarla en modo avión.
- Exportar un JSON e importarlo tras confirmar el reemplazo.
- Comprobar el tamaño de texto del sistema, VoiceOver y orientación horizontal en tu iPhone.

## Estado de verificación de esta entrega

Preparada en Windows. Se ha revisado la estructura del proyecto, las referencias a archivos, el esquema compartido, el catálogo de iconos, los archivos XML/JSON y el ZIP. **No se ha compilado con Xcode ni ejecutado en simulador/iPhone**: estos pasos quedan para el Mac. Las pruebas XCTest están incluidas, pero aún no ejecutadas.

## Fuentes oficiales

- Ejecutar en simulador o dispositivo: https://developer.apple.com/documentation/Xcode/running-your-app-on-simulated-or-physical-devices
- Modo de desarrollador: https://developer.apple.com/documentation/xcode/enabling-developer-mode-on-a-device
- Cuenta gratuita y límites de Personal Team: https://developer.apple.com/help/account/basics/about-your-developer-account
- Compatibilidad de Xcode y macOS: https://developer.apple.com/xcode/system-requirements
